def template_render(template, content):
    return template.replace("__CONTENT__", content)
