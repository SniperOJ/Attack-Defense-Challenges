<?php
namespace app\admin\controller;

use think\Db;
use think\Request;
use think\Loader;
use think\Exception;
use app\common\util\Random;
use app\common\util\ReturnCode;
use app\common\library\Tree;

use app\admin\model\AuthGroup;
use app\admin\model\AuthGroupAccess;

class Admin extends Base
{
    protected $model = null;
    protected $childrenGroupIds = [];
    protected $childrenAdminIds = [];

    public function _initialize() {
        parent::_initialize();
        $this->model = model('Admin');

        $this->childrenAdminIds = $this->auth->getChildrenAdminIds(true);
        $this->childrenGroupIds = $this->auth->getChildrenGroupIds(true);

        $groupList = collection(AuthGroup::where('id', 'in', $this->childrenGroupIds)->select())->toArray();

        Tree::instance()->init($groupList);
        $groupdata = [];
        if ($this->auth->isSuperAdmin())
        {
            $result = Tree::instance()->getTreeList(Tree::instance()->getTreeArray(0));
            foreach ($result as $k => $v)
            {
                $groupdata[$v['id']] = $v['name'];
            }
        }
        else
        {
            $result = [];
            $groups = $this->auth->getGroups();
            foreach ($groups as $m => $n)
            {
                $childlist = Tree::instance()->getTreeList(Tree::instance()->getTreeArray($n['id']));
                $temp = [];
                foreach ($childlist as $k => $v)
                {
                    $temp[$v['id']] = $v['name'];
                }
                $result[$n['name']] = $temp;
            }
            $groupdata = $result;
        }

        $this->view->assign('groupdata', $groupdata);
    }
    
    /**
     * 查看管理员个人信息
     */
    public function info() {
        $info = Db::name('admin')->where(['id' => $this->adminInfo['id']])->find();
        $this->assign('info', $info);
        return $this->fetch();
    }

    /**
     * 更新管理员个人信息
     */
    public function update() {
        if ($this->isAjaxPost()) {
            $password = $this->request->param('password');
            $nickname = $this->request->param('nickname');
            $phone = $this->request->param('phone');

            $data['nickname'] = $nickname;
            $data['phone'] = $phone;
            if ($password) {
                $data['salt'] = Random::alnum();
                $data['password'] = md5(md5($password) . $data['salt']);
            }
            $res = Db::name('admin')->where(['id' => $this->adminInfo['id']])->update($data);
            if ($res === false) {
                return $this->buildFailed(ReturnCode::ADD_FAILED, '修改失败');
            } else {
                return $this->buildSuccess([], '修改成功');
            }
        } else {
            return $this->buildFailed(ReturnCode::INVALID, '非法操作');
        }
    }

    /**
     * 管理员列表
     */
    public function index()
    {
        if ($this->isAjaxGet()) {
            $loginname = $this->request->param('loginname', '');
            $nickname = $this->request->param('nickname', '');
            $where = [];
            if ($loginname) {
                $where['loginname'] = ['like', "%{$loginname}%"];
            }
            if ($nickname) {
                $where['nickname'] = ['like', "%{$nickname}%"];
            }

            $childrenGroupIds = $this->childrenGroupIds;
            $groupName = AuthGroup::where('id', 'in', $childrenGroupIds)
                    ->column('id,name');
            $authGroupList = AuthGroupAccess::where('group_id', 'in', $childrenGroupIds)
                    ->field('uid,group_id')
                    ->select();

            $adminGroupName = [];
            foreach ($authGroupList as $k => $v)
            {
                if (isset($groupName[$v['group_id']]))
                    $adminGroupName[$v['uid']][$v['group_id']] = $groupName[$v['group_id']];
            }
            $groups = $this->auth->getGroups();
            foreach ($groups as $m => $n)
            {
                $adminGroupName[$this->auth->id][$n['id']] = $n['name'];
            }

            $model = Db::name('admin')->where($where)->paginate($this->limit);
            $adminList = $model->toArray();

            foreach ($adminList['data'] as $key => $value) {
                $adminList['data'][$key]['createtime'] = date('Y-m-d H:i:s', $value['createtime']);
                $adminList['data'][$key]['logintime'] = $value['logintime'] > 0 ? date('Y-m-d H:i:s', $value['logintime']) : '-';
                $groups = isset($adminGroupName[$value['id']]) ? $adminGroupName[$value['id']] : [];
                $adminList['data'][$key]['groups'] = implode(',', array_keys($groups));
                $adminList['data'][$key]['groups_text'] = implode(',', array_values($groups));
            }

            $data = $adminList['data'];
            $count = $adminList['total'];
            return $this->buildTableSuccess($data, $count);
        } else {
            return $this->fetch();
        }
    }

    /**
     * 添加管理员
     */
    public function add() {
        if ($this->isAjaxPost()) {
            $params = $this->request->param();
            $params['salt'] = Random::alnum();
            $data = [
                'loginname' => $params['loginname'],
                'nickname' => $params['nickname'],
                'phone' => $params['phone'],
                'avatar' => '/assets/img/avatar.png',
                'salt' => $params['salt'],
                'password' => md5(md5($params['password']) . $params['salt'])
            ];
            Db::startTrans();
            try {
                $adminModel = model('Admin');
                $res = $adminModel->validate('Admin.add')->save($data);
                if ($res === false) {
                    throw new Exception($adminModel->getError());
                }
                $group = $this->request->post("group/a");
                //过滤不允许的组别,避免越权
                $group = array_intersect($this->childrenGroupIds, $group);
                $dataset = [];
                foreach ($group as $value)
                {
                    $dataset[] = ['uid' => $adminModel->id, 'group_id' => $value];
                }
                $res = model('AuthGroupAccess')->saveAll($dataset);
                if ($res === false) {
                    throw new Exception('添加失败');
                }
                Db::commit();
                return $this->buildSuccess([], '添加成功');
            } catch(Exception $e) {
                Db::rollback();
                return $this->buildFailed(ReturnCode::ADD_FAILED, $e->getMessage());
            }
        } else {
            return $this->fetch();
        }
    }

    /**
     * 修改管理员
     */
    public function edit() {
        $id = $this->request->param('id', 0);
        if (! $id) {
            $this->error('非法操作');
        }
        $info = Db::name('admin')->where(['id' => $id])->find();
        if (empty($info)) {
            $this->error('非法操作');
        }
        if ($this->isAjaxPost()) {
            $params = $this->request->param();
            $data = [];

            if ($params['password'])
            {
                $data['salt'] = Random::alnum();
                $data['password'] = md5(md5($params['password']) . $data['salt']);
            }

            $data['nickname'] = $params['nickname'];
            $data['phone'] = $params['phone'];
            $data['status'] = $params['status'];
            $data['updatetime'] = time();

            Db::startTrans();

            try {
                $res = Db::name('admin')->where(['id' => $info['id']])->update($data);
                if ($res === false) {
                    throw new Exception('编辑失败');
                }
                // 先移除所有权限
                model('AuthGroupAccess')->where('uid', $info['id'])->delete();

                $group = $this->request->post("group/a");

                // 过滤不允许的组别,避免越权
                $group = array_intersect($this->childrenGroupIds, $group);

                $dataset = [];
                foreach ($group as $value)
                {
                    $dataset[] = ['uid' => $info['id'], 'group_id' => $value];
                }
                $res = model('AuthGroupAccess')->saveAll($dataset);
                if ($res === false) {
                    throw new Exception('编辑失败');
                }
                Db::commit();
                return $this->buildSuccess([], '编辑成功');
            } catch(Exception $e) {
                Db::rollback();
                return $this->buildFailed(ReturnCode::UPDATE_FAILED, $e->getMessage());
            }
        } else {
            $grouplist = $this->auth->getGroups($info['id']);
            $groupids = [];
            foreach ($grouplist as $k => $v)
            {
                $groupids[] = $v['id'];
            }
            $this->assign("groupid", $groupids[0]);
            $this->assign('info', $info);
            return $this->fetch();
        }
    }

    /**
     * 删除管理员
     */
    public function del() {
        if ($this->isAjaxPost()) {
            $id = $this->request->param('id', 0);
            if (! $id) {
                return $this->buildFailed(ReturnCode::INVALID, '非法操作');
            }
            $res = Db::name('admin')->where(['id' => $id])->delete();
            if ($res === false) {
                return $this->buildFailed(ReturnCode::DELETE_FAILED, '删除失败');
            } else {
                 // 先移除所有权限
                model('AuthGroupAccess')->where('uid', $id)->delete();
                return $this->buildSuccess([]);
            }
        } else {
            return $this->buildFailed(ReturnCode::INVALID, '非法操作');
        }
    }
}