<?php
namespace app\admin\controller;

use think\Loader;
use think\Request;

class Card extends Base
{
    public function index() {
        if ($this->isAjaxGet()) {
            $filter = [
                'card_no'  => $this->request->param('card_no'),
                'card_type'  => $this->request->param('card_type'),
                'is_use' => $this->request->param('is_use'),
                'use_user_name' => $this->request->param('use_user_name'),
                'createname' => $this->request->param('createname'),
                'starttime' => $this->request->param('starttime'),
                'endtime' => $this->request->param('endtime')
            ];
            $model = model('Card')->getCardList($filter, $this->limit);

            $cardList = $model->toArray();
            $cardTypeNameArr = ['3day' => '三天卡','month' => '月卡', 'season' => '季卡', 'year' => '年卡', 'forever' => '终身卡'];
            foreach ($cardList['data'] as $key => $value) {
                $cardList['data'][$key]['createtime'] = date('Y-m-d H:i:s', $value['createtime']);
                $cardList['data'][$key]['use_time'] = $value['use_time'] > 0 ? date('Y-m-d H:i:s', $value['use_time']) : '-';
                $cardList['data'][$key]['card_type_name'] = $cardTypeNameArr[$value['card_type']];
            }

            $data = $cardList['data'];
            $count = $cardList['total'];
            return $this->buildTableSuccess($data, $count);
        } else {
            return $this->fetch();
        }
    }

    public function export() {
        Loader::import('PHPExcel.Classes.PHPExcel');
        Loader::import('PHPExcel.Classes.PHPExcel.IOFactory.PHPExcel_IOFactory');
        $str = Request::instance()->param('str');
        if (!empty($str)) {
            $params = json_decode($str);
            $filter = [
                'card_no'  => $params->card_no,
                'card_type'  => $params->card_type,
                'is_use' => $params->is_use,
                'use_user_name' => $params->use_user_name,
                'createname' => $params->createname,
                'starttime' => $params->starttime,
                'endtime' => $params->endtime
            ];
        } else {
            $filter = [
                'card_no'  => '',
                'card_type'  => '',
                'is_use' => '',
                'use_user_name' => '',
                'createname' => '',
                'starttime' => '',
                'endtime' => ''
            ];
        }

        $model = collection(model('Card')->exportCardList($filter));

        $cardList = $model->toArray();
        
        $cardTypeNameArr = ['3day' => '三天卡','month' => '月卡', 'season' => '季卡', 'year' => '年卡', 'forever' => '终身卡'];
        foreach ($cardList as $key => $value) {
            $cardList[$key]['card_type'] = $cardTypeNameArr[$value['card_type']];
            $cardList[$key]['is_use'] =  $value['is_use'] == 1 ? '已使用' : '未使用';
            $cardList[$key]['use_time'] = $value['use_time'] > 0 ? date('Y-m-d H:i:s', $value['use_time']) : '-';
        }
        $row_title = ['ID', '卡密', '类型', '使用状态', '使用者', '使用时间', '持有者'];
        array_unshift($cardList, $row_title);

        $date = date('Y-m-d H i');
        $phpexcel = new \PHPExcel();
        $sheet    = $phpexcel->getActiveSheet();
        $sheet->setTitle("{$date}-卡密记录");
        $chr = [];
        for ($i='A'; $i<='Z'; $i++) {
            $chr[] = $i;
            if (sizeof($chr) >= sizeof($row_title)) break;
        }

        $i = 1;
        foreach ($cardList as $val) {
            $z = 0;
            foreach ($val as $k=>$v) {
                $sheet->setCellValue($chr[$z].$i, $v);
                $z++;
            }
            $i++;
        }

        $write = \PHPExcel_IOFactory::createWriter($phpexcel, 'Excel5');
        header("Pragma: public");
        header("Expires: 0");
        header("Cache-Control:must-revalidate, post-check=0, pre-check=0");
        header("Content-Type:application/force-download");
        header("Content-Type:application/vnd.ms-execl");
        header("Content-Type:application/octet-stream");
        header("Content-Type:application/download");
        header("Content-Disposition:attachment;filename={$date}-卡密记录.xls");
        header("Content-Transfer-Encoding:binary");
        header('Cache-Control: max-age=0');
        $write->save('php://output');
        exit;
    }
}
