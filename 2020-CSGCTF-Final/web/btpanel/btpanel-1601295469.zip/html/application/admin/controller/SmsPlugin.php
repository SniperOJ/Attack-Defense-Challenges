<?php
namespace app\admin\controller;

use think\Db;
use think\Exception;
use app\Common\Util\ReturnCode;

/*
// 阿里云短信配置
[
    ['conf_name' => 'accessKeyId', 'conf_key' => 'accessKeyId', 'conf_val' => ''],
    ['conf_name' => 'accessKeySecret', 'conf_key' => 'accessKeySecret', 'conf_val' => ''],
    ['conf_name' => '短信签名', 'conf_key' => 'signName', 'conf_val' => ''],
    ['conf_name' => '注册验证模板ID', 'conf_key' => 'registerTemplId', 'conf_val' => ''],
    ['conf_name' => '重置密码模板ID', 'conf_key' => 'findPassTemplId', 'conf_val' => '']
];
// 腾讯云短信配置
[
    ['conf_name' => 'appid', 'conf_key' => 'appid', 'conf_val' => ''],
    ['conf_name' => 'appkey', 'conf_key' => 'appkey', 'conf_val' => ''],
    ['conf_name' => '短信国家码', 'conf_key' => 'regionNo', 'conf_val' => '86'],
    ['conf_name' => '短信签名ID', 'conf_key' => 'signatureId', 'conf_val' => ''],
    ['conf_name' => '统一短信模板ID', 'conf_key' => 'verifyTemplId', 'conf_val' => '']
];
 */

/**
 * 直播接口设置
 */
class SmsPlugin extends Base
{
    /**
     * 无需鉴权的方法,但需要登录
     */
    protected $noNeedRight = [];
    
    public function index() {
        if ($this->isAjaxGet()) {
            $model = Db::name('sms_plugin')
            ->paginate($this->limit);

            $lists = $model->toArray();

            $data = $lists['data'];
            $count = $lists['total'];
            return $this->buildTableSuccess($data, $count);
        } else {
            return $this->fetch();
        }
    }

    public function edit($id = NULL) {
        $row = Db::name('sms_plugin')->where(['id' => $id])->find();
        if ($this->isAjaxPost()) {
            if (empty($row)) {
                return $this->buildFailed(ReturnCode::INVALID, '非法操作');
            }
            $params = $this->request->param();
            $data = [
                'name' => $params['name'],
                'description' => $params['description'],
                'config' => json_encode($params['config']),
                'is_effect' => $params['is_effect']
            ];

            Db::startTrans();
            try {
                $res = Db::name('sms_plugin')->where(['id' => $id])->update($data);
                if ($res === false) {
                    throw new Exception('编辑失败');
                }
                // 如果启用某个接口域名，则其它接口域名自动设为禁用
                if ($data['is_effect'] == 1) {
                    $res = Db::name('sms_plugin')->where('id', 'neq', $id)->update(['is_effect' => 0]);
                    if ($res === false) {
                        throw new Exception('编辑失败');
                    }
                }
                Db::commit();
                return $this->buildSuccess([], '编辑成功');
            } catch (Exception $e) {
                Db::rollback();
                return $this->buildFailed(ReturnCode::UPDATE_FAILED, $e->getMessage());
            }
        } else {
            if (empty($row)) {
                $this->error('非法操作');
            }
            $row['config'] = json_decode($row['config'], true);
            $this->assign('row', $row);
            return $this->fetch();
        }
    }
}
