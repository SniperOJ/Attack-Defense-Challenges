#!/bin/bash

# 在此编写修复漏洞的代码。
# Write the code to fix the vulnerability here.
# 例如：cp your_file /server/path
# for example: cp your_file /server/path

# 重启FLASK应用
# restart flask app
# 我不建议你修改下面的代码（因为经过测试，它们可以正确运行），但如果你认为有必要，你也可以修改。
# I do NOT recommend that you modify the code below(they will run correctly by testing), but you can also modify it if you think it is necessary.
ps -aux|grep -v grep|grep Flaskshop|awk '{print $2}'|xargs kill -9
python3 /var/www/Flaskshop/run.py > /dev/null 2>&1 &

