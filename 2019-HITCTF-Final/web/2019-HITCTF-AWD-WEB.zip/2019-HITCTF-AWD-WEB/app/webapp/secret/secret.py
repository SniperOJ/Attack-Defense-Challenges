from ..utils.utils import random_string

key = random_string()