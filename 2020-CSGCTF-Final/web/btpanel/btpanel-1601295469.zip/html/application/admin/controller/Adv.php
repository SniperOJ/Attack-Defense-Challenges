<?php
namespace app\admin\controller;

use think\Db;
use app\common\util\ReturnCode;

class Adv extends Base
{
    public function index()
    {
        if ($this->isAjaxGet()) {
            $filter = [
                'name'      => $this->request->param('name'),
                'position_id'      => $this->request->param('position_id')
            ];
            $model = Db::name('adv')
            ->alias('a')
            ->field([
                'a.id',
                'a.image',
                'a.name',
                'a.position_id',
                'a.link',
                'a.sort',
                'a.is_show',
                'a.createtime',
                'IFNULL( b.name, "无" )' => 'position_name'
            ])
            ->join('adv_position b','b.id=a.position_id', 'LEFT')
            ->where(function ($query) use (&$filter) {
                $where = $query->where('a.id', 'gt', 0);
                if ((bool)$filter['name']) {
                    $where->where('a.name', 'like', '%' . $filter['name'] . '%');
                }
                if ((bool)$filter['position_id']) {
                    $where->where('a.position_id', 'eq', $filter['position_id']);
                }
            })
            ->order('sort desc, id desc')
            ->paginate($this->limit);
            $advList = $model->toArray();
            foreach ($advList['data'] as $key => $value) {
                $advList['data'][$key]['createtime'] = date('Y-m-d H:i:s', $value['createtime']);
            }
            $data = $advList['data'];
            $count = $advList['total'];
            return $this->buildTableSuccess($data, $count);
        } else {
            return $this->fetch();
        }
    }

    public function add() {
        if ($this->isAjaxPost()) {
            $params = $this->request->param();
            if ($params['position_id'] == 2) {
                $info = Db::name('adv')->where(['position_id' => 2, 'is_deleted' => 0])->find();
                if (! empty($info)) {
                    return $this->buildFailed(ReturnCode::ADD_FAILED, '启动广告只能添加一个，已添加可编辑！');
                }
            }
            
            $data = [
                'name' => $params['name'],
                'position_id' => $params['position_id'],
                'link' => $params['link'],
                'image' => $params['image'],
                'sort' => $params['sort'],
                'is_show' => $params['is_show'],
                'create_by_id' => $this->adminInfo['id'],
                'createtime' => time()
            ];

            
            $id = Db::name('adv')->insertGetId($data);
            if ($id) {
                return $this->buildSuccess([]);
            } else {
                return $this->buildFailed(ReturnCode::ADD_FAILED, '添加失败');
            }
        } else {
            $positionList = Db::name('adv_position')->where(['is_deleted' => 0])->select();
            $this->assign('positionList', $positionList);
            return $this->fetch();
        }
    }

    public function edit() {
        $id = $this->request->param('id', 0);
        if (! $id) {
            $this->error('非法操作');
        }
        $info = Db::name('adv')->where(['id' => $id])->find();
        if (empty($info)) {
            $this->error('非法操作');
        }
        if ($this->isAjaxPost()) {
            $params = $this->request->param();

            $data = [
                'name' => $params['name'],
                'position_id' => $params['position_id'],
                'link' => $params['link'],
                'image' => $params['image'],
                'sort' => $params['sort'],
                'is_show' => $params['is_show']
            ];

            $res = Db::name('adv')->where(['id' => $id])->update($data);
            if ($res === false) {
                return $this->buildFailed(ReturnCode::ADD_FAILED, '编辑失败');
            } else {
                return $this->buildSuccess([]);
            }
        } else {
            $positionList = Db::name('adv_position')->where(['is_deleted' => 0])->select();
            $this->assign('positionList', $positionList);
            $this->assign('info', $info);
            return $this->fetch();
        }
    }

    public function del() {
        if ($this->isAjaxPost()) {
            $id = $this->request->param('id', 0);
            if (! $id) {
                return $this->buildFailed(ReturnCode::INVALID, '非法操作');
            }
            $res = Db::name('adv')->where(['id' => array('in', $id)])->delete();
            if ($res === false) {
                return $this->buildFailed(ReturnCode::ADD_FAILED, '删除失败');
            } else {
                return $this->buildSuccess([]);
            }
        } else {
            return $this->buildFailed(ReturnCode::INVALID, '非法操作');
        }
    }
  
    /**
     * 底部菜单广告位
     */
    public function film() {
        $advFilm = Db::name('config')->where(['group' => 'adv', 'name' => 'adv_film'])->value('value');
        $this->assign('advFilm', $advFilm);
        return $this->fetch();
    }
  
    /**
     * 更新卫视直播观看地址
     */
    public function updateFilm() {
        if ($this->isAjaxPost()) {
            $adv_film = $this->request->param('adv_film');
           
            $res = Db::name('config')
                ->where('group', 'eq', 'adv')
                ->where('name', 'eq', 'adv_film')
                ->update([
                    'value' => $adv_film
                ]);
            
            if ($res === false) {
                return $this->buildFailed(ReturnCode::UPDATE_FAILED, '保存失败');
            }
            return $this->buildSuccess([], '保存成功');
        } else {
            return $this->buildFailed(ReturnCode::INVALID, '非法操作');
        }
    }
  
  
    /**
     * vip影视
     */
    public function box_link() {
        $name = Db::name('box')->where(['id' => '1'])->value('name');
        $link = Db::name('box')->where(['id' => '1'])->value('link');
        $uid = Db::name('box')->where(['id' => '1'])->value('uid');
        $token = Db::name('box')->where(['id' => '1'])->value('token');
        $this->assign('name', $name);
        $this->assign('link', $link);
        $this->assign('uid', $uid);
        $this->assign('token', $token);
        return $this->fetch();
    }
    /**
     * 更新卫视直播观看地址
     */
    public function box_update() {
        if ($this->isAjaxPost()) {
          	$params = $this->request->param();
            $res = Db::name('box')
                ->where('id', 'eq', '1')
                ->update([
                    'name' => $params['name'],
                    'link' => $params['link'],
                    'uid' => $params['uid'],
                    'token' => $params['token']
                ]);
            
            if ($res === false) {
                return $this->buildFailed(ReturnCode::UPDATE_FAILED, '保存失败');
            }
            return $this->buildSuccess([], '保存成功');
        } else {
            return $this->buildFailed(ReturnCode::INVALID, '非法操作');
        }
    }
}
