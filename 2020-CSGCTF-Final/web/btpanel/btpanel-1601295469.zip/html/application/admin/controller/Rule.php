<?php
namespace app\admin\controller;

use think\Db;
use think\Cache;
use app\common\util\ReturnCode;
use app\common\library\Tree;

class Rule extends Base {
    /**
     * 无需鉴权的方法,但需要登录
     */
    protected $noNeedRight = [];

    protected $rulelist = [];

    public function _initialize() {
        parent::_initialize();
        $ruleList = Db::name('auth_rule')->order('weigh', 'desc')->select();
        Tree::instance()->init($ruleList);
        $this->rulelist = Tree::instance()->getTreeList(Tree::instance()->getTreeArray(0), 'title');
        $ruledata = [0 => '无'];
        foreach ($this->rulelist as $k => &$v)
        {
            if (!$v['ismenu'])
                continue;
            $ruledata[$v['id']] = $v['title'];
        }

        $this->assign('ruledata', $ruledata);
    }

    public function index() {
        if ($this->isAjaxGet()) {
            $data = $this->rulelist;
            return $this->buildTableSuccess($data, 0);
        } else {
            return $this->fetch();
        }
    }

    public function add() {
        if ($this->isAjaxPost()) {
            $param = $this->request->param();
            if ($param['ismenu'] == 1) {
                $param['type'] = 'menu';
            }
            $res = Db::name('auth_rule')->insert($param);
            if ($res === false) {
                return $this->buildFailed(ReturnCode::ADD_FAILED, '添加失败');
            }
            Cache::rm('__menu__');
            return $this->buildSuccess([], '添加成功');
        } else {
            return $this->fetch();
        }
    }

    /**
     * 编辑
     */
    public function edit($id = NULL)
    {
        $row = model('AuthRule')->get(['id' => $id]);

        if (!$row)
            return $this->buildFailed(ReturnCode::INVALID, '非法操作');
        if ($this->isAjaxPost()) {
            $params = $this->request->param();
            if ($params)
            {
                if (!$params['ismenu'] && !$params['pid'])
                {
                    return $this->buildFailed(ReturnCode::INVALID, '非菜单规则节点必须有父级');
                }
                //这里需要针对name做唯一验证
                // $ruleValidate = \think\Loader::validate('AuthRule');
                // $ruleValidate->rule([
                //     'name' => 'require|format|unique:AuthRule,name,' . $row->id,
                // ]);
                // $result = $row->validate()->save($params);
                $result = $row->save($params);
                if ($result === FALSE)
                {
                    return $this->buildFailed(ReturnCode::UPDATE_FAILED, $row->getError());
                }
                Cache::rm('__menu__');
                return $this->buildSuccess([], '编辑成功');
            }
            return $this->buildFailed(ReturnCode::INVALID, '非法操作');
        }
        $this->assign("row", $row);
        return $this->fetch();
    }

    /**
     * 删除
     */
    public function del($id = "")
    {
        if ($this->isAjaxPost()) {
            if ($id) {
                $delIds = [];
                foreach (explode(',', $id) as $k => $v)
                {
                    $delIds = array_merge($delIds, Tree::instance()->getChildrenIds($v, TRUE));
                }
                $delIds = array_unique($delIds);
                $count = model('AuthRule')->where('id', 'in', $delIds)->delete();
                if ($count)
                {
                    Cache::rm('__menu__');
                    return $this->buildSuccess([], '删除成功');
                }
            }
            return $this->buildFailed(ReturnCode::INVALID, '非法操作');
        } else {
            return $this->buildFailed(ReturnCode::INVALID, '非法操作');
        }
    }
}
