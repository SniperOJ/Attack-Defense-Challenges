<?php
namespace app\agent\controller;

use think\Db;
use think\Exception;
use think\Loader;
use think\Request;
use app\common\util\ReturnCode;

class User extends Base
{
    public function index() {
        if ($this->isAjaxGet()) {
            
            $filter = [
                'username'      => $this->request->param('username'),
                'invite_code'  => $this->request->param('invite_code'),
                'is_agent' => $this->request->param('is_agent'),
                'uid' => $this->agentInfo['id'],
                'agent_code' => $this->agentInfo['invite_code']
            ];
            $model = model('User')->getUserList($filter, $this->request->param('page'),  $this->request->param('limit'));
            $userList = $model;
            foreach ($userList as $key => $value) {
                $userList[$key]['createtime'] = date('Y-m-d H:i:s', $value['createtime']);
                $userList[$key]['logintime'] = $value['logintime'] > 0 ? date('Y-m-d H:i:s', $value['logintime']) : '-';
                $userList[$key]['is_end'] = $value['is_ever'] == 1 ? 0 : ($value['end_time'] > time() ? 0 : 1);
                $userList[$key]['end_time'] = date('Y-m-d H:i:s', $value['end_time']);
                $userList[$key]['referrer_name'] = Db::name('user')->alias('b')->where('b.invite_code', 'eq', $value['referrer'])->value('b.username');
                $userList[$key]['agent_nums'] =  Db::name('user')->alias('ag')->where('ag.is_agent', 'eq', 1)->where('ag.agent_code','eq',$value['invite_code'])->count('distinct ag.id');
            }

            $data = $userList;
            $count = model('User')->getUserList($filter,  $this->request->param('page'),  $this->request->param('limit'),true);
            return $this->buildTableSuccess($data, $count);
        } else {
            return $this->fetch();
        }
    }

    public function info() {
        $id = $this->request->param('id', 0);
        if (! $id) {
            $this->error('非法操作');
        }
        $info = Db::name('user')->where(['id' => $id])->find();
        if (! empty($info)) {
            $info['is_end'] = $info['end_time'] > time() ? 0 : 1;
            $info['agent_nums'] = Db::name('user')->where(['is_agent' => 1, 'agent_code' => $info['invite_code']])->count();
            $info['referrer'] = Db::name('user')->where(['invite_code' => $info['referrer']])->value('username');
            $info['agent_name'] = Db::name('user')->where(['invite_code' => $info['agent_code']])->value('username');
        }

        $this->assign('info', $info);
        return $this->fetch();
    }

    public function export() {
        Loader::import('PHPExcel.Classes.PHPExcel');
        Loader::import('PHPExcel.Classes.PHPExcel.IOFactory.PHPExcel_IOFactory');
        $str = Request::instance()->param('str');
        if (!empty($str)) {
            $params = json_decode($str);
            $filter = [
                'username'  => $params->username,
                'invite_code'  => $params->invite_code,
                'is_agent' => $params->is_agent,
                'uid' => $this->agentInfo['id'],
                'agent_code' => $this->agentInfo['invite_code']
            ];
        } else {
            $filter = [
                'username'  => '',
                'invite_code'  => '',
                'is_agent' => '',
                'uid' => $this->agentInfo['id'],
                'agent_code' => $this->agentInfo['invite_code']
            ];
        }

        $model = collection(model('User')->exportUserList($filter));

        $userList = $model->toArray();
        $newList = [];
        foreach ($userList as $key => $value) {
            $newList[] = [
                'id' => $value['id'],
                'username' => $value['username'],
                'nickname_code' => $value['nickname_code'],
                'invite_code' => $value['invite_code'],
                'referrer_name' => $value['referrer_name'],
                'agent_name' => $value['agent_name'],
                'is_agent' => $value['is_agent'] == 1 ? '是' : '否',
                'point_num' => $value['point_num'],
                'agent_nums' => $value['agent_nums'],
                'is_end' => $value['end_time'] > time() ? '否' : '是',
                'end_time' => date('Y-m-d H:i:s', $value['end_time']),
                'createtime' => date('Y-m-d H:i:s', $value['createtime']),
                'logintime' => $value['logintime'] > 0 ? date('Y-m-d H:i:s', $value['logintime']) : '-',
                'status' => $value['status'] == 1 ? '正常' : '禁用'
            ];
        }
        $row_title = ['ID', '用户名', '昵称', '推荐码', '推荐人', '上级代理', '是否代理', '积分', '下级代理数', '是否过期',  '到期时间', '注册时间', '最近登录时间', '状态'];
        array_unshift($newList, $row_title);

        $date = date('Y-m-d H i');
        $phpexcel = new \PHPExcel();
        $sheet    = $phpexcel->getActiveSheet();
        $sheet->setTitle("{$date}-会员记录");
        $chr = [];
        for ($i='A'; $i<='Z'; $i++) {
            $chr[] = $i;
            if (sizeof($chr) >= sizeof($row_title)) break;
        }

        $i = 1;
        foreach ($newList as $val) {
            $z = 0;
            foreach ($val as $k=>$v) {
                $sheet->setCellValue($chr[$z].$i, $v);
                $z++;
            }
            $i++;
        }

        $write = \PHPExcel_IOFactory::createWriter($phpexcel, 'Excel5');
        header("Pragma: public");
        header("Expires: 0");
        header("Cache-Control:must-revalidate, post-check=0, pre-check=0");
        header("Content-Type:application/force-download");
        header("Content-Type:application/vnd.ms-execl");
        header("Content-Type:application/octet-stream");
        header("Content-Type:application/download");
        header("Content-Disposition:attachment;filename={$date}-会员记录.xlsx");
        header("Content-Transfer-Encoding:binary");
        header('Cache-Control: max-age=0');
        $write->save('php://output');
        exit;
    }

    /**
     * 更新登录状态
     */
    public function updateStatus() {
        if ($this->isAjaxPost()) {
            $ids = $this->request->param('ids', 0);
            $type = $this->request->param('type', 0);
            if (! $ids) {
                return $this->buildFailed(ReturnCode::INVALID, '非法操作');
            }
            if ($type == 0) {
                $data['status'] = 0;
            } else if ($type == 1) {
                $data['status'] = 1;
            } else {
                return $this->buildFailed(ReturnCode::INVALID, '非法操作');
            }
            $res = Db::name('user')->where(['id' => array('in', $ids)])->update($data);
            if ($res === false) {
                return $this->buildFailed(ReturnCode::UPDATE_FAILED, '操作失败');
            } else {
                return $this->buildSuccess([]);
            }
        } else {
            return $this->buildFailed(ReturnCode::INVALID, '非法操作');
        }
    }

    /**
     * [关闭代理]
     */
    public function contact() {
        $id = $this->request->param('id', 0);
        if (! $id) {
            $this->error('非法操作');
        }
        // 不能关闭总代理
        if ($id == 1) {
            $this->error('不能关闭总代理');
        }
        $info = Db::name('user')->where(['id' => $id])->find();
        if (empty($info)) {
            $this->error('非法操作');
        }

        if ($this->isAjaxPost()) {
            $params = $this->request->param();

            $buyData['month_url'] = $params['month_url'];
            $buyData['season_url'] = $params['season_url'];
            $buyData['year_url'] = $params['year_url'];
            $buyData['forever_url'] = $params['forever_url'];
            $userBuyLinkInfo = Db::name('user_buy_link')->where(['user_id' => $info['id']])->find();
            if (empty($userBuyLinkInfo)) {
                $buyData['user_id'] = $info['id'];
                $buyData['createtime'] = time();
                $res = Db::name('user_buy_link')->insert($buyData);
            } else {
                $res = Db::name('user_buy_link')->where(['user_id' => $info['id']])->update($buyData);
            }
            if ($res === false) {
                return $this->buildFailed(ReturnCode::UPDATE_FAILED, '修改失败');
            }

            $data['is_online_buy'] = $params['is_online_buy'];
            $data['contact'] = $params['contact'];
            $data['desc'] = $params['desc'];
            $data['is_agent'] = 0; // 关闭代理
            
            $res = Db::name('user')->where(['id' => $info['id']])->update($data);
            if ($res === false) {
                return $this->buildFailed(ReturnCode::UPDATE_FAILED, '操作失败');
            } else {
                $this->updateAgentLog($id, 0);
                return $this->buildSuccess([]);
            }
        } else {
            $urlInfo = Db::name('user_buy_link')->where(['user_id' => $info['id']])->find();
            $this->assign('urlInfo', $urlInfo);
            $this->assign('info', $info);
            return $this->fetch();
        }
    }

    /**
     * 更新代理状态
     */
    public function updateAgent() {
        if ($this->isAjaxPost()) {
            $id = $this->request->param('id', 0);
            $type = $this->request->param('type', 0);
            if (! $id) {
                return $this->buildFailed(ReturnCode::INVALID, '非法操作');
            }
            $info = Db::name('user')->where(['id' => $id])->find();
            if (empty($info)) {
                return $this->buildFailed(ReturnCode::INVALID, '非法操作');
            }
            if ($type == 0) {
                $data['is_agent'] = 0;
            } else if ($type == 1) {
                $data['is_agent'] = 1;
                $data['is_ever_agent'] = 1;
            } else {
                return $this->buildFailed(ReturnCode::INVALID, '非法操作');
            }
            $res = Db::name('user')->where(['id' => $id])->update($data);
            if ($res === false) {
                return $this->buildFailed(ReturnCode::UPDATE_FAILED, '操作失败');
            } else {
                $this->updateAgentLog($id, $type);
                return $this->buildSuccess([]);
            }
        } else {
            return $this->buildFailed(ReturnCode::INVALID, '非法操作');
        }
    }

    /**
     * 充值
     */
    public function recharge()
    {
        $id = $this->request->param('id', 0);
        if (! $id) {
            $this->error('非法操作');
        }
        $agent_point_num = Db::name('user')->where(['id' => $this->agentInfo['id']])->value('point_num');
        $row = model('User')->get(['id' => $id]);
        if (empty($row)) {
            $this->error('非法操作');
        }
        if ($row->agent_code != $this->agentInfo['invite_code']) {
            $this->error('此用户不是您的下级代理，无权操作！');
        }
        if ($this->isAjaxPost()) {
            $params = $this->request->param();
            if ($params) {
                $point_num = $params['point_num'];
                if (!is_numeric($point_num)) {
                    return $this->buildFailed(ReturnCode::INVALID, '请输入正整数');
                }
                
                if ($point_num > $agent_point_num) {
                    return $this->buildFailed(ReturnCode::INVALID, '积分不足');
                }

                $data = [];
                $data['point_total'] = Db::raw('point_total+' . $point_num);
                $data['point_num'] = Db::raw('point_num+' . $point_num);

                // 启动事务
                Db::startTrans();
                try {
                    $result = $row->save($data);
                    if ($result === false) {
                        throw new Exception("发放积分失败，请重试！");
                    }
                    // 收支记录
                    $res = $this->userPointRecord($id, $point_num, $params['money']);
                    if (! $res) {
                        throw new Exception("发放积分失败，请重试！");
                    }

                    Db::commit();
                    return $this->buildSuccess([]);
                } catch(Exception $e) {
                    Db::rollback();
                    return $this->buildFailed(ReturnCode::INVALID, $e->getMessage());
                }
            }
            return $this->buildFailed(ReturnCode::INVALID, '非法操作');
        }  else {
            $this->assign('agent_point_num' , $agent_point_num);
            $this->assign('info', $row);
            return $this->fetch();
        }
    }

    /**
     * [setCardPoint 设置代理的提卡积分]
     */
    public function setCardPoint() {
        // 总代理才有权限操作
        if ($this->agentInfo['id'] != 1) {
            $this->error('您无权操作此功能');
        }
        $id = $this->request->param('id', 0);
        if (! $id) {
            $this->error('非法操作');
        }
        $info = Db::name('user')->where(['id' => $id])->find();
        if (empty($info)) {
            $this->error('非法操作');
        }
        if ($this->isAjaxPost()) {
            $params = $this->request->param();

            
            $data['month'] = $params['month'];
            $data['season'] = $params['season'];
            $data['year'] = $params['year'];
            $data['forever'] = $params['forever'];
            $data['create_by_id'] = $this->agentInfo['id'];

            $cardTakePointInfo = Db::name('card_take_point')->where(['user_id' => $info['id']])->find();
            if (empty($cardTakePointInfo)) {
                $data['user_id'] = $info['id'];
                $data['createtime'] = time();
                $res = Db::name('card_take_point')->insert($data);
            } else {
                $res = Db::name('card_take_point')->where(['user_id' => $info['id']])->update($data);
            }
            if ($res === false) {
                return $this->buildFailed(ReturnCode::UPDATE_FAILED, '操作失败');
            } else {
                return $this->buildSuccess([]);
            }
        } else {
            $cardTakePointInfo = Db::name('card_take_point')->where(['user_id' => $info['id']])->find();
            $this->assign('cardTakePointInfo', $cardTakePointInfo);
            $this->assign('info', $info);
            return $this->fetch('setCardPoint');
        }
    }

    /**
     * 记录
     */
    public function record() {
        if ($this->isAjaxGet()) {

            $filter = [
                'username' => $this->request->param('username'),
                'create_by_id' => $this->agentInfo['id']
            ];

            $model = model('UserPointRecord')->getRecordList($filter, $this->limit);
            $recordList = $model->toArray();

            foreach ($recordList['data'] as $key => $value) {
                $recordList['data'][$key]['createtime'] = date('Y-m-d H:i:s', $value['createtime']);
            }
            $data = $recordList['data'];
            $count = $recordList['total'];
            return $this->buildTableSuccess($data, $count);
        } else {
            return $this->fetch();
        }
    }

    public function exportRecordList() {
        Loader::import('PHPExcel.Classes.PHPExcel');
        Loader::import('PHPExcel.Classes.PHPExcel.IOFactory.PHPExcel_IOFactory');
        $str = Request::instance()->param('str');
        if (!empty($str)) {
            $params = json_decode($str);
            $filter = [
                'username' => $params->username,
                'create_by_id' => $this->agentInfo['id']
            ];
        } else {
            $filter = [
                'username' => '',
                'create_by_id' => $this->agentInfo['id']
            ];
        }

        $model = collection(model('UserPointRecord')->exportRecordList($filter));

        $recordList = $model->toArray();

        $newList = [];
        foreach ($recordList as $key => $value) {
            $newList[] = [
                'id' => $value['id'],
                'to_user_name' => $value['to_user_name'],
                'use_type' => $value['use_type'] == 1 ? '充积分' : '提卡',
                'point_use' => $value['point_use'],
                'desc' => $value['desc'],
                'createtime' => date('Y-m-d H:i:s', $value['createtime'])
            ];
        }
        $row_title = ['ID', '目标帐户', '支出类型', '支出积分', '备注', '支出时间'];
        array_unshift($newList, $row_title);

        $date = date('Y-m-d H i');
        $phpexcel = new \PHPExcel();
        $sheet    = $phpexcel->getActiveSheet();
        $sheet->setTitle("{$date}-积分记录");
        $chr = [];
        for ($i='A'; $i<='Z'; $i++) {
            $chr[] = $i;
            if (sizeof($chr) >= sizeof($row_title)) break;
        }

        $i = 1;
        foreach ($newList as $val) {
            $z = 0;
            foreach ($val as $k=>$v) {
                $sheet->setCellValue($chr[$z].$i, $v);
                $z++;
            }
            $i++;
        }

        $write = \PHPExcel_IOFactory::createWriter($phpexcel, 'Excel5');
        header("Pragma: public");
        header("Expires: 0");
        header("Cache-Control:must-revalidate, post-check=0, pre-check=0");
        header("Content-Type:application/force-download");
        header("Content-Type:application/vnd.ms-execl");
        header("Content-Type:application/octet-stream");
        header("Content-Type:application/download");
        header("Content-Disposition:attachment;filename={$date}-积分记录.xlsx");
        header("Content-Transfer-Encoding:binary");
        header('Cache-Control: max-age=0');
        $write->save('php://output');
        exit;
    }

    /**
     * 收支记录
     */
    private function userPointRecord($id, $point_num, $money) {
        $belowAgentInfo = Db::name('user')->where(['id' => $id])->find();
        // 下级代理收入记录
        $record = [
            'user_id' => $id, // 下级代理id
            'type' => 1, // 收入
            'point_add' => $point_num,
            'money' => $money,
            'point_total' => $belowAgentInfo['point_total'],
            'point_num' => $belowAgentInfo['point_num'],
            'desc' => '上级代理充值',
            'create_by_type' => 2, // 代理
            'create_by_id' => $this->agentInfo['id'],
            'use_type' => 1, // 发放积分
            'createtime' => time()
        ];

        $res = Db::name('user_point_record')->insert($record);
        if (! $res) {
            return false;
        }
        // 代理减积分
        $res = Db::name('user')->where(['id' => $this->agentInfo['id']])->setDec('point_num', $point_num);
        if (! $res) {
            return false;
        }

        $agentInfo = Db::name('user')->where(['id' => $this->agentInfo['id']])->find();

        // 代理支出记录
        $record = [
            'user_id' => $this->agentInfo['id'], // 代理
            'type' => 2, // 支出
            'point_use' => $point_num,
            'money' => $money,
            'point_total' => $agentInfo['point_total'],
            'point_num' => $agentInfo['point_num'],
            'desc' => '给下级代理充值',
            'create_by_type' => 2, // 代理
            'create_by_id' => $this->agentInfo['id'],
            'use_type' => 1, // 发放积分
            'createtime' => time()
        ];

        $res = Db::name('user_point_record')->insert($record);
        if (! $res) {
            return false;
        }
        return true;
    }

    /**
     * 更新代理记录
     *
     */
    private function updateAgentLog($id, $type) {
        $desc = ($type == 1 ? '被设置为代理身份' : '被取消代理身份');
        // 更新记录
        $data = [
            'user_id' => $id,
            'type' => $type,
            'desc' => $desc,
            'create_by_type' => 2, // 代理
            'create_by_id' => $this->agentInfo['id'],
            'createtime' => time()
        ];
        Db::name('update_agent_log')->insert($data);
    }
}
