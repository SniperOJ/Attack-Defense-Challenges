<?php
namespace app\admin\model;

use think\Model;
use think\Db;

class CardTakeLog extends Model {

    // 表名
    // protected $name = 'user';

    /**
     * @param $filter
     * @param $order
     * @param $by
     * @param int $page_size
     * @return \think\Paginator
     */
    public function getUseRecordList($filter, $page_size = 10) {
        $result = $this->alias('a')
            ->field([
                'a.id',
                'a.card_type',
                'a.num',
                'a.point',
                'a.desc',
                'a.create_by_id',
                'a.createtime',
                'u.username' => 'createname',
            ])
            ->join('user u','u.id=a.create_by_id', 'LEFT')
            ->where('a.is_deleted', '0')
            ->where(function ($query) use (&$filter) {
                $where = $query->where('a.id', 'gt', 0);
                if ((bool)$filter['createname']) {
                    $where->where('u.username', 'like', '%' . $filter['createname'] . '%');
                }
                if ((bool)$filter['card_type']) {
                    $where->where('a.card_type', 'eq', $filter['card_type']);
                }
                if ((bool)$filter['starttime'] &&  (bool)$filter['endtime']) {
                    $where->whereTime('a.createtime', 'between', [strtotime($filter['starttime'] . ' 00:00:00'), strtotime($filter['endtime'] . ' 23:59:59')]);
                } else {
                    if ((bool)$filter['starttime']) {
                        $where->whereTime('a.createtime', '>=', strtotime($filter['starttime'] . ' 00:00:00'));
                    }
                    if ((bool)$filter['endtime']) {
                        $where->whereTime('a.createtime', '<=', strtotime($filter['endtime'] . ' 23:59:59'));
                    }
                }
            })
            ->order('a.id desc')
            ->paginate($page_size);

        return $result;
    }


    public function exportUseRecord($filter) {
        $result = $this->alias('a')
            ->field([
                'a.id',
                'a.card_type',
                'a.num',
                'a.point',
                'a.desc',
                'a.create_by_id',
                'a.createtime',
                'u.username' => 'createname',
            ])
            ->join('user u','u.id=a.create_by_id', 'LEFT')
            ->where('a.is_deleted', '0')
            ->where(function ($query) use (&$filter) {
                $where = $query->where('a.id', 'gt', 0);
                if ((bool)$filter['createname']) {
                    $where->where('u.username', 'like', '%' . $filter['createname'] . '%');
                }
                if ((bool)$filter['card_type']) {
                    $where->where('a.card_type', 'eq', $filter['card_type']);
                }
                if ((bool)$filter['starttime'] &&  (bool)$filter['endtime']) {
                    $where->whereTime('a.createtime', 'between', [strtotime($filter['starttime'] . ' 00:00:00'), strtotime($filter['endtime'] . ' 23:59:59')]);
                } else {
                    if ((bool)$filter['starttime']) {
                        $where->whereTime('a.createtime', '>=', strtotime($filter['starttime'] . ' 00:00:00'));
                    }
                    if ((bool)$filter['endtime']) {
                        $where->whereTime('a.createtime', '<=', strtotime($filter['endtime'] . ' 23:59:59'));
                    }
                }
            })
            ->select();

        return $result;
    }
}