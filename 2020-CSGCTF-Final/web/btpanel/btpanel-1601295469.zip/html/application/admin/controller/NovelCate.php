<?php
namespace app\admin\controller;

use think\Db;
use app\common\util\ReturnCode;
/**
 * 小说分类模块
 */
class NovelCate extends Base {
    public function index() {
        if ($this->isAjaxGet()) {
            $filter = [
                'title'      => $this->request->param('title')
            ];
            $model = Db::name('novel_cate')
            ->alias('a')
            ->field([
                'a.id',
                'a.title',
              	'a.image',
                'a.sort',
                'a.createtime',
                'a.updatetime'
            ])
            ->where(function ($query) use (&$filter) {
                $where = $query->where('a.id', 'gt', 0);
                if ((bool)$filter['title']) {
                    $where->where('a.title', 'like', '%' . $filter['title'] . '%');
                }
            })
            ->order('a.sort desc, a.id asc')
            ->paginate($this->limit);
            $list = $model->toArray();
            foreach ($list['data'] as $key => $value) {
                $list['data'][$key]['createtime'] = date('Y-m-d H:i:s', $value['createtime']);
                $list['data'][$key]['updatetime'] = date('Y-m-d H:i:s', $value['updatetime']);
            }
            $data = $list['data'];
            $count = $list['total'];
            return $this->buildTableSuccess($data, $count);
        } else {
            return $this->fetch();
        }
    }

    public function add() {
        if ($this->isAjaxPost()) {
            $params = $this->request->param();

            $data = [
                'title' => $params['title'],
              	'image' => $params['image'],
                'sort' => $params['sort'],
                'create_by_id' => $this->adminInfo['id'],
                'createtime' => time(),
                'updatetime' => time()
            ];

            $result = $this->validate($data,
                [
                    'title' => 'require|max:500|unique:novel_cate,title'
                ],
                [
                    'title.require'  =>  '分类名称不能为空',
                    'title.unique'  =>  '此分类名称已存在',
                ]
            );
            if(true !== $result){
                // 验证失败 输出错误信息
                return $this->buildFailed(ReturnCode::ADD_FAILED, $result);
            }

            $id = Db::name('novel_cate')->insertGetId($data);
            if ($id) {
                return $this->buildSuccess([]);
            } else {
                return $this->buildFailed(ReturnCode::ADD_FAILED, '添加失败');
            }
        } else {
            return $this->fetch();
        }
    }

    public function edit() {
        $id = $this->request->param('id', 0);
        if (! $id) {
            $this->error('非法操作');
        }
        $info = Db::name('novel_cate')->where(['id' => $id])->find();
        if (empty($info)) {
            $this->error('非法操作');
        }
        if ($this->isAjaxPost()) {
            $params = $this->request->param();

            $data = [
                'title' => $params['title'],
              	'image' => $params['image'],
                'sort' => $params['sort'],
                'updatetime' => time()
            ];

            $result = $this->validate($data,
                [
                    'title' => 'require|max:500|unique:novel_cate,title,' . $id . ',id'
                ],
                [
                    'title.require'  =>  '分类名称不能为空',
                    'title.unique'  =>  '此分类名称已存在',
                ]
            );
            if(true !== $result){
                // 验证失败 输出错误信息
                return $this->buildFailed(ReturnCode::ADD_FAILED, $result);
            }

            $res = Db::name('novel_cate')->where(['id' => $id])->update($data);
            if ($res === false) {
                return $this->buildFailed(ReturnCode::ADD_FAILED, '编辑失败');
            } else {
                return $this->buildSuccess([]);
            }
        } else {
            $this->assign('info', $info);
            return $this->fetch();
        }
    }

    public function del() {
        if ($this->isAjaxPost()) {
            $id = $this->request->param('id', 0);
            if (! $id) {
                return $this->buildFailed(ReturnCode::INVALID, '非法操作');
            }
            $nums = Db::name('novel')->where(['cate_id' => array('in', $id)])->count();
            if ($nums > 0) {
                return $this->buildFailed(ReturnCode::INVALID, '请先删除分类下的内容，再删除分类');
            }

            $res = Db::name('novel_cate')->where(['id' => array('in', $id)])->delete();
            if ($res === false) {
                return $this->buildFailed(ReturnCode::DELETE_FAILED, '删除失败');
            } else {
                return $this->buildSuccess([]);
            }
        } else {
            return $this->buildFailed(ReturnCode::INVALID, '非法操作');
        }
    }
}