<?php
namespace app\admin\model;

use think\Model;
use think\Db;

class Tv extends Model {

    /**
     * @param $filter
     * @param int $page_size
     * @return \think\Paginator
     */
    public function getTvList($filter, $page_size = 10) {
        $result = Db::name('tv_cate')
            ->alias('a')
            ->field([
                'a.id',
                'a.title',
                'a.image',
                'a.link',
                'a.sort'
            ])
            ->where(function ($query) use (&$filter) {
                $where = $query->where('a.id', 'gt', 0);
                /*if ((bool)$filter['title']) {
                    $where->where('a.title', 'like', '%' . $filter['title'] . '%');
                }
                if ((bool)$filter['cate_name']) {
                    $where->where('b.title', 'like', '%' . $filter['cate_name'] . '%');
                }*/
            })
            ->order('sort asc')
            ->paginate($page_size);
        return $result;
    }

}