<?php
namespace app\agent\model;

use think\Model;
use think\Db;

class Card extends Model {

    // 表名
    // protected $name = 'card';

    /**
     * [卡密列表]
     */
    public function getCardList($filter, $page_size = 10) {
        $result = $this->alias('c')
            ->field([
                'c.id',
                'c.card_no',
                'c.card_type',
                'c.is_use',
                'c.user_id',
                'c.use_time',
                'c.createtime',
                'IFNULL( u.username, "无" )' => 'use_user_name'
            ])
            ->join('user u', 'u.id=c.user_id', 'LEFT')
            ->where(function ($query) use (&$filter) {
                $where = $query->where('c.id', 'gt', 0);
                if ((bool)$filter['create_by_id']) {
                    $where->where('c.create_by_id', 'eq', $filter['create_by_id']);
                }
                if ((bool)$filter['card_no']) {
                    $where->where('c.card_no', 'eq', $filter['card_no']);
                }
                if ((bool)$filter['card_type']) {
                    $where->where('c.card_type', 'eq', $filter['card_type']);
                }
                if (in_array($filter['is_use'], ['0', '1'])) {
                    $where->where('c.is_use', 'eq', $filter['is_use']);
                }
                if ((bool)$filter['username']) {
                    $where->where('u.username', 'like', '%' . $filter['username'] . '%');
                }
            })
            ->order('c.id desc')
            ->paginate($page_size);
        return $result;
    }

    /**
     * [导出卡密]
     */
    public function exportCardList($filter) {
        $result = $this->alias('c')
            ->field([
                'c.id',
                'c.card_no',
                'c.card_type',
                'c.is_use',
                'c.user_id',
                'c.use_time',
                'c.createtime',
                'IFNULL( u.username, "无" )' => 'use_user_name'
            ])
            ->join('user u', 'u.id=c.user_id', 'LEFT')
            ->where(function ($query) use (&$filter) {
                $where = $query->where('c.id', 'gt', 0);
                if ((bool)$filter['create_by_id']) {
                    $where->where('c.create_by_id', 'eq', $filter['create_by_id']);
                }
                if ((bool)$filter['card_no']) {
                    $where->where('c.card_no', 'eq', $filter['card_no']);
                }
                if ((bool)$filter['card_type']) {
                    $where->where('c.card_type', 'eq', $filter['card_type']);
                }
                if (in_array($filter['is_use'], ['0', '1'])) {
                    $where->where('c.is_use', 'eq', $filter['is_use']);
                }
                if ((bool)$filter['username']) {
                    $where->where('u.username', 'like', '%' . $filter['username'] . '%');
                }
            })
            // ->order('a.'.$order, strtoupper($by))
            ->select();

        return $result;
    }
}