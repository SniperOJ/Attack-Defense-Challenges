#!/usr/bin/env python
# encoding: utf-8

import random
import string
import hashlib
import hmac
import pickle
import base64

class HMAC_Pickler:
    def __init__(self, secret_key, seperator="|"):
        self.secret_key = secret_key
        self.seperator = seperator

    def digital_signature(self, data):
        signer = hmac.new(self.secret_key)
        signer.update(data)
        return signer.hexdigest()

    def loads(self, data):
        sign = data[:32]
        p = base64.b64decode(data[32+len(self.seperator):])
        assert sign == self.digital_signature(p), ("Data is tampered by someone.")
        return pickle.loads(p)

    def dumps(self, obj):
        p = pickle.dumps(obj)
        sign = self.digital_signature(p)
        return "%s%s%s" % (sign, self.seperator, str(base64.b64encode(p), encoding="utf-8"))

def md5(data):
    return hashlib.md5(bytes(data, encoding="utf-8")).hexdigest()

def random_string(length=0x10, charset=string.ascii_letters + string.digits):
    return "".join([random.choice(charset) for i in range(length)])
