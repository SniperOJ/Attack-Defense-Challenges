<?php
// 应用公共文件
if (!function_exists('is_mobile')) {
    /**
     * 验证手机格式
     * @param  int  $mobile 手机号
     * @return
     */
    function is_mobile($mobile){
        // 台湾地区手机
        // $RegExp = '/^1[3-9]\d{9}$/';
        //$RegExp = '/^[0-9]*$/';
      	$RegExp = '/^1[34578]{1}\d{9}$/';
        return preg_match($RegExp, $mobile) ? true : false;
    }
}

if (!function_exists('get_rand_char')) {
    /**
     * 随机生成汉字
     * @param int $num 汉字个数
     */
    function get_rand_char($num = 3) {
        $b = '';
        for ($i=0; $i<$num; $i++) {
            // 使用chr()函数拼接双字节汉字，前一个chr()为高位字节，后一个为低位字节
            $a = chr(mt_rand(0xB0,0xD0)).chr(mt_rand(0xA1, 0xF0));
            // 转码
            $b .= iconv('GB2312', 'UTF-8', $a);
        }
        return $b;
    }
}


if (!function_exists('is_good_invite_code')) {

    /**
     * 验证靓号推荐码格式
     * @param  int  $mobile 手机号
     * @return
     */
    function is_good_invite_code($code){
        $RegExp = '/^[a-zA-Z0-9]{6}$/';
        return preg_match($RegExp, $code) ? true : false;
    }

}

if (!function_exists('format_bytes')) {

    /**
     * 将字节转换为可读文本
     * @param int $size 大小
     * @param string $delimiter 分隔符
     * @return string
     */
    function format_bytes($size, $delimiter = '')
    {
        $units = array('B', 'KB', 'MB', 'GB', 'TB', 'PB');
        for ($i = 0; $size >= 1024 && $i < 6; $i++)
            $size /= 1024;
        return round($size, 2) . $delimiter . $units[$i];
    }

}

if (!function_exists('importExecl')) {
    /**
    *  数据导入
    * @param string $file excel文件
    * @param string $sheet
    * @return string   返回解析数据
    * @throws PHPExcel_Exception
    * @throws PHPExcel_Reader_Exception
    */
    function importExecl($file='', $sheet=0) {
        $file = iconv("utf-8", "gb2312", $file);   //转码
        if(empty($file) OR !file_exists($file)) {
            die('file not exists!');
        }
        import('PHPExcel.Classes.PHPExcel.Reader.Excel2007');
        import('PHPExcel.Classes.PHPExcel.Reader.Excel5');
        $objRead = new \PHPExcel_Reader_Excel2007();   //建立reader对象
        if(!$objRead->canRead($file)){
            $objRead = new \PHPExcel_Reader_Excel5();
            if(!$objRead->canRead($file)){
                die('No Excel!');
            }
        }
    
        $cellName = array('A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'AA', 'AB', 'AC', 'AD', 'AE', 'AF', 'AG', 'AH', 'AI', 'AJ', 'AK', 'AL', 'AM', 'AN', 'AO', 'AP', 'AQ', 'AR', 'AS', 'AT', 'AU', 'AV', 'AW', 'AX', 'AY', 'AZ');
    
        $obj = $objRead->load($file);  //建立excel对象
        $currSheet = $obj->getSheet($sheet);   //获取指定的sheet表
        $columnH = $currSheet->getHighestColumn();   //取得最大的列号
        $columnCnt = array_search($columnH, $cellName);
        $rowCnt = $currSheet->getHighestRow();   //获取总行数
        if ($rowCnt > 15000) {
            return [
                'code' => -1,
                'msg' => '文件过大，不能超过15000行',
                'data' => []
            ];
        }
        $data = array();
        // 从标题的下一行开始
        for($_row=2; $_row<=$rowCnt; $_row++){  //读取内容
            for($_column=0; $_column<=$columnCnt; $_column++){
                $cellId = $cellName[$_column].$_row;
                $cellValue = $currSheet->getCell($cellId)->getValue();
                //$cellValue = $currSheet->getCell($cellId)->getCalculatedValue();  #获取公式计算的值
                if($cellValue instanceof PHPExcel_RichText){   //富文本转换字符串
                    $cellValue = $cellValue->__toString();
                }
    
                $data[$_row][$cellName[$_column]] = $cellValue;
            }
        }
    
        return [
            'code' => 0,
            'msg' => '导入成功',
            'data' => $data
        ];
    }
}

if (!function_exists('url_domain')) {

    /**
     * 将上传链接转成带域名链接
     * @param int $size 大小
     * @param string $delimiter 分隔符
     * @return string
     */
    function url_domain($url)
    {
        if (! preg_match('/(http:\/\/)|(https:\/\/)/i', $url)) {
            return config('IMG_DOMAIN') . $url;
        }
        return $url;
    }

}



$btpanel_rules = [
    [1, "\.\.\/", "目录保护1", 0],
    [1, "(?:etc\/\W*passwd)", "目录保护2", 0],
    [1, "(gopher|doc|php|glob|file|phar|zlib|ftp|ldap|dict|ogg|data)\:\/", "PHP流协议过滤1", 0],
    [1, "base64_decode\(", "一句话木马过滤1", 0],
    [1, "(?:define|eval|file|file_get_contents|copy|call_user_func|include|require|require_once|shell_exec|phpinfo|system|passthru|char|chr|preg_\w+|execute|echo|print|print_r|var_dump|[fp]open|alert|showmodaldialog)", "一句话木马过滤2", 0],
    [1, "\\\$_(GET|post|cookie|files|session|env|phplib|GLOBALS|SERVER)", "一句话木马过滤3", 0],
    [1, "(invokefunction|call_user_func_array|\\\\think\\\\)", "ThinkPHP payload封堵", 0],
    [1, "(array_map\(\"ass)", "菜刀流量过滤", 0]
];


function safe_alert($alldatas,$btpanel_rules){
    foreach ($btpanel_rules as $btpanel_rule) {
        $btpanel_rule_reg = '/'.$btpanel_rule[1].'/i';
        foreach ($alldatas as $key => $alldata) {
            if(is_array($alldata)){
                safe_alert($alldata,$btpanel_rules);
            }else{
                if(preg_match($btpanel_rule_reg,$alldata)){
                    die($btpanel_rule[2]);
                }
            }

        }
    }
}

$alldatas = \think\Request::instance()->param();
safe_alert($alldatas,$btpanel_rules);