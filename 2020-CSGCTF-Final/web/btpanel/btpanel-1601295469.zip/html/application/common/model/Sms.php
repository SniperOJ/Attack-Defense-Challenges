<?php
namespace app\common\model;

use think\Model;

/**
 * 短信验证码
 */
class Sms Extends Model
{

}
