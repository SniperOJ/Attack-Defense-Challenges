#/usr/bin/env python
# encoding:utf-8

from webapp.utils import utils
import os

basedir = os.path.abspath(os.path.dirname(__file__))

class Config(object):
    MAIL_SERVER = 'smtp.qq.com'
    MAIL_PORT= 587
    MAIL_USE_TLS = True
    MAIL_USERNAME = os.environ.get('MAIL_USERNAME')
    MAIL_PASSWORD = os.environ.get('MAIL_PASSWORD')
    FLASKY_MAIL_SUBJECT_PREFIX = '[Flasky]'
    FLASKY_MAIL_SENDER = os.environ.get('MAIL_USERNAME')
    UPLOAD_FOLDER = os.getcwd()+'/webapp/static/headimg/'
    UPLOAD_PHOTOS_FOLDER=os.getcwd()+'/webapp/static/picture/'
    SAVEPIC = 'webapp/static/savepic/'
    UPLOADED_PHOTOS_DEST =  os.path.join(os.getcwd(),'static/upload/image')
    SQLALCHEMY_DATABASE_URI = "mysql+pymysql://ctf:123456@127.0.0.1:3306/ctf?charset=utf8"
    SECRET_KEY = 'welcome to 2019-HITCTF, enjoy your vulnerabilies!'
    path = os.getcwd() + "/.secret"
    if not os.path.exists(path):
        with open(path, "wb") as f:
            f.write(random_string(4))
    SERIALIZER_SECRET_KEY = open(path, "rb").read().strip()
    @staticmethod
    def init_app(app):
        pass

class ProdConfig(Config):
    DEBUG = False

class DevConfig(Config):
    DEBUG = True
