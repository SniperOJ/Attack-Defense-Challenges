<?php
namespace app\admin\controller;

use think\Controller;
use think\Session;
use think\Db;
use think\Request;
use app\common\util\ReturnCode;
use app\admin\library\Auth;

class Base extends Controller
{
    /**
     * 权限控制类
     * @var Auth
     */
    protected $auth = null;

    protected $adminInfo;

    // 每页条数，默认为10
    protected $limit = 10;

    /**
     * 无需登录的方法
     */
    protected $noNeedLogin = [];

    /**
     * 无需鉴权的方法,但需要登录
     */
    protected $noNeedRight = [];

    public function _initialize() {

        $modulename = $this->request->module();
        $controllername = strtolower($this->request->controller());
        $actionname = strtolower($this->request->action());

        $path = str_replace('.', '/', $controllername) . '/' . $actionname;
        
        $this->auth = Auth::instance();

        if (! $this->match($this->noNeedLogin)) {
            // 需要登录，则判断是否登录
            if (! $this->isLogin()) {
                $this->error('请先登录', url('Admin/Login/index'));
            }

            // 判断是否需要验证权限
            if (!$this->match($this->noNeedRight)) {
                // 判断控制器和方法判断是否有对应权限
                if (!$this->auth->check($path)) {
                    $this->error('没有权限进行此操作');
                }
            }
        }
        $adminInfo = Session::get('admin');
        if ($adminInfo) {
            $this->adminInfo = $adminInfo;
            $this->assign('adminInfo', $adminInfo);
        }
       
        $this->limit = $this->request->param('limit', 10, 'intval');
        $sitename = Db::name('config')->where(['group' => 'basic', 'name' => 'sitename'])->value('value');
        $this->assign('sitename', $sitename);
    }

    protected function buildSuccess($data, $msg = '操作成功', $code = ReturnCode::SUCCESS) {
        $return = [
            'code' => $code,
            'msg'  => $msg,
            'data' => $data
        ];

        return json($return);
    }

    protected function buildTableSuccess($data, $count, $msg = '操作成功', $code = ReturnCode::SUCCESS) {
        $return = [
            'code' => $code,
            'count' => $count,
            'msg'  => $msg,
            'data' => $data
        ];

        return json($return);
    }

    protected function buildFailed($code, $msg, $data = []) {
        $return = [
            'code' => $code,
            'msg'  => $msg,
            'data' => $data
        ];

        return json($return);
    }

    protected function isAjaxGet() {
        return ($this->request->isAjax() && $this->request->isGet()) ? true : false;
    }

    protected function isAjaxPost() {
        return ($this->request->isAjax() && $this->request->isPost()) ? true : false;
    }

    /**
     * 检测当前控制器和方法是否匹配传递的数组
     *
     * @param array $arr 需要验证权限的数组
     * @return boolean
     */
    private function match($arr = []) {
        $request = Request::instance();
        $arr = is_array($arr) ? $arr : explode(',', $arr);
        if (!$arr)
        {
            return FALSE;
        }
        $arr = array_map('strtolower', $arr);
        // 是否存在
        if (in_array(strtolower($request->action()), $arr) || in_array('*', $arr))
        {
            return TRUE;
        }

        // 没找到匹配
        return FALSE;
    }

    /**
     * 检验是否已经登录
     */
    private function isLogin() {
        $adminInfo = Session::get('admin');
        if (empty($adminInfo)) {
            return false;
        }
        return true;
    }
}
