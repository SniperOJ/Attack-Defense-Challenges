drop database if exists `ctf`;
create database ctf;
use ctf;
-- MySQL dump 10.13  Distrib 5.7.27, for Linux (x86_64)
--
-- Host: localhost    Database: ctf
-- ------------------------------------------------------
-- Server version	5.7.27-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `alembic_version`
--

DROP TABLE IF EXISTS `alembic_version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alembic_version` (
  `version_num` varchar(32) NOT NULL,
  PRIMARY KEY (`version_num`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alembic_version`
--

LOCK TABLES `alembic_version` WRITE;
/*!40000 ALTER TABLE `alembic_version` DISABLE KEYS */;
INSERT INTO `alembic_version` VALUES ('a129fe49f35d');
/*!40000 ALTER TABLE `alembic_version` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comment`
--

DROP TABLE IF EXISTS `comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `text` text,
  `date` datetime DEFAULT NULL,
  `post_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `post_id` (`post_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `comment_ibfk_1` FOREIGN KEY (`post_id`) REFERENCES `post` (`id`),
  CONSTRAINT `comment_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comment`
--

LOCK TABLES `comment` WRITE;
/*!40000 ALTER TABLE `comment` DISABLE KEYS */;
/*!40000 ALTER TABLE `comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `messageboard`
--

DROP TABLE IF EXISTS `messageboard`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `messageboard` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `text` text,
  `timestamp` datetime DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `messageboard_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `messageboard`
--

LOCK TABLES `messageboard` WRITE;
/*!40000 ALTER TABLE `messageboard` DISABLE KEYS */;
/*!40000 ALTER TABLE `messageboard` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `myfeeling`
--

DROP TABLE IF EXISTS `myfeeling`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `myfeeling` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `text` text,
  `user_id` int(11) DEFAULT NULL,
  `timestamp` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `myfeeling_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `myfeeling`
--

LOCK TABLES `myfeeling` WRITE;
/*!40000 ALTER TABLE `myfeeling` DISABLE KEYS */;
/*!40000 ALTER TABLE `myfeeling` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `photos`
--

DROP TABLE IF EXISTS `photos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `photos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `timestamp` datetime DEFAULT NULL,
  `pic_url` text,
  `description` text,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `photos_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `photos`
--

LOCK TABLES `photos` WRITE;
/*!40000 ALTER TABLE `photos` DISABLE KEYS */;
/*!40000 ALTER TABLE `photos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `post`
--

DROP TABLE IF EXISTS `post`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `post` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `subtitle` varchar(255) DEFAULT NULL,
  `text` text,
  `publish_date` datetime DEFAULT NULL,
  `private` tinyint(1) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `body_html` text,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `post_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `post`
--

LOCK TABLES `post` WRITE;
/*!40000 ALTER TABLE `post` DISABLE KEYS */;
INSERT INTO `post` VALUES (1,'《瞭望》新闻周刊刊发周玉校长专访：规格严格 建设“尖端”强校','2020年哈尔滨工业大学100周年校庆','![](/image/MjEzYTA2YzMzNGFhNTg4YWQxZjEyMjA4MTMwMDQxMDguanBn)\r\n\r\n哈工大报讯（报宣）10月26日，《瞭望》新闻周刊专访我校校长周玉院士，以《规格严格 建设“尖端”强校》为题，以4个专版报道我校办学理念与办学成果。报道文章在新华社客户端刊发后引起广泛关注，截至目前文章浏览量已超过131万。\r\n\r\n报道全文如下：\r\n\r\n\r\n\r\n哈尔滨工业大学校长、中国工程院院士周玉：规格严格 建设“尖端”强校\r\n\r\n文 |《瞭望》新闻周刊记者 杨思琪\r\n\r\n\r\n\r\n◇大学不在大，而在学；学科不在全，而在精、优、特。办大学是办特色、创优势、求卓越、出精品，这是我们始终坚持的理念，也是大学赢得竞争、走向卓越的关键。\r\n\r\n◇培养中国社会发展所需要的各类人才，以应对经济社会高质量发展对人才的需求；解决重大社会、科技和工程技术问题，为中国乃至世界社会经济发展做出重要贡献。这是新时代中国高校的使命，也是“双一流”建设的最终目的。\r\n\r\n\r\n\r\n![](/image/OTVkMDNhNzYxYzg5MjRlNGZlNDc0MjlmOTBkYTg4ZWEuanBn)\r\n\r\n\r\n一所高校的特色是在漫长办学历程中积淀而成的，既决定着学校的风格与方位，又与人才培养质量、科研成果水平密不可分。\r\n\r\n从扎根边疆、艰苦创业，将毕生奉献给共和国工业化事业的“八百壮士”，到为新中国航天事业写下浓墨重彩的“航天人”，地处“冰城”的哈尔滨工业大学始终与国家发展同向同行，形成了“立足航天、服务国防、长于工程”的鲜明品格。\r\n\r\n2020年，哈尔滨工业大学将迎来建校百年。哈工大校长、中国工程院院士周玉日前接受《瞭望》新闻周刊专访时表示，哈工大将始终牢记“赶考”初心、强国使命、育人根本，以争创世界一流大学、一流学科的责任感和紧迫感，向着“中国特色、世界一流、哈工大规格”的百年强校奋进。\r\n\r\n红色气质百年传承\r\n\r\n《瞭望》：作为一名哈工大人，你如何理解百年哈工大走过的风雨历程？新时代的哈工大又该怎样继承和发扬这种优良传统？\r\n\r\n周玉：哈尔滨工业大学1920年建校，原本是隶属于中长铁路的一所专业高校。新中国成立初期，国家各项建设刚刚起步，百废待兴。哈工大作为新中国学习苏联的样板学校，开始肩负起推动旧教育制度改革、实现社会主义工业化的使命。\r\n\r\n20世纪50年代，800多名青年师生响应国家号召，从祖国各地齐聚哈工大。短短十余年时间里，他们创办了24个新专业，一个基本适应当时国民经济建设需要，以机电、电气、土木、工程经济等为主的专业教学体系基本建成。这支平均年龄只有27.5岁的教师队伍，就是后人常常提起的哈工大“八百壮士”。\r\n\r\n虽然扎根边疆，但哈工大人始终心系国家命运，刻苦攻关，甘于奉献，形成了“规格严格、功夫到家”的校训文化和“立足航天、服务国防”的学科氛围。\r\n\r\n哈工大是首批国家“211工程”“985工程”重点建设高校，学校一直把人才培养作为第一要务和中心工作，并逐渐探索出“厚基础、强实践、严过程、求创新”的人才培养模式，为国家国防、航天领域培养了大批基础理论功底扎实、工程实践能力强、具有团结协作精神的优秀人才。\r\n\r\n如今，哈工大已构建了本、硕、博贯通的人才培养体系，建设了“本研一体化”教学管理系统，支持学生自主跨学科、跨层次选课。鼓励学生尽早进实验室，成为课题组初级成员，搭上科研快车，在真刀实枪的科研实践中成长为拔尖创新人才。同时推广小班化、混合式教学，倡导互动式、研讨式教学，通过教学改革促进学习革命，不断提高教育教学质量。\r\n\r\n面向国家重大需求、面向国际科技前沿，哈工大形成了服务航天国防、引领创新发展的科研特色，为建设中国特色先进国防科技工业体系做出了卓越贡献。\r\n\r\n2018年度国家最高科学技术奖获得者，中国科学院院士、中国工程院院士刘永坦，早在20世纪80年代初就立志开创中国的新体制雷达。尽管这项研究风险大、周期长，但他数十年如一日，初衷不改，带领团队潜心攻关，最终打破国外技术垄断，成功研制成我国第一部新体制雷达，为祖国万里海疆装上“火眼金睛”。\r\n\r\n在哈工大，像刘永坦这样一心一意干事业的教师不胜枚举。从我国第一台智能下棋计算机诞生，到第一台点焊弧焊机器人亮相；从首颗由高校牵头自主研制的小卫星一飞冲天，到近百项技术助力“神舟”飞天、“嫦娥”探月；从空间机械手成功完成天宫二号人机协同在轨维修科学试验，到国际首次高轨卫星对地高速激光双向通信试验成功……一项项科研成果成功破解了我国科技事业发展面临的诸多关键核心技术。\r\n\r\n建校以来，30余万学子从哈工大出发奔赴祖国各大战线，他们把爱国化为具体的行动，把个人奋斗融入国家发展，把科研精神与家国情怀有机融合，为了祖国的需要奉献一切，这种精神在不断传递，成为哈工大的一种品质，也成为哈工大建设世界一流大学的不变底色。\r\n\r\n立足航天创造一流\r\n\r\n《瞭望》：站在即将建校百年的历史节点，哈工大制定实施的《哈尔滨工业大学一流大学建设方案》对百年强校建设意味着什么？学校又将如何有效推动落实？\r\n\r\n周玉：当前，世界经济大国对高等教育的投入越来越大，重视程度越来越高，许多国家都把办一流大学、培养拔尖创新人才作为实现国家发展、增强综合国力的战略举措，全球范围内的大学竞争明显加剧。\r\n\r\n我国依托高校布局了一批战略级科学研究中心，为高校瞄准国家目标、集聚科研人才、开展跨学科研究、实现跨越式发展提供了重要平台，也为高校建设“双一流”提供了加速器。\r\n\r\n在这种背景下，哈工大以建设“‘中国特色、世界一流、哈工大规格’的百年强校”为定位，以全面深化教育综合改革为抓手，以“汇聚一流、形成高峰；突出优势、彰显特色；创新机制、鼓励交叉；促进新兴、引领发展”为指导思想，制定实施了“2511”学科建设计划，以一流学科建设引领带动学校整体发展。\r\n\r\n“2511”学科建设计划是以位居国内前列、具备冲击世界一流条件的学科为基础，重点建设2个领先一级学科、5个优势学科群、1个特色学科群、1个交叉学科群，主要涉及力学、材料科学与工程等学科，覆盖环境科学与工程、计算机科学与技术、高端装备制造、航天科学与工程等学科群。\r\n\r\n哈工大注重加强学科规划与顶层设计，动态调整学科建设范围及支持力度，做好特色优势学科和新兴交叉学科的统筹协调发展。做好物理学院、数学学院顶层设计和发展规划，推动理工学科交叉融合。采取差异化发展策略，推动经管文法学科与航天、国防、工程交叉融合，持续巩固形成以工强文、以文促工、文理融通的良好局面。\r\n\r\n目前，数学、人工智能、网络空间安全、生物信息技术、可持续能源技术研究院、生命科学中心等都已成立，通过培育更多学科发展和学术研究的新增长点，力争在前沿交叉领域实现若干重大突破。\r\n\r\n在国际化建设方面，学校将继续推进与世界一流大学、一流学术机构和一流学者可持续、高水平、深层次的实质性合作，将国外优质教育资源有效融合到学科建设的全过程，共同进军科学技术前沿。\r\n\r\n《瞭望》：作为一所以航天为特色的高校，哈工大提出坚持“有所为、有所不为”的原则，建设航天科学与工程学科群。如何突出这一优势特色？\r\n\r\n周玉：大学不在大，而在学；学科不在全，而在精、优、特。办大学是办特色、创优势、求卓越、出精品，这是我们始终坚持的理念，也是大学赢得竞争、走向卓越的关键。\r\n\r\n哈工大主动立足航天、服务国防，于1987年成立了我国高校第一个航天学院，并逐步打造形成了多学科相互融合、共同服务航天事业的“大航天”格局，有百余项研究成果应用于航天国防各个领域，荣获“中国载人航天工程协作贡献奖”等多个奖项。\r\n\r\n在“双一流”建设中，哈工大将坚持“人才、学科、科研”三位一体协调发展，超前凝练新方向、谋划大项目、建设大平台，注重高水平科技人才、团队、项目培育的有效融合，着力提升原始创新能力、交叉融合能力和团队攻关能力，打造基础研究、关键技术攻关、重大工程实施、成果转化和产业化的完整链条，实现从被动跟踪到主动引领的跨越式转变，推进特色优势学科的加速、升级、提高。\r\n\r\n针对制约我国科技、经济发展以及航天等重大战略需求的核心关键技术研究，产出一批重大创新成果，打造一批善于协同攻关、奉献担当的创新团队，努力建设成为我国航天国防和工程等领域重大科研方向的“策源地”“聚集地”和“孵化器”。\r\n\r\n我们还将围绕“航天强国”“网络强国”等国家重大战略，以高水平科研创新平台建设、重大标志项目实施等重大任务为抓手，建设若干具有集成优势的高水平特色新型智库，支持培养一批高端智库人才和咨询研究团队。\r\n\r\n改革创新汇聚人才\r\n\r\n《瞭望》：在东北振兴发展背景下，哈工大在加强人才队伍建设方面采取了哪些举措？是如何培养拔尖创新人才、提升科研水平的？\r\n\r\n周玉：“致天下之治者在人才。”哈工大始终把师资队伍建设作为重大战略工作来对待。经过多年探索，哈工大走出了一条“以自己培养为主、稳引培并举”的人才建设之路，努力打造引高贤的宝地、干事业的高地、聚人心的福地。\r\n\r\n一是持续建设并完善分类多元评价体系。通过分类设岗、分类聘任、分类评价等破“五唯”的实招硬招，设置了教学科研并重型、教学为主型、科研为主型、创新创业型和教学科研支持型5种类型的教师岗位。通过“以人为本、人尽其才、才尽其用”的人才管理机制，支持和鼓励广大教师根据自身的特点和潜能合理定位，明确发展目标和方向，让各类人才各得其所，发挥人才队伍建设的“长板效应”。\r\n\r\n二是优化教师岗位长聘准聘机制，搭建助推优秀人才特别是青年人才发展的成长阶梯，鼓励优秀人才潜心研究、静心教学，勇于挑战前沿难点问题，不拘一格大力培育、大胆使用青年教师。2014年以来，学校共投入2亿多元建设29个青年科学家工作室，按类别分别提供300万至500万元建设经费，使青年领军人才由“一个课题方向、一个人”交叉融合形成“一个前沿领域、一群人”的学术共同体。\r\n\r\n三是坚持“大师+团队”的人才方略，就是以学科领军人物、学术带头人、学术骨干力量、学术发展力量，组成层次清晰、创新能力强、可持续发展的学术梯队，发挥集智攻关、协同创新的优良传统，形成“以才聚才，以才引才”的良好环境，打造了复合材料、微小卫星、激光通信等200多个“大师+团队”群体。这是哈工大师资队伍建设的特色，也是学科建设的优势。\r\n\r\n四是统筹运用好“稳、引、培”策略，也就是稳定核心骨干、引进高端人才、培育年轻后备，大力实施青年拔尖人才选聘计划、重大项目突出贡献人才计划、教学拔尖人才计划，构建从青年人才到高端人才的成长通道，打造一支新“八百壮士”队伍。\r\n\r\n有了坚实的人才保障，近年来从哈工大走出了一大批科研成果，成功应用于天宫号、嫦娥号、蛟龙号、实践系列卫星、长征系列火箭、FAST工程、C919大飞机研制等国家重大项目。哈工大也创造出小卫星、机器人等一批有影响力的新成果、新方向，多项科技成果连续荣获国家科技进步奖特等奖、一等奖，国防科技奖特等奖，连续6年有7项成果入选“中国高校十大科技进展”。\r\n\r\n蓄力发展走向未来\r\n\r\n《瞭望》：作为一名在哈工大学习、工作40多年的哈工大人，你对学校有哪些期望？对未来中国高等教育发展又有怎样的判断和期许？\r\n\r\n周玉：42年前，我作为恢复高考后的第一届大学生来到哈工大，圆了大学梦。42年来，是哈工大这座熔炉去粗取精、去伪存真，把我从铁矿石炼成一块生铁，再熔炼成具有一定强度和韧性的合金钢，让我从一名农村民办教师成长为教授、院士、校长。在这片热土上，我从几代哈工大“八百壮士”身上深刻感受到了中国教育发生的深刻变化。\r\n\r\n培养中国社会发展所需要的各类人才，以应对中国经济社会高质量发展对人才的需求；解决重大社会、科技和工程技术问题，为中国乃至世界经济社会发展做出重要贡献。这是新时代中国高校的使命，也是“双一流”建设的最终目的。\r\n\r\n回顾哈工大与中国工业化事业、中国航天事业共同发展的历程，我们可以看到，哈工大能够取得今天的成绩，缘于学校多年来始终注重与国家重大战略需求同频共振。往往在一个学科处于鼎盛时期时，哈工大就开始着手谋划下一个新的学科方向和学科增长点，从而保持挑战最前沿科学问题的势态，取得一批重大成果填补国内空白、达到国际先进水平。\r\n\r\n今天，在新的历史起点上，哈工大面临着前所未有的机遇和挑战。未来几年将是全国高等教育分层发展、学科结构优化调整的重要时期，也是哈工大进一步增强综合实力、提升学术地位、建设世界一流大学的重大机遇期。\r\n\r\n哈工大的目标是创建“中国特色、世界一流、哈工大规格”的百年强校。“中国特色”，指的是办学要始终坚持中国共产党的领导，坚持社会主义办学方向，回答的是“办什么样的大学”和“培养什么样的人”的方向问题；“世界一流”，指的是办学要遵循教育规律，培养一流人才，产出一流成果，回答的是“建设什么水平的大学”和“培养什么水平的人才”的标准问题；“哈工大规格”，源于“规格严格，功夫到家”的校训，指的是哈工大近百年发展形成的历史传统和文化特色，是哈工大人做人、做事、做学问的共同标准和行为规范，回答的是现实路径问题。\r\n\r\n一是精准对接国家战略，继续推动重大项目超前培育。围绕航天强国、制造强国等国家创新驱动发展战略，主动适应新一轮重大科技计划调整的新形势新要求，强化科研组织力度、重大方向凝练力度、高端智库建设力度，推动形成基础研究、重大项目培育、科技奖励激励、青年科技人才成长的有效衔接，实现顺大势、谋大事、抓大项目、出大成果。\r\n\r\n二是持续深化科技体制机制改革。完善以激励创新、注重质量、支撑学科建设发展为导向的科研评价体系，实现从注重科技成果数量到能力、质量和贡献的有效转变。加强教师学术生涯规划和关键时点精准助推体系建设，着力培育扶植青年教师。\r\n\r\n三是大力推进交叉学科研究中心体制机制改革与建设。围绕国家经济社会发展和学术前沿关键核心领域，突破传统院系设置的体制壁垒，以开放共享为导向，全面加强管理体系和制度体系建设，实现对全校各类交叉研究机构的统筹管理、精准服务和系统建设。\r\n\r\n百舸争流千帆竞，风起扬帆正当时。哈工大人希望通过共同努力，把学校建设成广大学生向往的理工强校、航天名校，担当好培养卓越人才、产出创新成果、支撑国家战略、服务区域发展、开展高水平国际交流合作的时代使命，在实现“两个一百年”奋斗目标、实现中华民族伟大复兴中国梦的征程中，交出精彩答卷。\r\n\r\n原文链接：http://xhpfmapi.zhongguowangshi.com/vh512/share/6585659?channel=weixin','2019-11-18 19:40:43',NULL,1,'<p><img alt=\"\" src=\"/image/MjEzYTA2YzMzNGFhNTg4YWQxZjEyMjA4MTMwMDQxMDguanBn\"></p>\n<p>哈工大报讯（报宣）10月26日，《瞭望》新闻周刊专访我校校长周玉院士，以《规格严格 建设“尖端”强校》为题，以4个专版报道我校办学理念与办学成果。报道文章在新华社客户端刊发后引起广泛关注，截至目前文章浏览量已超过131万。</p>\n<p>报道全文如下：</p>\n<p>哈尔滨工业大学校长、中国工程院院士周玉：规格严格 建设“尖端”强校</p>\n<p>文 |《瞭望》新闻周刊记者 杨思琪</p>\n<p>◇大学不在大，而在学；学科不在全，而在精、优、特。办大学是办特色、创优势、求卓越、出精品，这是我们始终坚持的理念，也是大学赢得竞争、走向卓越的关键。</p>\n<p>◇培养中国社会发展所需要的各类人才，以应对经济社会高质量发展对人才的需求；解决重大社会、科技和工程技术问题，为中国乃至世界社会经济发展做出重要贡献。这是新时代中国高校的使命，也是“双一流”建设的最终目的。</p>\n<p><img alt=\"\" src=\"/image/OTVkMDNhNzYxYzg5MjRlNGZlNDc0MjlmOTBkYTg4ZWEuanBn\"></p>\n<p>一所高校的特色是在漫长办学历程中积淀而成的，既决定着学校的风格与方位，又与人才培养质量、科研成果水平密不可分。</p>\n<p>从扎根边疆、艰苦创业，将毕生奉献给共和国工业化事业的“八百壮士”，到为新中国航天事业写下浓墨重彩的“航天人”，地处“冰城”的哈尔滨工业大学始终与国家发展同向同行，形成了“立足航天、服务国防、长于工程”的鲜明品格。</p>\n<p>2020年，哈尔滨工业大学将迎来建校百年。哈工大校长、中国工程院院士周玉日前接受《瞭望》新闻周刊专访时表示，哈工大将始终牢记“赶考”初心、强国使命、育人根本，以争创世界一流大学、一流学科的责任感和紧迫感，向着“中国特色、世界一流、哈工大规格”的百年强校奋进。</p>\n<p>红色气质百年传承</p>\n<p>《瞭望》：作为一名哈工大人，你如何理解百年哈工大走过的风雨历程？新时代的哈工大又该怎样继承和发扬这种优良传统？</p>\n<p>周玉：哈尔滨工业大学1920年建校，原本是隶属于中长铁路的一所专业高校。新中国成立初期，国家各项建设刚刚起步，百废待兴。哈工大作为新中国学习苏联的样板学校，开始肩负起推动旧教育制度改革、实现社会主义工业化的使命。</p>\n<p>20世纪50年代，800多名青年师生响应国家号召，从祖国各地齐聚哈工大。短短十余年时间里，他们创办了24个新专业，一个基本适应当时国民经济建设需要，以机电、电气、土木、工程经济等为主的专业教学体系基本建成。这支平均年龄只有27.5岁的教师队伍，就是后人常常提起的哈工大“八百壮士”。</p>\n<p>虽然扎根边疆，但哈工大人始终心系国家命运，刻苦攻关，甘于奉献，形成了“规格严格、功夫到家”的校训文化和“立足航天、服务国防”的学科氛围。</p>\n<p>哈工大是首批国家“211工程”“985工程”重点建设高校，学校一直把人才培养作为第一要务和中心工作，并逐渐探索出“厚基础、强实践、严过程、求创新”的人才培养模式，为国家国防、航天领域培养了大批基础理论功底扎实、工程实践能力强、具有团结协作精神的优秀人才。</p>\n<p>如今，哈工大已构建了本、硕、博贯通的人才培养体系，建设了“本研一体化”教学管理系统，支持学生自主跨学科、跨层次选课。鼓励学生尽早进实验室，成为课题组初级成员，搭上科研快车，在真刀实枪的科研实践中成长为拔尖创新人才。同时推广小班化、混合式教学，倡导互动式、研讨式教学，通过教学改革促进学习革命，不断提高教育教学质量。</p>\n<p>面向国家重大需求、面向国际科技前沿，哈工大形成了服务航天国防、引领创新发展的科研特色，为建设中国特色先进国防科技工业体系做出了卓越贡献。</p>\n<p>2018年度国家最高科学技术奖获得者，中国科学院院士、中国工程院院士刘永坦，早在20世纪80年代初就立志开创中国的新体制雷达。尽管这项研究风险大、周期长，但他数十年如一日，初衷不改，带领团队潜心攻关，最终打破国外技术垄断，成功研制成我国第一部新体制雷达，为祖国万里海疆装上“火眼金睛”。</p>\n<p>在哈工大，像刘永坦这样一心一意干事业的教师不胜枚举。从我国第一台智能下棋计算机诞生，到第一台点焊弧焊机器人亮相；从首颗由高校牵头自主研制的小卫星一飞冲天，到近百项技术助力“神舟”飞天、“嫦娥”探月；从空间机械手成功完成天宫二号人机协同在轨维修科学试验，到国际首次高轨卫星对地高速激光双向通信试验成功……一项项科研成果成功破解了我国科技事业发展面临的诸多关键核心技术。</p>\n<p>建校以来，30余万学子从哈工大出发奔赴祖国各大战线，他们把爱国化为具体的行动，把个人奋斗融入国家发展，把科研精神与家国情怀有机融合，为了祖国的需要奉献一切，这种精神在不断传递，成为哈工大的一种品质，也成为哈工大建设世界一流大学的不变底色。</p>\n<p>立足航天创造一流</p>\n<p>《瞭望》：站在即将建校百年的历史节点，哈工大制定实施的《哈尔滨工业大学一流大学建设方案》对百年强校建设意味着什么？学校又将如何有效推动落实？</p>\n<p>周玉：当前，世界经济大国对高等教育的投入越来越大，重视程度越来越高，许多国家都把办一流大学、培养拔尖创新人才作为实现国家发展、增强综合国力的战略举措，全球范围内的大学竞争明显加剧。</p>\n<p>我国依托高校布局了一批战略级科学研究中心，为高校瞄准国家目标、集聚科研人才、开展跨学科研究、实现跨越式发展提供了重要平台，也为高校建设“双一流”提供了加速器。</p>\n<p>在这种背景下，哈工大以建设“‘中国特色、世界一流、哈工大规格’的百年强校”为定位，以全面深化教育综合改革为抓手，以“汇聚一流、形成高峰；突出优势、彰显特色；创新机制、鼓励交叉；促进新兴、引领发展”为指导思想，制定实施了“2511”学科建设计划，以一流学科建设引领带动学校整体发展。</p>\n<p>“2511”学科建设计划是以位居国内前列、具备冲击世界一流条件的学科为基础，重点建设2个领先一级学科、5个优势学科群、1个特色学科群、1个交叉学科群，主要涉及力学、材料科学与工程等学科，覆盖环境科学与工程、计算机科学与技术、高端装备制造、航天科学与工程等学科群。</p>\n<p>哈工大注重加强学科规划与顶层设计，动态调整学科建设范围及支持力度，做好特色优势学科和新兴交叉学科的统筹协调发展。做好物理学院、数学学院顶层设计和发展规划，推动理工学科交叉融合。采取差异化发展策略，推动经管文法学科与航天、国防、工程交叉融合，持续巩固形成以工强文、以文促工、文理融通的良好局面。</p>\n<p>目前，数学、人工智能、网络空间安全、生物信息技术、可持续能源技术研究院、生命科学中心等都已成立，通过培育更多学科发展和学术研究的新增长点，力争在前沿交叉领域实现若干重大突破。</p>\n<p>在国际化建设方面，学校将继续推进与世界一流大学、一流学术机构和一流学者可持续、高水平、深层次的实质性合作，将国外优质教育资源有效融合到学科建设的全过程，共同进军科学技术前沿。</p>\n<p>《瞭望》：作为一所以航天为特色的高校，哈工大提出坚持“有所为、有所不为”的原则，建设航天科学与工程学科群。如何突出这一优势特色？</p>\n<p>周玉：大学不在大，而在学；学科不在全，而在精、优、特。办大学是办特色、创优势、求卓越、出精品，这是我们始终坚持的理念，也是大学赢得竞争、走向卓越的关键。</p>\n<p>哈工大主动立足航天、服务国防，于1987年成立了我国高校第一个航天学院，并逐步打造形成了多学科相互融合、共同服务航天事业的“大航天”格局，有百余项研究成果应用于航天国防各个领域，荣获“中国载人航天工程协作贡献奖”等多个奖项。</p>\n<p>在“双一流”建设中，哈工大将坚持“人才、学科、科研”三位一体协调发展，超前凝练新方向、谋划大项目、建设大平台，注重高水平科技人才、团队、项目培育的有效融合，着力提升原始创新能力、交叉融合能力和团队攻关能力，打造基础研究、关键技术攻关、重大工程实施、成果转化和产业化的完整链条，实现从被动跟踪到主动引领的跨越式转变，推进特色优势学科的加速、升级、提高。</p>\n<p>针对制约我国科技、经济发展以及航天等重大战略需求的核心关键技术研究，产出一批重大创新成果，打造一批善于协同攻关、奉献担当的创新团队，努力建设成为我国航天国防和工程等领域重大科研方向的“策源地”“聚集地”和“孵化器”。</p>\n<p>我们还将围绕“航天强国”“网络强国”等国家重大战略，以高水平科研创新平台建设、重大标志项目实施等重大任务为抓手，建设若干具有集成优势的高水平特色新型智库，支持培养一批高端智库人才和咨询研究团队。</p>\n<p>改革创新汇聚人才</p>\n<p>《瞭望》：在东北振兴发展背景下，哈工大在加强人才队伍建设方面采取了哪些举措？是如何培养拔尖创新人才、提升科研水平的？</p>\n<p>周玉：“致天下之治者在人才。”哈工大始终把师资队伍建设作为重大战略工作来对待。经过多年探索，哈工大走出了一条“以自己培养为主、稳引培并举”的人才建设之路，努力打造引高贤的宝地、干事业的高地、聚人心的福地。</p>\n<p>一是持续建设并完善分类多元评价体系。通过分类设岗、分类聘任、分类评价等破“五唯”的实招硬招，设置了教学科研并重型、教学为主型、科研为主型、创新创业型和教学科研支持型5种类型的教师岗位。通过“以人为本、人尽其才、才尽其用”的人才管理机制，支持和鼓励广大教师根据自身的特点和潜能合理定位，明确发展目标和方向，让各类人才各得其所，发挥人才队伍建设的“长板效应”。</p>\n<p>二是优化教师岗位长聘准聘机制，搭建助推优秀人才特别是青年人才发展的成长阶梯，鼓励优秀人才潜心研究、静心教学，勇于挑战前沿难点问题，不拘一格大力培育、大胆使用青年教师。2014年以来，学校共投入2亿多元建设29个青年科学家工作室，按类别分别提供300万至500万元建设经费，使青年领军人才由“一个课题方向、一个人”交叉融合形成“一个前沿领域、一群人”的学术共同体。</p>\n<p>三是坚持“大师+团队”的人才方略，就是以学科领军人物、学术带头人、学术骨干力量、学术发展力量，组成层次清晰、创新能力强、可持续发展的学术梯队，发挥集智攻关、协同创新的优良传统，形成“以才聚才，以才引才”的良好环境，打造了复合材料、微小卫星、激光通信等200多个“大师+团队”群体。这是哈工大师资队伍建设的特色，也是学科建设的优势。</p>\n<p>四是统筹运用好“稳、引、培”策略，也就是稳定核心骨干、引进高端人才、培育年轻后备，大力实施青年拔尖人才选聘计划、重大项目突出贡献人才计划、教学拔尖人才计划，构建从青年人才到高端人才的成长通道，打造一支新“八百壮士”队伍。</p>\n<p>有了坚实的人才保障，近年来从哈工大走出了一大批科研成果，成功应用于天宫号、嫦娥号、蛟龙号、实践系列卫星、长征系列火箭、FAST工程、C919大飞机研制等国家重大项目。哈工大也创造出小卫星、机器人等一批有影响力的新成果、新方向，多项科技成果连续荣获国家科技进步奖特等奖、一等奖，国防科技奖特等奖，连续6年有7项成果入选“中国高校十大科技进展”。</p>\n<p>蓄力发展走向未来</p>\n<p>《瞭望》：作为一名在哈工大学习、工作40多年的哈工大人，你对学校有哪些期望？对未来中国高等教育发展又有怎样的判断和期许？</p>\n<p>周玉：42年前，我作为恢复高考后的第一届大学生来到哈工大，圆了大学梦。42年来，是哈工大这座熔炉去粗取精、去伪存真，把我从铁矿石炼成一块生铁，再熔炼成具有一定强度和韧性的合金钢，让我从一名农村民办教师成长为教授、院士、校长。在这片热土上，我从几代哈工大“八百壮士”身上深刻感受到了中国教育发生的深刻变化。</p>\n<p>培养中国社会发展所需要的各类人才，以应对中国经济社会高质量发展对人才的需求；解决重大社会、科技和工程技术问题，为中国乃至世界经济社会发展做出重要贡献。这是新时代中国高校的使命，也是“双一流”建设的最终目的。</p>\n<p>回顾哈工大与中国工业化事业、中国航天事业共同发展的历程，我们可以看到，哈工大能够取得今天的成绩，缘于学校多年来始终注重与国家重大战略需求同频共振。往往在一个学科处于鼎盛时期时，哈工大就开始着手谋划下一个新的学科方向和学科增长点，从而保持挑战最前沿科学问题的势态，取得一批重大成果填补国内空白、达到国际先进水平。</p>\n<p>今天，在新的历史起点上，哈工大面临着前所未有的机遇和挑战。未来几年将是全国高等教育分层发展、学科结构优化调整的重要时期，也是哈工大进一步增强综合实力、提升学术地位、建设世界一流大学的重大机遇期。</p>\n<p>哈工大的目标是创建“中国特色、世界一流、哈工大规格”的百年强校。“中国特色”，指的是办学要始终坚持中国共产党的领导，坚持社会主义办学方向，回答的是“办什么样的大学”和“培养什么样的人”的方向问题；“世界一流”，指的是办学要遵循教育规律，培养一流人才，产出一流成果，回答的是“建设什么水平的大学”和“培养什么水平的人才”的标准问题；“哈工大规格”，源于“规格严格，功夫到家”的校训，指的是哈工大近百年发展形成的历史传统和文化特色，是哈工大人做人、做事、做学问的共同标准和行为规范，回答的是现实路径问题。</p>\n<p>一是精准对接国家战略，继续推动重大项目超前培育。围绕航天强国、制造强国等国家创新驱动发展战略，主动适应新一轮重大科技计划调整的新形势新要求，强化科研组织力度、重大方向凝练力度、高端智库建设力度，推动形成基础研究、重大项目培育、科技奖励激励、青年科技人才成长的有效衔接，实现顺大势、谋大事、抓大项目、出大成果。</p>\n<p>二是持续深化科技体制机制改革。完善以激励创新、注重质量、支撑学科建设发展为导向的科研评价体系，实现从注重科技成果数量到能力、质量和贡献的有效转变。加强教师学术生涯规划和关键时点精准助推体系建设，着力培育扶植青年教师。</p>\n<p>三是大力推进交叉学科研究中心体制机制改革与建设。围绕国家经济社会发展和学术前沿关键核心领域，突破传统院系设置的体制壁垒，以开放共享为导向，全面加强管理体系和制度体系建设，实现对全校各类交叉研究机构的统筹管理、精准服务和系统建设。</p>\n<p>百舸争流千帆竞，风起扬帆正当时。哈工大人希望通过共同努力，把学校建设成广大学生向往的理工强校、航天名校，担当好培养卓越人才、产出创新成果、支撑国家战略、服务区域发展、开展高水平国际交流合作的时代使命，在实现“两个一百年”奋斗目标、实现中华民族伟大复兴中国梦的征程中，交出精彩答卷。</p>\n<p>原文链接：<a href=\"http://xhpfmapi.zhongguowangshi.com/vh512/share/6585659?channel=weixin\" rel=\"nofollow\">http://xhpfmapi.zhongguowangshi.com/vh512/share/6585659?channel=weixin</a></p>');
/*!40000 ALTER TABLE `post` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `post_tags`
--

DROP TABLE IF EXISTS `post_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `post_tags` (
  `post_id` int(11) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  KEY `post_id` (`post_id`),
  KEY `tag_id` (`tag_id`),
  CONSTRAINT `post_tags_ibfk_1` FOREIGN KEY (`post_id`) REFERENCES `post` (`id`),
  CONSTRAINT `post_tags_ibfk_2` FOREIGN KEY (`tag_id`) REFERENCES `tag` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `post_tags`
--

LOCK TABLES `post_tags` WRITE;
/*!40000 ALTER TABLE `post_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `post_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tag`
--

DROP TABLE IF EXISTS `tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tag` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tag`
--

LOCK TABLES `tag` WRITE;
/*!40000 ALTER TABLE `tag` DISABLE KEYS */;
/*!40000 ALTER TABLE `tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(64) DEFAULT NULL,
  `location` varchar(64) DEFAULT NULL,
  `about_me` text,
  `member_since` datetime DEFAULT NULL,
  `last_seen` datetime DEFAULT NULL,
  `name` varchar(64) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `birthday` date DEFAULT NULL,
  `headimg` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `ix_user_email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'admin@admin.com','哈尔滨','20c3e2deb2736089dbd999cf999195ae|gANYHgAAAOinhOagvOS4peagvO+8jOWKn+Wkq+WIsOWutuOAgnEALg==','2019-11-18 11:37:21','2019-11-18 11:54:56','admin','admin','$2b$12$ZEjCGiJr18x5zlOzF3dPwOn/uyk87Xay8MvilapaOOYdZOCE9k6zq',NULL,'/static/headimg/default.jpg');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-11-18 19:56:10
