#/usr/bin/env python
# encoding:utf-8

from flask import Blueprint
userinfo  = Blueprint('userinfo',__name__)
from . import views
