<?php
namespace app\index\controller;

class Frame
{
    public function frame() {
      	return view('frame0');
    }
}
