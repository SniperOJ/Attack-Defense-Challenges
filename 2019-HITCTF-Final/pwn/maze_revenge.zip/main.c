//gcc -s -fPIE -pie main.c -o pwn
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <fcntl.h>
#include <time.h>
#include <math.h>
#include <linux/seccomp.h>
#include <linux/filter.h>
#include <sys/prctl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include "maze.h"

#define MAZE_SZ 44

//#define DEBUG

// enable pie

char *g_notes;

int pass_maze();
void leave_message();
void practise_shellcode();
void repeater();
void take_notes();
void view_notes();

int init_buf();
int init_seccomp();
void show_menu();
int get_str();
unsigned int get_uint();
unsigned long long get_ull();
void alarm_handle();
int init();
int quit();
int pass_check(); // 检查是否只包含 W A S D

void show_menu() { 
    puts("1. practise shellcode");
	puts("2. play with repeater");
	puts("3. take some notes");
    puts("4. view notes");
    puts("5. leave some messages");
    puts("6. quit");
	printf("> ");
}

int main() {
	init();
    puts("welcome to game center !");
    puts("let's play some maze first !");
    pass_maze();
	int choice=-1;
	for(;;) {
		show_menu();
		choice = get_uint();
		switch(choice) {
			case 1: practise_shellcode(); break;
			case 2: repeater(); break;
			case 3: take_notes(); break;
			case 4: view_notes(); break;
			case 5: leave_message(); break;
			case 6: exit(0); break;
			default : puts("invalid choice"); continue;
		}
	}
	return 0;
}

void take_notes(){
    puts("hackers don't need note");
}

void view_notes(){
    puts("practice makes perfact");
}

void repeater() {
    puts("I am The Ruthless Repeater");
    unsigned long long size;
    for(unsigned int i=0; i<996; ++i){
        puts("input the size:");
        size = get_ull();
        if ( !size )
        exit(-1);
        char *buf = malloc(size);
        puts("Say sth");
        read(0, buf, size);
        buf[size-1] = '\0';
        puts("Say sth");
        write(1, buf, size);
        free(buf);
    }
    exit(0);
}

void practise_shellcode() {
    puts("pratice makes perfact");
    puts("so show me the code ");
    init_seccomp();
    char sc_buf[0x101];
    memset(sc_buf, 0, 0x101);
    if (read(0, sc_buf, 0x100) <= 0)
        exit(-1);
    for(int i=0; i<0x100; ++i){
        char ch = sc_buf[i];
        if (ch == '\0')
            break;
        if (ch < 0x20 || ch >0x7f)
            exit(-1);
    }
    void *mem = mmap(0, 0x1000, PROT_READ|PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, 0, 0);
    if (mem == (void *)-1)
        exit(-1);
    memcpy(mem, sc_buf, 0x100);
    if (mprotect(mem, 0x1000, PROT_READ|PROT_WRITE|PROT_EXEC) == -1)
        exit(-1);
    ((void(*)(void))mem)();
}

int pass_maze() {
    puts("want the flag,  ha ?");
    puts("pass the maze first");
    Maze *mazep = init_maze(MAZE_SZ);
    show_maze(mazep);
    puts("input your steps");
    char steps[0x401];
    unsigned int step_cnt;
    step_cnt = get_str(steps, 0x400);
    if (walk_maze(mazep, steps, step_cnt) == 1){
        puts("wow, you are really good at that");
        return 1;
    }
    else
        puts("learn some Data Structures and Algorithms before hacking, man");
    exit(-1);
}

void leave_message() {
    puts("leave something intersting to the gamebox's maintainer");
    puts("e.g. hacked by Smi1e");
    char name[0x51];
    unsigned int name_sz;
    name_sz =  read(0, name, 0x50);
    if (name_sz <= 0)
        exit(-1);
    name[0x50] = '\0';
    puts("where do you want to save the message (./tourist.txt is recommended): ");
    char path[0x21];
    if (read(0, path, 0x20) <= 0)
        exit(-1);
    path[0x20] = '\0';
    if (*(int *)path == 0x6f72702f)
        exit(-1);
    int fd = open(path, 2 , 0);
    if (fd == -1)
        exit(-1);
    // puts("suggest appending to the end of file in case of overwriting messages leaved by others");
    // int seek_mode = SEEK_SET;
    // scanf("%d", &seek_mode);
    puts("offset ?");
    unsigned int offset = get_uint();
    if (lseek(fd, offset, SEEK_SET) == -1)
        exit(-1);
    if (write(fd, name, name_sz) <= 0)
        exit(-1);
    puts("see you");
    exit(0);
}

int init_seccomp() {
	int rc = -1;
    rc = prctl(PR_SET_NO_NEW_PRIVS,1,0,0,0);
    if (rc == -1)
        return rc;
	struct sock_filter sfi[] = {
        {0x20, 0x00, 0x00, 0x00000004},
        {0x15, 0x00, 0x10, 0xc000003e},
        {0x20, 0x00, 0x00, 0x00000000},
        {0x15, 0x00, 0x01, 0x00000002},
        {0x06, 0x00, 0x00, 0x00000000},
        {0x15, 0x00, 0x01, 0x00000101},
        {0x06, 0x00, 0x00, 0x00000000},
        {0x15, 0x00, 0x01, 0x0000003b},
        {0x06, 0x00, 0x00, 0x00000000},
        {0x15, 0x00, 0x01, 0x00000038},
        {0x06, 0x00, 0x00, 0x00000000},
        {0x15, 0x00, 0x01, 0x00000039},
        {0x06, 0x00, 0x00, 0x00000000},
        {0x15, 0x00, 0x01, 0x0000003a},
        {0x06, 0x00, 0x00, 0x00000000},
        {0x15, 0x00, 0x01, 0x00000055},
        {0x06, 0x00, 0x00, 0x00000000},
        {0x15, 0x00, 0x01, 0x00000142},
        {0x06, 0x00, 0x00, 0x00000000},
        {0x06, 0x00, 0x00, 0x7fff0000},
    };
	struct sock_fprog sfp = {20,sfi};
    rc = prctl(PR_SET_SECCOMP,SECCOMP_MODE_FILTER,&sfp);
    if (rc == -1)
        return rc;
    puts("seccomp init success");
    return 0;
}

int init_buf() {
    if (setvbuf(stdin, 0, 2, 0))
        exit(-1);
    if(setvbuf(stdout, 0, 2, 0))
        exit(-1);
    if(setvbuf(stderr, 0, 2, 0))
        exit(-1);
    puts("buf init success");
    return 0;
}

int get_str(char *buf, unsigned int cnt){
	char ch=0;
	int i=0;
	for(; i<cnt; ++i){
		int ret = read(0, &ch, 1);
		if (ret == -1){
			exit(-1);
		}
		if (ch == '\n' || ch == '\0'){
			break;
		}
		buf[i] = ch;
	}
	buf[i] = '\x00'; // off-by-null
	return i;
}

unsigned int get_uint(){
	char buf[0x10];
	get_str(buf, 0xf);
	buf[15] = '\x00';
	return atoi(buf);
}

unsigned long long get_ull(){
	char buf[0x10];
	get_str(buf, 0xf);
	buf[15] = '\x00';
	return atoll(buf);
}


void alarm_handle(int param){
	puts("time over");
	exit(param);
}

int init(){
    init_buf();
    write(1, " _     _ _       _    __  \n", 27);
    write(1, "| |__ (_) |_ ___| |_ / _| \n", 27);
    write(1, "| '_ \\| | __/ __| __| |_  \n", 27);
    write(1, "| | | | | || (__| |_|  _| \n", 27);
    write(1, "|_| |_|_|\\__\\___|\\__|_|   \n", 27);
	signal(SIGALRM, alarm_handle);
	alarm(60);
    g_notes = NULL;
	return 0;
}
