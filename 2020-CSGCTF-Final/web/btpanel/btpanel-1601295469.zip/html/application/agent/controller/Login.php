<?php
namespace app\agent\controller;

use think\Session;
use think\Db;
use app\common\util\ReturnCode;

class Login extends Base
{
    /**
     * 无需登录的方法
     */
    protected $noNeedLogin = ['index'];

    public function index()
    {
        if ($this->isAjaxPost()) {
            $username = $this->request->param('username');
            $password = $this->request->param('password');
            $vercode = $this->request->param('vercode');
            // if (!$loginname || !$password || $vercode) {
            //     return $this->buildFailed(ReturnCode::LOGIN_ERROR '未知参数');
            // }
            $res = $this->validate(
                [
                    'username' => $username,
                    'password' => $password,
                    'vercode' => $vercode
                ],
                [
                    'username' => 'require',
                    'password' => 'require',
                    'vercode' => 'require|captcha'
                ],
                [
                    'username.require' => '帐号不能为空',
                    'password.require' => '密码不能为空',
                    'vercode.require' => '验证码不能为空',
                    'vercode.captcha' => '验证码不正确',
                ]
            );
            if (true !== $res) {
                return $this->buildFailed(ReturnCode::LOGIN_ERROR, $res);
            }
            $agentInfo = Db::name('user')->where(['username' => $username])->find();
            if (empty($agentInfo)) {
                return $this->buildFailed(ReturnCode::LOGIN_ERROR, '帐号或密码不正确');
            }

            if ($agentInfo['is_agent'] != '1') {
                return $this->buildFailed(ReturnCode::LOGIN_ERROR, '请用代理帐号登录');
            }

            if ($agentInfo['password'] != $this->getEncryptPassword($password, $agentInfo['salt'])) {
                return $this->buildFailed(ReturnCode::LOGIN_ERROR, '帐号或密码不正确');
            }

            if ($agentInfo['status'] != '1') {
                return $this->buildFailed(ReturnCode::LOGIN_ERROR, '帐号已被禁用，请联系管理员');
            }

            unset($agentInfo['password']);
            unset($agentInfo['salt']);
            // 记录登录状态
            Session::set('agent', $agentInfo);
            return $this->buildSuccess([], '登录成功');
        } else {
            return $this->fetch();
        }
    }

    /**
     * 退出登录
     */
    public function logout() {
        Session::delete("agent");
        $this->success('退出登录成功', url('Agent/Login/index'));
    }



    /**
     * 获取密码加密后的字符串
     * @param string $password  密码
     * @param string $salt      密码盐
     * @return string
     */
    private function getEncryptPassword($password, $salt = '')
    {
        return md5(md5($password) . $salt);
    }
}
