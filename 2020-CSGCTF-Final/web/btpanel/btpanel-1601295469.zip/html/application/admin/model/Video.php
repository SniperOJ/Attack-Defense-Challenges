<?php
namespace app\admin\model;

use think\Model;
use think\Db;

class Video extends Model {

    /**
     * @param $filter
     * @param int $page_size
     * @return \think\Paginator
     */
    public function getVideoList($filter, $page_size = 10) {
        $result = Db::name('video')
            ->alias('a')
            ->field([
                'a.id',
                'b.title' => 'cate_name',
                'a.title',
                'a.image',
                'a.link',
                'a.brief',
                'a.filename',
                'a.filesize',
                'a.mimetype',
                'a.sort',
                'a.createtime'
            ])
            ->join('video_cate b', 'b.id=a.cate_id', 'LEFT')
            ->where(function ($query) use (&$filter) {
                $where = $query->where('a.id', 'gt', 0);
                if ((bool)$filter['title']) {
                    $where->where('a.title', 'like', '%' . $filter['title'] . '%');
                }
                if ((bool)$filter['cate_name']) {
                    $where->where('b.title', 'like', '%' . $filter['cate_name'] . '%');
                }
            })
            ->order('id desc')
            ->paginate($page_size);
        return $result;
    }

    /**
     * 导出视频数据
     */
    public function exportVideoList($filter) {
        $result = Db::name('video')
            ->alias('a')
            ->field([
                'a.id',
                'b.title' => 'cate_name',
                'a.title',
                'a.image',
                'a.link',
                'a.brief',
                'a.filename',
                'a.filesize',
                'a.mimetype',
                'a.sort',
                'a.createtime'
            ])
            ->join('video_cate b', 'b.id=a.cate_id', 'LEFT')
            ->where(function ($query) use (&$filter) {
                $where = $query->where('a.id', 'gt', 0);
                if ((bool)$filter['title']) {
                    $where->where('a.title', 'like', '%' . $filter['title'] . '%');
                }
                if ((bool)$filter['cate_name']) {
                    $where->where('b.title', 'like', '%' . $filter['cate_name'] . '%');
                }
            })
            ->select();

        return $result;
    }
}