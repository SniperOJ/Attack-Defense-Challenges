<?php
namespace app\admin\controller;

use think\Db;
use think\Exception;
use think\Loader;
use think\Request;
use app\common\util\ReturnCode;
use app\common\util\Random;

class User extends Base {

    /**
     * 用户列表
     */
    public function index() {
        if ($this->isAjaxGet()) {
            
            $filter = [
                'username'      => $this->request->param('username'),
                'invite_code'  => $this->request->param('invite_code'),
                'is_agent' => $this->request->param('is_agent')
            ];
            $model = model('User')->getUserList($filter,  $this->request->param('page'),  $this->request->param('limit'));
            $userList = $model;
          	//$userList = $model;
            foreach ($userList as $key => $value) {
                $userList[$key]['createtime'] = date('Y-m-d H:i:s', $value['createtime']);
                $userList[$key]['logintime'] = $value['logintime'] > 0 ? date('Y-m-d H:i:s', $value['logintime']) : '-';
                $userList[$key]['is_end'] = $value['is_ever'] == 1 ? 0 : ($value['end_time'] > time() ? 0 : 1);
                $userList[$key]['end_time'] = date('Y-m-d H:i:s', $value['end_time']);
                $userList[$key]['referrer_name'] = Db::name('user')->alias('b')->where('b.invite_code', 'eq', $value['referrer'])->value('b.username');
                $userList[$key]['agent_nums'] =  Db::name('user')->alias('ag')->where('ag.is_agent', 'eq', 1)->where('ag.agent_code','eq',$value['invite_code'])->count('distinct ag.id');
            }
            $data = $userList;
            $count = model('User')->getUserList($filter,  $this->request->param('page'),  $this->request->param('limit'),true);
            return $this->buildTableSuccess($data, $count);
        } else {
            return $this->fetch();
        }
    }

    /**
     * 用户个人信息
     */
    public function info() {
        $id = $this->request->param('id', 0);
        if (! $id) {
            $this->error('非法操作');
        }
        $info = Db::name('user')->where(['id' => $id])->find();
        if (! empty($info)) {
            $info['is_end'] = $info['end_time'] > time() ? 0 : 1;
            $info['agent_nums'] = Db::name('user')->where(['is_agent' => 1, 'agent_code' => $info['invite_code']])->count();
            $info['referrer'] = Db::name('user')->where(['invite_code' => $info['referrer']])->value('username');
            $info['agent_name'] = Db::name('user')->where(['invite_code' => $info['agent_code']])->value('username');
        }

        $this->assign('info', $info);
        return $this->fetch();
    }

    /**
     * 修改密码
     */
    public function editPass() {
        $id = $this->request->param('id', 0);
        if (! $id) {
            $this->error('非法操作');
        }
        $info = Db::name('user')->where(['id' => $id])->find();
        if (empty($info)) {
            $this->error('非法操作');
        }
        if ($this->isAjaxPost()) {
            $password = $this->request->param('password');
            if (!$id || ! $password) {
                return $this->buildFailed(ReturnCode::INVALID, '非法操作');
            }
         
            $data['salt'] = Random::alnum();
            $data['password'] = md5(md5($password) . $data['salt']);
            
            $res = Db::name('user')->where(['id' => $id])->update($data);
            if ($res === false) {
                return $this->buildFailed(ReturnCode::ADD_FAILED, '修改失败');
            } else {
                return $this->buildSuccess([], '修改成功');
            }
        } else {
            $this->assign('info', $info);
            return $this->fetch('editPass');
        }
    }

  
  
    /**
     * [export 导出用户记录]
     */
    public function export() {
        Loader::import('PHPExcel.Classes.PHPExcel');
        Loader::import('PHPExcel.Classes.PHPExcel.IOFactory.PHPExcel_IOFactory');
        $str = Request::instance()->param('str');
        if (!empty($str)) {
            $params = json_decode($str);
            $filter = [
                'username'  => $params->username,
                'invite_code'  => $params->invite_code,
                'is_agent' => $params->is_agent
            ];
        } else {
            $filter = [
                'username'  => '',
                'invite_code'  => '',
                'is_agent' => ''
            ];
        }

        $model = collection(model('User')->exportUserList($filter));

        $userList = $model->toArray();
        $newList = [];
        foreach ($userList as $key => $value) {
            $newList[] = [
                'id' => $value['id'],
                'username' => $value['username'],
                'nickname_code' => $value['nickname_code'],
                'invite_code' => $value['invite_code'],
                'referrer_name' => $value['referrer_name'],
                'agent_name' => $value['agent_name'],
                'is_agent' => $value['is_agent'] == 1 ? '是' : '否',
                'point_num' => $value['point_num'],
                'agent_nums' => $value['agent_nums'],
                'is_end' => $value['end_time'] > time() ? '否' : '是',
                'end_time' => date('Y-m-d H:i:s', $value['end_time']),
                'createtime' => date('Y-m-d H:i:s', $value['createtime']),
                'logintime' => $value['logintime'] > 0 ? date('Y-m-d H:i:s', $value['logintime']) : '-',
                'status' => $value['status'] == 1 ? '正常' : '禁用'
            ];
        }
        $row_title = ['ID', '用户名', '昵称', '推荐码', '推荐人', '上级代理', '是否代理', '积分', '下级代理数', '是否过期',  '到期时间', '注册时间', '最近登录时间', '状态'];
        array_unshift($newList, $row_title);

        $date = date('Y-m-d H i');
        $phpexcel = new \PHPExcel();
        $sheet    = $phpexcel->getActiveSheet();
        $sheet->setTitle("{$date}-会员记录");
        $chr = [];
        for ($i='A'; $i<='Z'; $i++) {
            $chr[] = $i;
            if (sizeof($chr) >= sizeof($row_title)) break;
        }

        $i = 1;
        foreach ($newList as $val) {
            $z = 0;
            foreach ($val as $k=>$v) {
                $sheet->setCellValue($chr[$z].$i, $v);
                $z++;
            }
            $i++;
        }

        $write = \PHPExcel_IOFactory::createWriter($phpexcel, 'Excel5');
        header("Pragma: public");
        header("Expires: 0");
        header("Cache-Control:must-revalidate, post-check=0, pre-check=0");
        header("Content-Type:application/force-download");
        header("Content-Type:application/vnd.ms-execl");
        header("Content-Type:application/octet-stream");
        header("Content-Type:application/download");
        header("Content-Disposition:attachment;filename={$date}-会员记录.xlsx");
        header("Content-Transfer-Encoding:binary");
        header('Cache-Control: max-age=0');
        $write->save('php://output');
        exit;
    }

    /**
     * 更新登录状态
     */
    public function updateStatus() {
        if ($this->isAjaxPost()) {
            $ids = $this->request->param('ids', 0);
            $type = $this->request->param('type', 0);
            if (! $ids) {
                return $this->buildFailed(ReturnCode::INVALID, '非法操作');
            }
            if ($type == 0) {
                $data['status'] = 0;
            } else if ($type == 1) {
                $data['status'] = 1;
            } else {
                return $this->buildFailed(ReturnCode::INVALID, '非法操作');
            }
            $res = Db::name('user')->where(['id' => array('in', $ids)])->update($data);
            if ($res === false) {
                return $this->buildFailed(ReturnCode::UPDATE_FAILED, '操作失败');
            } else {
                return $this->buildSuccess([]);
            }
        } else {
            return $this->buildFailed(ReturnCode::INVALID, '非法操作');
        }
    }

    /**
     * 更新代理状态
     */
    public function updateAgent() {
        if ($this->isAjaxPost()) {
            $id = $this->request->param('id', 0);
            $type = $this->request->param('type', 0);
            if (! $id) {
                return $this->buildFailed(ReturnCode::INVALID, '非法操作');
            }
            $info = Db::name('user')->where(['id' => $id])->find();
            if (empty($info)) {
                return $this->buildFailed(ReturnCode::INVALID, '非法操作');
            }
            if ($type == 0) {
                $data['is_agent'] = 0;
            } else if ($type == 1) {
                $data['is_agent'] = 1;
                $data['is_ever_agent'] = 1;
            } else {
                return $this->buildFailed(ReturnCode::INVALID, '非法操作');
            }
            $res = Db::name('user')->where(['id' => $id])->update($data);
            if ($res === false) {
                return $this->buildFailed(ReturnCode::UPDATE_FAILED, '操作失败');
            } else {
                $this->updateAgentLog($id, $type);
                return $this->buildSuccess([]);
            }
        } else {
            return $this->buildFailed(ReturnCode::INVALID, '非法操作');
        }
    }

    /**
     * [编辑靓号推荐码]
     */
    public function updateInviteCode() {
        $id = $this->request->param('id', 0);
        if (! $id) {
            $this->error('非法操作');
        }
        $info = Db::name('user')->where(['id' => $id])->find();
        if (empty($info)) {
            $this->error('非法操作');
        }

        if ($this->isAjaxPost()) {
            $params = $this->request->param();

            $data['good_invite_code'] = $params['good_invite_code'];
            if (! empty($data['good_invite_code'])) {
                if (! is_good_invite_code($data['good_invite_code'])) {
                    return $this->buildFailed(ReturnCode::INVALID, '靓号只能由6位小写、大写字母、数字组成');
                }
                $row = Db::name('user')->where(['good_invite_code' => $data['good_invite_code']])->find();
                if (! empty($row['good_invite_code']) && $row['id'] != $id) {
                    return $this->buildFailed(ReturnCode::INVALID, '此靓号推荐码已被使用');
                }
            }

            $res = Db::name('user')->where(['id' => $info['id']])->update($data);
            if ($res === false) {
                return $this->buildFailed(ReturnCode::UPDATE_FAILED, '操作失败');
            } else {
                $this->addInviteCodeRecord($id, $data['good_invite_code']);
                return $this->buildSuccess([]);
            }
        } else {
            $this->assign('info', $info);
            return $this->fetch('updateInviteCode');
        }
    }

    /**
     * [关闭代理]
     */
    public function contact() {
        $id = $this->request->param('id', 0);
        if (! $id) {
            $this->error('非法操作');
        }
        // 不能关闭总代理
        if ($id == 1) {
            $this->error('不能关闭总代理');
        }
        $info = Db::name('user')->where(['id' => $id])->find();
        if (empty($info)) {
            $this->error('非法操作');
        }

        if ($this->isAjaxPost()) {
            $params = $this->request->param();

            $buyData['month_url'] = $params['month_url'];
            $buyData['season_url'] = $params['season_url'];
            $buyData['year_url'] = $params['year_url'];
            $buyData['forever_url'] = $params['forever_url'];
            $userBuyLinkInfo = Db::name('user_buy_link')->where(['user_id' => $info['id']])->find();
            if (empty($userBuyLinkInfo)) {
                $buyData['user_id'] = $info['id'];
                $buyData['createtime'] = time();
                $res = Db::name('user_buy_link')->insert($buyData);
            } else {
                $res = Db::name('user_buy_link')->where(['user_id' => $info['id']])->update($buyData);
            }
            if ($res === false) {
                return $this->buildFailed(ReturnCode::UPDATE_FAILED, '修改失败');
            }

            $data['is_online_buy'] = $params['is_online_buy'];
            $data['contact'] = $params['contact'];
            $data['desc'] = $params['desc'];
            $data['is_agent'] = 0; // 关闭代理
            // 回收靓号推荐码
            $data['good_invite_code'] = '';
            $res = Db::name('user')->where(['id' => $info['id']])->update($data);
            if ($res === false) {
                return $this->buildFailed(ReturnCode::UPDATE_FAILED, '操作失败');
            } else {
                $this->updateAgentLog($id, 0);
                return $this->buildSuccess([]);
            }
        } else {
            $urlInfo = Db::name('user_buy_link')->where(['user_id' => $info['id']])->find();
            $this->assign('urlInfo', $urlInfo);
            $this->assign('info', $info);
            return $this->fetch();
        }
    }

    /**
     * 充值
     */
    public function recharge()
    {
        $id = $this->request->param('id', 0);
        if (! $id) {
            $this->error('非法操作');
        }
        // $info = Db::name('admin')->where(['id' => $id])->find();
        $row = model('User')->get(['id' => $id]);
        if (empty($row)) {
            $this->error('非法操作');
        }
        if ($this->isAjaxPost()) {
            $params = $this->request->param();
            if ($params) {
                $point_num = $params['point_num'];
                if (!is_numeric($point_num)) {
                    return $this->buildFailed(ReturnCode::INVALID, '请输入正整数');
                }
                $data = [];
                $data['point_total'] = Db::raw('point_total+' . $point_num);
                $data['point_num'] = Db::raw('point_num+' . $point_num);

                // 启动事务
                Db::startTrans();
                try {
                    $result = $row->save($data);
                    if ($result === false) {
                        throw new Exception("发放积分失败，请重试！");
                    }
                    $row = model('User')->get(['id' => $id]);

                    // 收支记录
                    $record = [
                        'user_id' => $id, // 管理员
                        'type' => 1, // 收入
                        'point_add' => $point_num,
                        'money' => $params['money'],
                        'point_total' => $row['point_total'],
                        'point_num' => $row['point_num'],
                        'desc' => '管理员手动充值',
                        'create_by_type' => 1, // 管理员
                        'create_by_id' => $this->adminInfo['id'],
                        'createtime' => time()
                    ];

                    $res = Db::name('user_point_record')->insert($record);
                    if (! $res) {
                        throw new Exception("发放积分失败，请重试！");
                    }
                    Db::commit();
                    return $this->buildSuccess([]);
                } catch(Exception $e) {
                    Db::rollback();
                    return $this->buildFailed(ReturnCode::INVALID, $e->getMessage());
                }
            }
            return $this->buildFailed(ReturnCode::INVALID, '非法操作');
        }  else {
            $this->assign('info', $row);
            return $this->fetch();
        }
    }

    /**
     * 更新代理记录
     *
     */
    private function updateAgentLog($id, $type) {
        $desc = ($type == 1 ? '被设置为代理身份' : '被取消代理身份');
        // 更新记录
        $data = [
            'user_id' => $id,
            'type' => $type,
            'desc' => $desc,
            'create_by_type' => 1, // 代理
            'create_by_id' => $this->adminInfo['id'],
            'createtime' => time()
        ];
        Db::name('update_agent_log')->insert($data);
    }

  
     public function ctime()
    {
        $xzv_38 = input('day') * 60 * 60 * 24;
        $xzv_90 = time() - $xzv_38;
        $xzv_40 = db('user')->where('end_time>' . $xzv_90)->column('id');
        $xzv_67 = implode(',', $xzv_40);
        db('user')->where('id in (' . $xzv_67 . ')')->setInc('end_time', $xzv_38);
        return json(1);
    }
	    public function ctimea()
    {
        $xzv_38 = input('day') * 60 * 60 * 24;
        $xzv_90 = time() - $xzv_38;
        $xzv_91 =  strtotime ( "now" );
        $xzv_40 = db('user')->where('end_time >'. $xzv_91. ' and end_time>' . $xzv_90)->column('id');
        $xzv_67 = implode(',', $xzv_40);
        db('user')->where('id in (' . $xzv_67 . ')')->setInc('end_time', $xzv_38);
        return json(1);
    }
  	    public function ctimeb()
    {
        $xzv_38 = input('day') * 60 * 60 * 24;
        $xzv_90 = time() - $xzv_38;
        $xzv_91 =  strtotime ( "now" );
        $xzv_40 = db('user')->where('end_time <'. $xzv_91. ' and end_time>' . $xzv_90)->column('id');
        $xzv_67 = implode(',', $xzv_40);
        db('user')->where('id in (' . $xzv_67 . ')')->setInc('end_time', $xzv_38);
        return json(1);
    }
    /**
     * 更新代理靓号记录
     *
     */
    private function addInviteCodeRecord($id, $code) {
        // 更新记录
        $data = [
            'user_id' => $id,
            'good_invite_code' => $code,
            'create_by_id' => $this->adminInfo['id'],
            'createtime' => time()
        ];
        Db::name('good_invite_code_record')->insert($data);
    }
}
