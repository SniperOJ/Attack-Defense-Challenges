export FLASK_APP=main.py
export FLASK_DEBUG=0
# echo "[***] Running Flask"
/usr/bin/python3 /usr/local/bin/flask run --host 127.0.0.1 --port 8080 >/dev/null 2>&1 &
/bin/bash