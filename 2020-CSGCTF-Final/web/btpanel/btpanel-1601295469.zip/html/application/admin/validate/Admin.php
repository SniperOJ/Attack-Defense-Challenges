<?php
namespace app\admin\validate;

use think\Validate;

class Admin extends Validate {
    protected $rule = [
        'loginname' => 'require|max:20|unique:admin',
        'nickname' => 'require',
        'password' => 'require'
    ];

    protected $message = [
        'loginname.require' => '账号名称不能为空',
        'loginname.max' => '账号名称不能超过50个字符',
        'loginname.unique' => '此账号名称已存在',
        'nickname.require' => '昵称不能为空',
        'password.require' => '密码不能为空'
    ];

    protected $scene = [
        'add' => ['loginname', 'nickname', 'password'],
        'edit' => ['loginname', 'nickname', 'password']
    ];
}