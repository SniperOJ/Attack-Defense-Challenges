<?php
namespace app\admin\controller;

use think\Db;
use think\Request;
use think\Loader;
use think\Exception;
use app\common\util\ReturnCode;

class UserPointRecord extends Base {

    /**
     * 代理积分发放记录
     */
    public function records() {
        if ($this->isAjaxGet()) {
            $filter = [
                'username'  => $this->request->param('username'),
                'createname'  => $this->request->param('createname'),
                'starttime' => $this->request->param('starttime'),
                'endtime' => $this->request->param('endtime'),
            ];

            $model = model('UserPointRecord')->getAdminPushRecordList($filter, $this->limit);
            $recordList = $model->toArray();

            foreach ($recordList['data'] as $key => $value) {
                $recordList['data'][$key]['createtime'] = date('Y-m-d H:i:s', $value['createtime']);
            }

            $data = $recordList['data'];
            $count = $recordList['total'];
            return $this->buildTableSuccess($data, $count);
        } else {
            return $this->fetch();
        }
    }

    /**
     * 导出代理积分发放记录
     */
    public function exportRecords() {
        Loader::import('PHPExcel.Classes.PHPExcel');
        Loader::import('PHPExcel.Classes.PHPExcel.IOFactory.PHPExcel_IOFactory');
        $str = Request::instance()->param('str');
        if (!empty($str)) {
            $params = json_decode($str);
            $filter = [
                'username'  => $params->username,
                'createname'  => $params->createname,
                'starttime' => $params->starttime,
                'endtime' => $params->endtime
            ];
        } else {
            $filter = [
                'username'  => '',
                'createname'  => '',
                'starttime' => '',
                'endtime' => ''
            ];
        }

        $model = collection(model('UserPointRecord')->exportAdminPushRecordList($filter));

        $lists= $model->toArray();
        $newList = [];
        foreach ($lists as $key => $value) {
            $newList[] = [
                'id' => $value['id'],
                'point_add' => $value['point_add'],
                'money' => $value['money'],
                'to_user_name' => $value['to_user_name'],
                'createtime' => date('Y-m-d H:i:s', $value['createtime']),
                'create_name' => $value['create_name'],
            ];
        }
        $row_title = ['ID', '积分数量', '价格', '代理账号', '发放时间', '操作人'];
        array_unshift($newList, $row_title);

        $date = date('Y-m-d H i');
        $phpexcel = new \PHPExcel();
        $sheet    = $phpexcel->getActiveSheet();
        $sheet->setTitle("{$date}-管理员积分操作记录");
        $chr = [];
        for ($i='A'; $i<='Z'; $i++) {
            $chr[] = $i;
            if (sizeof($chr) >= sizeof($row_title)) break;
        }

        $i = 1;
        foreach ($newList as $val) {
            $z = 0;
            foreach ($val as $k=>$v) {
                $sheet->setCellValue($chr[$z].$i, $v);
                $z++;
            }
            $i++;
        }

        $write = \PHPExcel_IOFactory::createWriter($phpexcel, 'Excel5');
        header("Pragma: public");
        header("Expires: 0");
        header("Cache-Control:must-revalidate, post-check=0, pre-check=0");
        header("Content-Type:application/force-download");
        header("Content-Type:application/vnd.ms-execl");
        header("Content-Type:application/octet-stream");
        header("Content-Type:application/download");
        header("Content-Disposition:attachment;filename={$date}-管理员积分操作记录.xlsx");
        header("Content-Transfer-Encoding:binary");
        header('Cache-Control: max-age=0');
        $write->save('php://output');
        exit;
    }

        /**
     * [pushrecord 积分发放记录]
     */
    public function pushrecord() {
        if ($this->isAjaxGet()) {
            $filter = [
                'username'  => $this->request->param('username'),
                'createname'  => $this->request->param('createname'),
                'starttime' => $this->request->param('starttime'),
                'endtime' => $this->request->param('endtime'),
            ];

            $model = model('UserPointRecord')->getPushRecordList($filter, $this->limit);
            $recordList = $model->toArray();

            foreach ($recordList['data'] as $key => $value) {
                $recordList['data'][$key]['createtime'] = date('Y-m-d H:i:s', $value['createtime']);
            }

            $data = $recordList['data'];
            $count = $recordList['total'];
            return $this->buildTableSuccess($data, $count);
        } else {
            return $this->fetch();
        }
    }

    /**
     * [exportPushRecord 导出积分发放记录]
     */
    public function exportPushRecord() {
        Loader::import('PHPExcel.Classes.PHPExcel');
        Loader::import('PHPExcel.Classes.PHPExcel.IOFactory.PHPExcel_IOFactory');
        $str = Request::instance()->param('str');
        if (!empty($str)) {
            $params = json_decode($str);
            $filter = [
                'username'  => $params->username,
                'createname'  => $params->createname,
                'starttime' => $params->starttime,
                'endtime' => $params->endtime
            ];
        } else {
            $filter = [
                'username'  => '',
                'createname'  => '',
                'starttime' => '',
                'endtime' => ''
            ];
        }

        $model = collection(model('UserPointRecord')->exportPushRecordList($filter));

        $lists= $model->toArray();
        $newList = [];
        foreach ($lists as $key => $value) {
            $newList[] = [
                'id' => $value['id'],
                'point_add' => $value['point_add'],
                'money' => $value['money'],
                'to_user_name' => $value['to_user_name'],
                'createtime' => date('Y-m-d H:i:s', $value['createtime']),
                'create_name' => $value['create_name'],
            ];
        }
        $row_title = ['ID', '积分数量', '价格', '代理帐号', '发放时间', '操作人'];
        array_unshift($newList, $row_title);

        $date = date('Y-m-d H i');
        $phpexcel = new \PHPExcel();
        $sheet    = $phpexcel->getActiveSheet();
        $sheet->setTitle("{$date}-代理积分发放记录");
        $chr = [];
        for ($i='A'; $i<='Z'; $i++) {
            $chr[] = $i;
            if (sizeof($chr) >= sizeof($row_title)) break;
        }

        $i = 1;
        foreach ($newList as $val) {
            $z = 0;
            foreach ($val as $k=>$v) {
                $sheet->setCellValue($chr[$z].$i, $v);
                $z++;
            }
            $i++;
        }

        $write = \PHPExcel_IOFactory::createWriter($phpexcel, 'Excel5');
        header("Pragma: public");
        header("Expires: 0");
        header("Cache-Control:must-revalidate, post-check=0, pre-check=0");
        header("Content-Type:application/force-download");
        header("Content-Type:application/vnd.ms-execl");
        header("Content-Type:application/octet-stream");
        header("Content-Type:application/download");
        header("Content-Disposition:attachment;filename={$date}-代理积分发放记录.xlsx");
        header("Content-Transfer-Encoding:binary");
        header('Cache-Control: max-age=0');
        $write->save('php://output');
        exit;
    }
}