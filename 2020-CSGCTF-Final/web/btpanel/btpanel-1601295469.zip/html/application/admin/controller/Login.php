<?php
namespace app\admin\controller;

use think\Session;
use app\common\util\ReturnCode;

class Login extends Base {
    /**
     * 无需登录的方法
     */
    protected $noNeedLogin = ['index'];
    /**
     * 无需鉴权的方法,但需要登录
     */
    protected $noNeedRight = ['logout'];

    public function index()
    {
        if ($this->isAjaxPost()) {
            $loginname = $this->request->param('loginname');
            $password = $this->request->param('password');
            $vercode = $this->request->param('vercode');
            // if (!$loginname || !$password || $vercode) {
            //     return $this->buildFailed(ReturnCode::LOGIN_ERROR '未知参数');
            // }
            $res = $this->validate(
                [
                    'loginname' => $loginname,
                    'password' => $password,
                    'vercode' => $vercode
                ],
                [
                    'loginname' => 'require',
                    'password' => 'require',
                    'vercode' => 'require|captcha'
                ],
                [
                    'loginname.require' => '帐号不能为空',
                    'password.require' => '密码不能为空',
                    'vercode.require' => '验证码不能为空',
                    'vercode.captcha' => '验证码不正确',
                ]
            );
            if (true !== $res) {
                return $this->buildFailed(ReturnCode::LOGIN_ERROR, $res);
            }
            $adminModel = model('Admin');
            $adminInfo = $adminModel->get(['loginname' => $loginname]);
            if (!$adminInfo) {
                return $this->buildFailed(ReturnCode::LOGIN_ERROR, '帐号或密码不正确');
            }

            if ($adminInfo->password != $this->getEncryptPassword($password, $adminInfo->salt)) {
                return $this->buildFailed(ReturnCode::LOGIN_ERROR, '帐号或密码不正确');
            }

            if ($adminInfo->status != '1') {
                return $this->buildFailed(ReturnCode::LOGIN_ERROR, '帐号已被禁用，请联系管理员');
            }

            $adminInfo = $adminInfo->toArray();
            unset($adminInfo['password']);
            unset($adminInfo['salt']);
            // 记录登录状态
            Session::set('admin', $adminInfo);
            return $this->buildSuccess([], '登录成功');
        } else {
            return $this->fetch();
        }
    }

    /**
     * 退出登录
     */
    public function logout() {
        Session::delete("admin");
        $this->success('退出登录成功', url('Admin/Login/index'));
    }



    /**
     * 获取密码加密后的字符串
     * @param string $password  密码
     * @param string $salt      密码盐
     * @return string
     */
    private function getEncryptPassword($password, $salt = '')
    {
        return md5(md5($password) . $salt);
    }
}
