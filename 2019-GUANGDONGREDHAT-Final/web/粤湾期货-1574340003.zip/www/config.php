<?php
//mysql database address
define('DB_HOST','127.0.0.1');
//mysql database user
define('DB_USER','root');
//database password
define('DB_PASSWD','root');
//database name
define('DB_NAME','emlog');
//database prefix
define('DB_PREFIX','emlog_');
//auth key
define('AUTH_KEY','irj9ZuWF0Duc(LzwF9BCCJ86p&f%l%nm8ad914d4d99bdeb5f8cc9122fb81ae74');
//cookie name
define('AUTH_COOKIE_NAME','EM_AUTHCOOKIE_W5ybaCEXHdrHWkYBR6bvBATPe8K9inQP');
