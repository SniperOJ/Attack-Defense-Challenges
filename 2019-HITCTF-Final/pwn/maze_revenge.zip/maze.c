//gcc -fPIC -shared maze.c -o libmaze.so
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <time.h>
#include <math.h>
#include "maze.h"

void show_maze(Maze *mazep){
	char **data = mazep->data;
	unsigned int maze_sz = mazep->size;
    printf("maze size:%d, start(%d,%d), end(%d,%d)\n", maze_sz, mazep->start_x, mazep->start_y, mazep->end_x, mazep->end_y);
	fflush(stdout);
	int i,j;
	for(i=0; i<maze_sz; ++i){
		for(j=0; j<maze_sz; ++j){
			if(data[i][j] == ROUTE){
				write(1, ROUTE_CHAR, 1);
				// write(1, "xx", 2);
			}else{
				write(1, WALL_CHAR, 1);
				// write(1, "  ", 2);
			}
		}
		write(1, "\n", 1);
	}
}


void create_maze(Maze *mazep, int x, int y) {
#ifdef DEBUG
	printf("(%d, %d)\n", x, y);
	show_maze(mazep);
#endif
	char **data = mazep->data;

	//确保四个方向随机
	int direction[4][2] = { { 1,0 },{ -1,0 },{ 0,1 },{ 0,-1 } };
	for (int i = 0; i < 4; i++) {
		int r = rand() % 4;
		int temp = direction[0][0];
		direction[0][0] = direction[r][0];
		direction[r][0] = temp;
 
		temp = direction[0][1];
		direction[0][1] = direction[r][1];
		direction[r][1] = temp;
	}

    for (int i = 0; i < 4; i++) {
		int dx = x;
		int dy = y;
 
		//控制挖的距离，由Rank来调整大小
		int range = 1 ;
		while (range>0) {
			dx += direction[i][0];
			dy += direction[i][1];
 
			//排除掉回头路
			if (data[dx][dy] == ROUTE) {
				break;
			}
 
			//判断是否挖穿路径
			int count = 0;
			for (int j = dx - 1; j < dx + 2; j++) {
				for (int k = dy - 1; k < dy + 2; k++) {
					//abs(j - dx) + abs(k - dy) == 1 确保只判断九宫格的四个特定位置
					if (abs(j - dx) + abs(k - dy) == 1 && data[j][k] == ROUTE) {
						count++;
					}
				}
			}
 
			if (count > 1) {
				break;
			}
 
			//确保不会挖穿时，前进
			--range;
			data[dx][dy] = ROUTE;
		}
 
		//没有挖穿危险，以此为节点递归
		if (range <= 0) {
			create_maze(mazep, dx, dy);
		}
	}
}

Maze* init_maze(unsigned int maze_sz_p) {
	if (maze_sz_p > 1000)
		return (Maze *)NULL;
    write(1, "init maze ...\n", 14);
	char **data = malloc(sizeof(char*) * maze_sz_p);
	for (int i = 0; i < maze_sz_p; i++){
		data[i] = (char *) malloc(maze_sz_p);
    	memset(data[i], WALL, maze_sz_p);
	}
	Maze* mazep = (Maze*) malloc(sizeof(Maze));
	mazep->size = maze_sz_p;
	mazep->data = data;
    srand((unsigned)time(NULL));
	for (int i = 0; i < maze_sz_p; i++){
		data[i][0] = ROUTE;
		data[0][i] = ROUTE;
		data[i][maze_sz_p - 1] = ROUTE;
		data[maze_sz_p - 1][i] = ROUTE;
    }

    create_maze(mazep, 2, 1);
    
    // MAZE[1][0] = WALL;
    // MAZE[2][0] = WALL; // vuln
    data[2][1] = ROUTE; // entrance
    mazep->start_x = 2;
    mazep->start_y = 1;
	mazep->cur_x = mazep->start_x;
	mazep->cur_y = mazep->start_y;
    // exit
	for (int i = maze_sz_p - 3; i >= 0; i--) {
		if (data[i][maze_sz_p - 3] == ROUTE) {
			data[i][maze_sz_p - 2] = ROUTE;
		    mazep->end_x = i;
            mazep->end_y = maze_sz_p - 2;
            break;
		}
	}
	for (int i = 0; i < maze_sz_p; i++){
		data[i][0] = WALL;
		data[0][i] = WALL;
		data[i][maze_sz_p - 1] = WALL;
		data[maze_sz_p - 1][i] = WALL;
    }
	write(1, "maze init finished\n", 19);
	return mazep; //TODO
}

int walk_maze(Maze* mazep, char *steps, unsigned int step_cnt) {
	char **data = mazep->data;
	unsigned int maze_sz = mazep->size;

	for (int i=0; i<step_cnt; i++) {
		if (mazep->cur_x == mazep->end_x && mazep->cur_y == mazep->end_y)
			return 1;
		unsigned int x = mazep->cur_x;
		unsigned int y = mazep->cur_y;
		char op = steps[i] | 0x20; // lowcase
		if(op == '\x20') {
			break;
		}
		else if(op == 'a'){
			if (y < 2 || y >= maze_sz){
				#ifdef DEBUG				
				puts("invalid y");
				#endif
				return -1;
			}
			if (data[x][y-1] != ROUTE){
				#ifdef DEBUG				
				puts("wrong way");
				#endif
				return -1;
			}
			mazep->cur_y -= 1;
		} else if(op == 'w'){
			if (x < 2 || x >= maze_sz){
				#ifdef DEBUG				
				puts("invalid x");
				#endif
				return -1;
			}
			if (data[x-1][y] != 0){
				#ifdef DEBUG				
				puts("wrong way");
				#endif
				return -1;
			}
			mazep->cur_x -= 1;
		} else if(op == 'd'){
			if (y < 0 || y >= maze_sz-2){
				#ifdef DEBUG				
				puts("invalid y");
				#endif
				return -1;
			}			
			if (data[x][y+1] != 0){
				#ifdef DEBUG				
				puts("wrong way");
				#endif
				return -1;
			}
			mazep->cur_y += 1;
		} else if(op == 's'){
			if(x < 0 || x >= maze_sz-2){
				#ifdef DEBUG				
				puts("invalid x");
				#endif
				return -1;
			}
			if (data[x+1][y] != 0){
				#ifdef DEBUG				
				puts("wrong way");
				#endif
				return -1;
			}
			mazep->cur_x += 1;
		} else{
			puts("invalid op");
			exit(-1);
		}
	}
	if (mazep->cur_x == mazep->end_x && mazep->cur_y == mazep->end_y)
		return 1;
	return 0;
}