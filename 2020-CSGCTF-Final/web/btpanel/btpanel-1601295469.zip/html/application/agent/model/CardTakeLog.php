<?php
namespace app\agent\model;

use think\Model;
use think\Db;

class CardTakeLog extends Model {

    // 表名
    // protected $name = 'card_take_log';

    /**
     * [获取提卡记录]
     */
    public function getTakeLog($filter, $page_size = 10) {
        $result = $this->alias('a')
                ->where(function ($query) use (&$filter) {
                    $where = $query->where('a.id', 'gt', 0);
                    if ((bool)$filter['create_by_id']) {
                        $where->where('a.create_by_id', 'eq', $filter['create_by_id']);
                    }
                    if ((bool)$filter['id']) {
                        $where->where('a.id', 'eq', $filter['id']);
                    }
                    if ((bool)$filter['card_type']) {
                        $where->where('a.card_type', 'eq', $filter['card_type']);
                    }
                    if ((bool)$filter['starttime'] &&  (bool)$filter['endtime']) {
                        $where->whereTime('a.createtime', 'between', [strtotime($filter['starttime'] . ' 00:00:00'), strtotime($filter['endtime'] . ' 23:59:59')]);
                    } else {
                        if ((bool)$filter['starttime']) {
                            $where->whereTime('a.createtime', '>=', strtotime($filter['starttime'] . ' 00:00:00'));
                        }
                        if ((bool)$filter['endtime']) {
                            $where->whereTime('a.createtime', '<=', strtotime($filter['endtime'] . ' 23:59:59'));
                        }
                    }
                    
                })
                ->paginate($page_size);

        return $result;
    }


    /**
     * [导出提卡记录]
     */
    public function exportTakeLog($filter) {
        $result = $this->alias('a')
                ->where(function ($query) use (&$filter) {
                    $where = $query->where('a.id', 'gt', 0);
                    if ((bool)$filter['create_by_id']) {
                        $where->where('a.create_by_id', 'eq', $filter['create_by_id']);
                    }
                    if ((bool)$filter['id']) {
                        $where->where('a.id', 'eq', $filter['id']);
                    }
                    if ((bool)$filter['card_type']) {
                        $where->where('a.card_type', 'eq', $filter['card_type']);
                    }
                    if ((bool)$filter['starttime'] &&  (bool)$filter['endtime']) {
                        $where->whereTime('a.createtime', 'between', [strtotime($filter['starttime'] . ' 00:00:00'), strtotime($filter['endtime'] . ' 23:59:59')]);
                    } else {
                        if ((bool)$filter['starttime']) {
                            $where->whereTime('a.createtime', '>=', strtotime($filter['starttime'] . ' 00:00:00'));
                        }
                        if ((bool)$filter['endtime']) {
                            $where->whereTime('a.createtime', '<=', strtotime($filter['endtime'] . ' 23:59:59'));
                        }
                    }
                    
                })
                ->select();

        return $result;
    }
}