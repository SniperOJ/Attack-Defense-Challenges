<?php
// database host
$db_host   = "localhost:3306";

// database name
$db_name   = "maggish_pay";

// database username
$db_user   = "maggish_pay";

// database password
$db_pass   = "sDz(^qJ6PHlW";

// table prefix
$prefix    = "ecs_";

$timezone    = "Asia/Shanghai";

$cookie_path    = "/";

$cookie_domain    = "";

$session = "1440";

define('EC_CHARSET','utf-8');

define('ADMIN_PATH','admin');

define('AUTH_KEY', 'this is a key');

define('OLD_AUTH_KEY', '');

define('API_TIME', '2016-03-03 11:36:24');

?>