<?php
namespace app\agent\controller;

use think\Db;
use think\Exception;
use think\Session;
use app\common\util\ReturnCode;
use app\common\util\Random;

class Agent extends Base
{
    public function info() {
        $info = Db::name('user')->where(['id' => $this->agentInfo['id']])->find();
        $sysFreetime = intval(Db::name('config')->where(['group' => 'basic', 'name' => 'freetime'])->value('value'));
        if ($this->isAjaxPost()) {
            $freetime = $this->request->param('freetime');
            $password = $this->request->param('password');

            if ($freetime < 0 || $freetime > $sysFreetime) {
                return $this->buildFailed(ReturnCode::INVALID, '观看时长必须为0 - ' . $sysFreetime . '的整数');
            }
            if ($password) {
                $data['salt'] = Random::alnum();
                $data['password'] = md5(md5($password) . $data['salt']);
            }
            $data['freetime'] = $freetime;
            $res = Db::name('user')->where(['id' => $this->agentInfo['id']])->update($data);
            if ($res === false) {
                return $this->buildFailed(ReturnCode::ADD_FAILED, '修改失败');
            } else {
                return $this->buildSuccess([], '修改成功');
            }
        }
        $this->assign('info', $info);
        $this->assign('sysFreetime', $sysFreetime);
        return $this->fetch();
    }

    /**
     * 修改联系方式
     */
    public function contact() {
        $info = Db::name('user')->where(['id' => $this->agentInfo['id']])->find();
        if ($this->isAjaxPost()) {
            $is_online_buy = $this->request->param('is_online_buy');
            $contact = $this->request->param('contact');
            $desc = $this->request->param('desc');

            $month_url = $this->request->param('month_url');
            $season_url = $this->request->param('season_url');
            $year_url = $this->request->param('year_url');
            $forever_url = $this->request->param('forever_url');

            $buyData['month_url'] = $month_url;
            $buyData['season_url'] = $season_url;
            $buyData['year_url'] = $year_url;
            $buyData['forever_url'] = $forever_url;
            $userBuyLinkInfo = Db::name('user_buy_link')->where(['user_id' => $info['id']])->find();
            if (empty($userBuyLinkInfo)) {
                $buyData['user_id'] = $info['id'];
                $buyData['createtime'] = time();
                $res = Db::name('user_buy_link')->insert($buyData);
            } else {
                $res = Db::name('user_buy_link')->where(['user_id' => $info['id']])->update($buyData);
            }
            if ($res === false) {
                return $this->buildFailed(ReturnCode::UPDATE_FAILED, '修改失败');
            }

            $data['is_online_buy'] = $is_online_buy;
            $data['contact'] = $contact;
            $data['desc'] = $desc;
            $res = Db::name('user')->where(['id' => $this->agentInfo['id']])->update($data);
            if ($res === false) {
                return $this->buildFailed(ReturnCode::ADD_FAILED, '修改失败');
            } else {
                return $this->buildSuccess([], '修改成功');
            }
        } else {
            $urlInfo = Db::name('user_buy_link')->where(['user_id' => $info['id']])->find();
            $this->assign('urlInfo', $urlInfo);
            $this->assign('info', $info);
            return $this->fetch();
        }
    }

    /**
     * 修改登录手机号
     */
    public function editphone() {
        $phone = Db::name('user')->where(['id' => $this->agentInfo['id']])->value('username');
        $editCount = Db::name('phone_log')->where(['user_id' => $this->agentInfo['id']])->count();
        if ($this->isAjaxPost()) {
            $username = $this->request->param('username');
            if (! is_mobile($username)) {
                return $this->buildFailed(ReturnCode::INVALID, '请输入正确的手机号');
            }

            if ($editCount > 0) {
                return $this->buildFailed(ReturnCode::INVALID, '您已修改过一次手机号');
            }

            $info = Db::name('user')->where(['username' => $username])->value('username');
            if (! empty($info)) {
                return $this->buildFailed(ReturnCode::INVALID, '该手机已被注册');
            }
            // 启动事务
            Db::startTrans();
            try {
                $res = Db::name('user')->where(['id' => $this->agentInfo['id']])->update([
                    'username' => $username
                ]);

                if ($res === false) {
                    throw new Exception("修改失败");
                }

                $res = Db::name('phone_log')->insert([
                    'user_id' => $this->agentInfo['id'],
                    'old_phone' => $phone,
                    'phone' => $username,
                    'createtime' => time()
                ]);

                if ($res === false) {
                    throw new Exception("修改失败");
                }
                Session::delete("agent");
                Db::commit();
                return $this->buildSuccess([], '修改成功，请重新登录');
            } catch(Exception $e) {
                Db::rollback();
                return $this->buildFailed(ReturnCode::ADD_FAILED, $e->getMessage());
            }
        } else {
            $this->assign('phone', $phone);
            $this->assign('editCount', $editCount);
            return $this->fetch();
        }
    }
}
