<?php
namespace app\admin\controller;

use think\Db;
use app\common\util\ReturnCode;
use app\common\library\Tree;

use app\admin\model\AuthGroup;

class Group extends Base {
    /**
     * 无需鉴权的方法,但需要登录
     */
    protected $noNeedRight = ['roletree'];

    protected $model = null;
    //当前组别列表数据
    protected $groupdata = [];
    //当前登录管理员所有子组别
    protected $childrenGroupIds = [];

    public function _initialize() {
        parent::_initialize();

        $this->model = model('AuthGroup');

        $this->childrenGroupIds = $this->auth->getChildrenGroupIds(true);

        $groupList = collection(AuthGroup::where('id', 'in', $this->childrenGroupIds)->select())->toArray();
        
        Tree::instance()->init($groupList);
        $result = [];
        if ($this->auth->isSuperAdmin()) {
            $result = Tree::instance()->getTreeList(Tree::instance()->getTreeArray(0));
        } else {
            $groups = $this->auth->getGroups();
            foreach ($groups as $m => $n)
            {
                $result = array_merge($result, Tree::instance()->getTreeList(Tree::instance()->getTreeArray($n['pid'])));
            }
        }

        $groupName = [];
        foreach ($result as $k => $v)
        {
            $groupName[$v['id']] = $v['name'];
        }

        $this->groupdata = $groupName;

        $this->assign('groupdata', $this->groupdata);
    }

    public function index() {
        if ($this->isAjaxGet()) {

            $list = AuthGroup::all(array_keys($this->groupdata));
            $list = collection($list)->toArray();
            $groupList = [];
            foreach ($list as $k => $v)
            {
                $groupList[$v['id']] = $v;
            }
            $list = [];
            foreach ($this->groupdata as $k => $v)
            {
                if (isset($groupList[$k]))
                {
                    $groupList[$k]['name'] = $v;
                    $list[] = $groupList[$k];
                }
            }
            $data = $list;
            return $this->buildTableSuccess($data, 0);
        } else {
            return $this->fetch();
        }
    }

    public function add() {
        if ($this->isAjaxPost()) {
            $param = $this->request->param();
            $param['createtime'] = time();
            $param['updatetime'] = time();
            $res = Db::name('auth_group')->insert($param);
            if ($res === false) {
                return $this->buildFailed(ReturnCode::ADD_FAILED, '添加失败');
            }
            return $this->buildSuccess([], '添加成功');
        } else {
            return $this->fetch();
        }
    }

    public function edit($id = null) {
        
        if ($this->isAjaxPost()) {
            $params = $this->request->param();
            if (!isset($params['id']) || $params['id'] == 1) {
                return $this->buildFailed(ReturnCode::INVALID, '非法操作');
            }
            if (!in_array($params['pid'], $this->childrenGroupIds)) {
                return $this->buildFailed(ReturnCode::INVALID, '父组别不能是自身的子组别');
            }
            $params['rules'] = explode(',', $params['rules']);
            $parentmodel = model("AuthGroup")->get($params['pid']);
            if (!$parentmodel)
            {
                return $this->buildFailed(ReturnCode::INVALID, '父组别未找到');
            }
            // 父级别的规则节点
            $parentrules = explode(',', $parentmodel->rules);
            // 当前组别的规则节点
            $currentrules = $this->auth->getRuleIds();
            $rules = $params['rules'];
            // 如果父组不是超级管理员则需要过滤规则节点,不能超过父组别的权限
            $rules = in_array('*', $parentrules) ? $rules : array_intersect($parentrules, $rules);
            // 如果当前组别不是超级管理员则需要过滤规则节点,不能超当前组别的权限
            $rules = in_array('*', $currentrules) ? $rules : array_intersect($currentrules, $rules);
            $params['rules'] = implode(',', $rules);


            $data['pid'] = $params['pid'];
            $data['name'] = $params['name'];
            $data['rules'] = $params['rules'];
            $data['updatetime'] = time();
            $data['status'] = $params['status'];
            // $res = false;
            $res = Db::name('auth_group')->where(['id' => $params['id']])->update($data);
            if ($res === false) {
                return $this->buildFailed(ReturnCode::ADD_FAILED, '添加失败');
            }
            return $this->buildSuccess([], '添加成功');
        } else {
            $row = AuthGroup::get(['id' => $id]);
            if (empty($row) || $id == 1) {
                $this->error('非法操作');
            }
            $this->assign('row', $row);
            return $this->fetch();
        }
    }


    /**
     * 删除
     */
    public function del($ids = "")
    {
        if ($ids)
        {
            $ids = explode(',', $ids);
            $grouplist = $this->auth->getGroups();
            $group_ids = array_map(function($group) {
                return $group['id'];
            }, $grouplist);
            // 移除掉当前管理员所在组别
            $ids = array_diff($ids, $group_ids);

            // 循环判断每一个组别是否可删除
            $grouplist = $this->model->where('id', 'in', $ids)->select();
            $groupaccessmodel = model('AuthGroupAccess');
            foreach ($grouplist as $k => $v)
            {
                // 当前组别下有管理员
                $groupone = $groupaccessmodel->get(['group_id' => $v['id']]);
                if ($groupone)
                {
                    $ids = array_diff($ids, [$v['id']]);
                    continue;
                }
                // 当前组别下有子组别
                $groupone = $this->model->get(['pid' => $v['id']]);
                if ($groupone)
                {
                    $ids = array_diff($ids, [$v['id']]);
                    continue;
                }
            }
            if (!$ids)
            {
                return $this->buildFailed(ReturnCode::INVALID, '你不能删除含有子组和管理员的组');
            }
            $count = $this->model->where('id', 'in', $ids)->delete();
            if ($count)
            {
                return $this->buildSuccess([], '删除成功');
            }
        }
        return $this->buildFailed(ReturnCode::INVALID, '非法操作');
    }


    public function roletree() {
        $model = model('AuthGroup');
        $id = $this->request->post("id");
        $pid = $this->request->post("pid");
        $parentGroupModel = $model->get($pid);
        $currentGroupModel = NULL;
        if ($id)
        {
            $currentGroupModel = $model->get($id);
        }
        if (($pid || $parentGroupModel) && (!$id || $currentGroupModel))
        {
            $id = $id ? $id : NULL;
            $ruleList = collection(model('AuthRule')->order('weigh', 'desc')->select())->toArray();
            //读取父类角色所有节点列表
            $parentRuleList = [];
            if (in_array('*', explode(',', $parentGroupModel->rules)))
            {
                $parentRuleList = $ruleList;
            }
            else
            {
                $parentRuleIds = explode(',', $parentGroupModel->rules);
                foreach ($ruleList as $k => $v)
                {
                    if (in_array($v['id'], $parentRuleIds))
                    {
                        $parentRuleList[] = $v;
                    }
                }
            }

            //当前所有正常规则列表
            Tree::instance()->init($parentRuleList);


            //读取当前角色下规则ID集合
            $adminRuleIds = $this->auth->getRuleIds();
            //是否是超级管理员
            $superadmin = $this->auth->isSuperAdmin();
            //当前拥有的规则ID集合
            $currentRuleIds = $id ? explode(',', $currentGroupModel->rules) : [];
            if (!$id || !in_array($pid, Tree::instance()->getChildrenIds($id, TRUE)))
            {
                $parentRuleList = Tree::instance()->getTreeList(Tree::instance()->getTreeArray(0), 'name');

                $hasChildrens = [];
                foreach ($parentRuleList as $k => $v)
                {
                    if ($v['haschild'])
                        $hasChildrens[] = $v['id'];
                }
                $parentRuleIds = array_map(function($item) {
                    return $item['id'];
                }, $parentRuleList);
                $nodeList = [];

                foreach ($parentRuleList as $k => $v)
                {
                    if (!$superadmin && !in_array($v['id'], $adminRuleIds))
                        continue;
                    if ($v['pid'] && !in_array($v['pid'], $parentRuleIds))
                        continue;
                    $state = array('selected' => in_array($v['id'], $currentRuleIds) && !in_array($v['id'], $hasChildrens));
                    $nodeList[] = array('id' => $v['id'], 'parent' => $v['pid'] ? $v['pid'] : '#', 'text' =>  $v['title'], 'type' => 'menu', 'state' => $state);
                }

                return $this->buildSuccess($nodeList);
            }
            else
            {
                return $this->buildFailed(ReturnCode::ADD_FAILED, '父组别不能是它的子组别');
            }
        }
        else
        {
            return $this->buildFailed(ReturnCode::ADD_FAILED, '组别未找到');
        }
    }
}
