<?php
namespace app\agent\controller;

use think\Controller;
use think\Session;
use think\Request;
use think\Db;
use app\common\util\ReturnCode;

class Base extends Controller
{
    // 每页条数，默认为10
    protected $limit = 10;
    // 代理信息
    protected $agentInfo;
    /**
     * 无需登录的方法
     */
    protected $noNeedLogin = [];

    public function _initialize() {
        if (! $this->match($this->noNeedLogin)) {
            // 需要登录，则判断是否登录
            if (! $this->isLogin()) {
                $this->error('请先登录', url('Agent/Login/index'));
            }
        }
        $agentInfo = Session::get('agent');
        if ($agentInfo) {
            $is_agent = Db::name('user')->where(['id' => $agentInfo['id']])->value('is_agent');
            if ($is_agent != 1) {
                Session::delete("agent");
                $this->error('您已不是代理，请联系管理员后，重新登录', url('Agent/Login/index'));
            }
            $this->agentInfo = $agentInfo;
            $this->assign('agentInfo', $agentInfo);
        }
        $this->limit = $this->request->param('limit', 10);
        $sitename = Db::name('config')->where(['group' => 'basic', 'name' => 'sitename'])->value('value');
        $this->assign('sitename', $sitename);
    }

    protected function buildSuccess($data, $msg = '操作成功', $code = ReturnCode::SUCCESS) {
        $return = [
            'code' => $code,
            'count' => 1000,
            'msg'  => $msg,
            'data' => $data
        ];

        return json($return);
    }

    protected function buildTableSuccess($data, $count, $msg = '操作成功', $code = ReturnCode::SUCCESS) {
        $return = [
            'code' => $code,
            'count' => $count,
            'msg'  => $msg,
            'data' => $data
        ];

        return json($return);
    }

    protected function buildFailed($code, $msg, $data = []) {
        $return = [
            'code' => $code,
            'msg'  => $msg,
            'data' => $data
        ];

        return json($return);
    }

    protected function isAjaxGet() {
        return ($this->request->isAjax() && $this->request->isGet()) ? true : false;
    }

    protected function isAjaxPost() {
        return ($this->request->isAjax() && $this->request->isPost()) ? true : false;
    }

    /**
     * 检测当前控制器和方法是否匹配传递的数组
     *
     * @param array $arr 需要验证权限的数组
     * @return boolean
     */
    private function match($arr = []) {
        $request = Request::instance();
        $arr = is_array($arr) ? $arr : explode(',', $arr);
        if (!$arr)
        {
            return FALSE;
        }
        $arr = array_map('strtolower', $arr);
        // 是否存在
        if (in_array(strtolower($request->action()), $arr) || in_array('*', $arr))
        {
            return TRUE;
        }

        // 没找到匹配
        return FALSE;
    }

    /**
     * 检验是否已经登录
     */
    private function isLogin() {
        $agentInfo = Session::get('agent');
        if (empty($agentInfo)) {
            return false;
        }
        return true;
    }
}
