#!/usr/bin/env python
# encoding:utf-8

from config import ProdConfig
from webapp import create_app

app = create_app(ProdConfig)

if __name__ == "__main__":
    app.run()
