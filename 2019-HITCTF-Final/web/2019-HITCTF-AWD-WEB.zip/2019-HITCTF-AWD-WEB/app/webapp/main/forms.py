#!/usr/bin/env python
# encoding:utf-8

from wtforms import StringField,SubmitField
from flask_wtf import Form
from wtforms.validators import Required,Length

class MessageboardForm(Form):
    content = StringField('内容',validators=[Required(),Length(max=64)])
    submit = SubmitField('提交')
