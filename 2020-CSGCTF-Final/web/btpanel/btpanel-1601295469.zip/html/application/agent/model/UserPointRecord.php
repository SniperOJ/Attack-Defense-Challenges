<?php
namespace app\agent\model;

use think\Model;
use think\Db;

class UserPointRecord extends Model {

    // 表名
    // protected $name = 'user_point_record';

    /**
     * [代理积分操作记录]
     *
     * @since  2018-06-15
     */
    public function getRecordList($filter, $page_size = 10) {
        $result = $this->alias('a')
            ->field([
                'a.id',
                'a.user_id',
                'a.type',
                'a.point_use',
                'a.use_type',
                'a.desc',
                'a.createtime',
                'b.username' => 'to_user_name'
            ])
            ->join('user b', 'b.id=a.user_id', 'LEFT')
            ->where('a.type', 'eq', 2)
            ->where('a.create_by_type', 2)
            ->where(function ($query) use (&$filter) {
                $where = $query->where('a.id', 'gt', 0);
                if ((bool)$filter['create_by_id']) {
                    $where->where('a.create_by_id', 'eq', $filter['create_by_id']);
                }
                if ((bool)$filter['username']) {
                    $where->where('b.username', 'like', '%' . $filter['username'] . '%');
                }
            })
            ->order('a.id desc')
            ->paginate($page_size);

        return $result;
    }


    /**
     * [导出代理积分操作记录]
     *
     * @since  2018-06-15
     */
    public function exportRecordList($filter) {
        $result = $this->alias('a')
            ->field([
                'a.id',
                'a.user_id',
                'a.type',
                'a.point_use',
                'a.use_type',
                'a.desc',
                'a.createtime',
                'b.username' => 'to_user_name'
            ])
            ->join('user b', 'b.id=a.user_id', 'LEFT')
            ->where('a.type', 'eq', 2)
            ->where('a.create_by_type', 2)
            ->where(function ($query) use (&$filter) {
                $where = $query->where('a.id', 'gt', 0);
                if ((bool)$filter['create_by_id']) {
                    $where->where('a.create_by_id', 'eq', $filter['create_by_id']);
                }
                if ((bool)$filter['username']) {
                    $where->where('b.username', 'like', '%' . $filter['username'] . '%');
                }
            })
            ->select();

        return $result;
    }
}