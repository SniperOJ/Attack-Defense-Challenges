<?php
namespace app\admin\controller;

use think\Db;
use app\common\util\ReturnCode;
/**
 * 卫视模块
 */
class Tv extends Base {
    /**
     * 卫视直播观看地址
     */
    public function info() {
        $tvLink = Db::name('config')->where(['group' => 'tv', 'name' => 'tv_link'])->value('value');
        $this->assign('tvLink', $tvLink);
        return $this->fetch();
    }

    /**
     * 更新卫视直播观看地址
     */
    public function updateInfo() {
        if ($this->isAjaxPost()) {
            $tv_link = $this->request->param('tv_link');
           
            $res = Db::name('config')
                ->where('group', 'eq', 'tv')
                ->where('name', 'eq', 'tv_link')
                ->update([
                    'value' => $tv_link
                ]);
            
            if ($res === false) {
                return $this->buildFailed(ReturnCode::UPDATE_FAILED, '保存失败');
            }
            return $this->buildSuccess([], '保存成功');
        } else {
            return $this->buildFailed(ReturnCode::INVALID, '非法操作');
        }
    }

    /**
     * vip影视
     */
    public function vip() {
        $vipLink = Db::name('config')->where(['group' => 'tv', 'name' => 'vip_link'])->value('value');
      	$vipInterface = Db::name('config')->where(['group' => 'tv', 'name' => 'vip_interface'])->value('value');
        $this->assign('vipLink', $vipLink);
        $this->assign('vipInterface', $vipInterface);
        return $this->fetch();
    }

    /**
     * 更新vip影视
     */
    public function updateVip() {
        if ($this->isAjaxPost()) {
            $vip_link = $this->request->param('vip_link');
            $vip_interface = $this->request->param('vip_interface');
          
            $res = Db::name('config')
                ->where('group', 'eq', 'tv')
                ->where('name', 'eq', 'vip_link')
                ->update([
                    'value' => $vip_link
                ]);
          
            $res2 = Db::name('config')
                ->where('group', 'eq', 'tv')
                ->where('name', 'eq', 'vip_interface')
                ->update([
                    'value' => $vip_interface
                ]);
            
            if ($res === false || $res2 === false) {
                return $this->buildFailed(ReturnCode::UPDATE_FAILED, '保存失败');
            }
            return $this->buildSuccess([], '保存成功');
        } else {
            return $this->buildFailed(ReturnCode::INVALID, '非法操作');
        }
    }
  
    /**
     * vip影视九宫格
     */
    public function cate() {
        if ($this->isAjaxGet()) {
            $filter = [
            ];
            $model = model('Tv')->getTvList($filter, $this->limit);
            $list = $model->toArray();
            $data = $list['data'];
            $count = $list['total'];
             //print_r($data);
            // exit();  
            return $this->buildTableSuccess($data, $count);
        } else {
            return $this->fetch();
        }
    }
    /**
     * vip影视九宫格（删除）
     */
    public function del() {
        if ($this->isAjaxPost()) {
            $id = $this->request->param('id', 0);
            if (! $id) {
                return $this->buildFailed(ReturnCode::INVALID, '非法操作');
            }
            $res = Db::name('tv_cate')->where(['id' => array('in', $id)])->delete();
            if ($res === false) {
                return $this->buildFailed(ReturnCode::DELETE_FAILED, '删除失败');
            } else {
                return $this->buildSuccess([]);
            }
        } else {
            return $this->buildFailed(ReturnCode::INVALID, '非法操作');
        }
    }
  
    /**
     * vip影视九宫格（添加）
     */
    public function add() {
        if ($this->isAjaxPost()) {
            $params = $this->request->param();

            $data = [
                'title' => $params['title'],
                'image' => $params['image'],
                'link' => $params['link'],
                'sort' => $params['sort']
                /*'filename' => basename($params['link']),
                'cate_id' => $params['cate_id'],
                'create_by_id' => $this->adminInfo['id'],
                'createtime' => time()*/
            ];
            $id = Db::name('tv_cate')->insertGetId($data);
            if ($id) {
                return $this->buildSuccess([]);
            } else {
                return $this->buildFailed(ReturnCode::ADD_FAILED, '添加失败');
            }
        } else {
            $cateList = Db::name('video_cate')->where(['is_deleted' => 0])->select();
            
            $this->assign('cateList', $cateList);
            return $this->fetch();
        }
    }
  
    /**
     * vip影视九宫格（编辑）
     */
    public function edit() {
        $id = $this->request->param('id', 0);
        if (! $id) {
            $this->error('非法操作1');
        }
        $info = Db::name('tv_cate')->where(['id' => $id])->find();
        if (empty($info)) {
            $this->error('非法操作2');
        }
        if ($this->isAjaxPost()) {
            $params = $this->request->param();

            $data = [
                'id' => $params['id'],
                'title' => $params['title'],
                'image' => $params['image'],
                'sort' => $params['sort'],
                'link' => $params['link']
            ];

            $res = Db::name('tv_cate')->where(['id' => $id])->update($data);
            if ($res === false) {
                return $this->buildFailed(ReturnCode::ADD_FAILED, '编辑失败');
            } else {
                return $this->buildSuccess([]);
            }
        } else {
            

            $this->assign('info', $info);
            return $this->fetch();
        }
    }
}