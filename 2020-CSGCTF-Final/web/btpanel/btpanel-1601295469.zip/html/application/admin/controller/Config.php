<?php
namespace app\admin\controller;

use think\Db;
use think\Exception;
use app\Common\Util\ReturnCode;

class Config extends Base
{
    /**
     * 查看App配置信息
     */
    public function info() {
        $result = Db::name('config')->where(['group' => ['in', ['basic', 'app', 'maintain']]])->select();
        $info = [];
        foreach ($result as $key=>$val) {
            $info[$val['group']][$val['name']] = [
                'value' => $val['value'],
                'title' => $val['title']
            ];
        }
        $this->assign('info', $info);
        return $this->fetch();
    }

    /**
     * 更新App配置信息
     */
    public function updateInfo() {
        if ($this->isAjaxPost()) {
            $params = $this->request->param();

            if (isset($params['basic']) && !empty($params['basic'])) {
                foreach ($params['basic'] as $key=>$val) {
                    Db::name('config')
                        ->where('group', 'eq', 'basic')
                        ->where('name', 'eq', $key)
                        ->update([
                            'value' => $val
                        ]);
                  //设置采集地址
                    if($key == 'interface1'){   
                        $interfaceArr = explode(";",$val);
                        Db::name('live_interface')
                          ->where('id', 'eq', $key+1)
                          ->update([
                            'live_url' => $interfaceArr[0],
                            'anchor_url' => $interfaceArr[1]
                          ]);
                    }
                    if($key == 'interface2'){           
                        $interfaceArr = explode(";",$val);
                        Db::name('live_interface')
                          ->where('id', 'eq', $key+2)
                          ->update([
                            'live_url' => $interfaceArr[0],
                            'anchor_url' => $interfaceArr[1]
                          ]);
                    }
                    if($key == 'interface3'){           
                        $interfaceArr = explode(";",$val);
                        Db::name('live_interface')
                          ->where('id', 'eq', $key+3)
                          ->update([
                            'live_url' => $interfaceArr[0],
                            'anchor_url' => $interfaceArr[1]
                          ]);
                    }
                    if($key == 'interface4'){           
                        $interfaceArr = explode(";",$val);
                        Db::name('live_interface')
                          ->where('id', 'eq', $key+4)
                          ->update([
                            'live_url' => $interfaceArr[0],
                            'anchor_url' => $interfaceArr[1]
                          ]);
                    }
                }
            }

            if (isset($params['app']) && !empty($params['app'])) {
                foreach ($params['app'] as $key=>$val) {
                Db::name('config')
                    ->where('group', 'eq', 'app')
                    ->where('name', 'eq', $key)
                    ->update([
                        'value' => $val
                    ]);
                }
            }

            if (isset($params['maintain']) && !empty($params['maintain'])) {
                foreach ($params['maintain'] as $key=>$val) {
                Db::name('config')
                    ->where('group', 'eq', 'maintain')
                    ->where('name', 'eq', $key)
                    ->update([
                        'value' => $val
                    ]);
                }
            }
            
            return $this->buildSuccess(['data'=>$params]);
        } else {
            return $this->buildFailed(ReturnCode::INVALID, '非法操作');
        }
    }

    /**
     * 兑换卡积分设置
     */
    public function point() {
        $result = Db::name('config')->where(['group' => 'card'])->select();
        $info = [];
        foreach ($result as $key=>$val) {
            $info[$val['group']][$val['name']] = [
                'value' => $val['value'],
                'title' => $val['title']
            ];
        }
        $this->assign('info', $info);
        return $this->fetch();
    }

    /**
     * 更新兑换卡积分
     */
    public function updatePoint() {
        if ($this->isAjaxPost()) {
            $params = $this->request->param();
            if (!isset($params['card']) || empty($params['card'])) {
                $this->buildFailed(ReturnCode::INVALID, '非法操作');
            }
            foreach ($params['card'] as $key=>$val) {
                Db::name('config')
                    ->where('group', 'eq', 'card')
                    ->where('name', 'eq', $key)
                    ->update([
                        'value' => $val
                    ]);
            }
            return $this->buildSuccess([]);
        } else {
            return $this->buildFailed(ReturnCode::INVALID, '非法操作');
        }
    }
    
    /**
     * 查看直播接口域名
     */
    public function live() {
        $lists = Db::name('live_interface')->where(['is_deleted' => 0])->field(['id', 'name', 'is_use'])->select();
        $this->assign('lists', $lists);
        return $this->fetch();
    }

    /**
     * 更新直播接口域名
     */
    public function updateLive() {
        if ($this->isAjaxPost()) {
            $id = $this->request->param('id');
            if (empty($id)) {
                $this->buildFailed(ReturnCode::INVALID, '非法操作');
            }
            $row = Db::name('live_interface')->where(['id' => $id])->find();
            if (empty($row)) {
                $this->buildFailed(ReturnCode::INVALID, '非法操作');
            }

            Db::startTrans();
            try {
                $res = Db::name('live_interface')->where(['id' => $id])->update([
                    'is_use' => 1
                ]);
                if ($res === false) {
                    throw new Exception('保存失败');
                }
                // 如果启用某个接口域名，则其它接口域名自动设为禁用
                $res = Db::name('live_interface')->where('id', 'neq', $id)->update(['is_use' => 0]);
                if ($res === false) {
                    throw new Exception('保存失败');
                }
                Db::commit();
                return $this->buildSuccess([], '保存成功');
            } catch (Exception $e) {
                Db::rollback();
                return $this->buildFailed(ReturnCode::UPDATE_FAILED, $e->getMessage());
            }
        } else {
            return $this->buildFailed(ReturnCode::INVALID, '非法操作');
        }
    }
}
