<?php
namespace app\admin\controller;

use think\Request;
use think\Db;
use app\common\util\ReturnCode;

/**
 * 视频模块
 */
class Video extends Base {
    public function index() {
        if ($this->isAjaxGet()) {
            $filter = [
                'title'      => $this->request->param('title'),
                'cate_name'  => $this->request->param('cate_name')
            ];
            $model = model('Video')->getVideoList($filter, $this->limit);
            $list = $model->toArray();
            foreach ($list['data'] as $key => $value) {
                $list['data'][$key]['createtime'] = date('Y-m-d H:i:s', $value['createtime']);
                $list['data'][$key]['filesize'] = format_bytes($value['filesize']);
            }
            $data = $list['data'];
            $count = $list['total'];
            // print_r($data);
            // exit();  
            return $this->buildTableSuccess($data, $count);
        } else {
          	$videoInterface = Db::name('config')->where(['group' => 'video', 'name' => 'video_interface'])->value('value');
          	$this->assign('videoInterface', $videoInterface);
            return $this->fetch();
        }
    }

    public function add() {
        if ($this->isAjaxPost()) {
            $params = $this->request->param();

            $data = [
                'title' => $params['title'],
                'image' => $params['image'],
                'link' => $params['link'],
                'filename' => basename($params['link']),
                'cate_id' => $params['cate_id'],
                'create_by_id' => $this->adminInfo['id'],
                'createtime' => time()
            ];
            $id = Db::name('video')->insertGetId($data);
            if ($id) {
                return $this->buildSuccess([]);
            } else {
                return $this->buildFailed(ReturnCode::ADD_FAILED, '添加失败');
            }
        } else {
            $cateList = Db::name('video_cate')->where(['is_deleted' => 0])->select();
            
            $this->assign('cateList', $cateList);
            return $this->fetch();
        }
    }

    public function edit() {
        $id = $this->request->param('id', 0);
        if (! $id) {
            $this->error('非法操作');
        }
        $info = Db::name('video')->where(['id' => $id])->find();
        if (empty($info)) {
            $this->error('非法操作');
        }
        if ($this->isAjaxPost()) {
            $params = $this->request->param();
            $data = [
                'title' => $params['title'],
                'image' => $params['image'],
                'link' => $params['link'],
                'filename' => basename($params['link']),
                'cate_id' => $params['cate_id']
            ];

            $res = Db::name('video')->where(['id' => $id])->update($data);
            if ($res === false) {
                return $this->buildFailed(ReturnCode::ADD_FAILED, '编辑失败');
            } else {
                return $this->buildSuccess([]);
            }
        } else {
            $cateList = Db::name('video_cate')->where(['is_deleted' => 0])->select();
            $this->assign('info', $info);
            $this->assign('cateList', $cateList);
            return $this->fetch();
        }
    }
  
    public function tuijian() {
        $id = $this->request->param('id', 0);
        if (! $id) {
            $this->error('非法操作');
        }
        $info = Db::name('video')->where(['id' => $id])->find();
        if (empty($info)) {
            $this->error('非法操作');
        }
        if ($this->isAjaxPost()) {
            $params = $this->request->param();
            $data = [
                'sort' => $params['sort'],
            ];

            $res = Db::name('video')->where(['id' => $id])->update($data);
            if ($res === false) {
                return $this->buildFailed(ReturnCode::ADD_FAILED, '编辑失败');
            } else {
                return $this->buildSuccess([]);
            }
        } else {
            $cateList = Db::name('video_cate')->where(['is_deleted' => 0])->select();
            $this->assign('info', $info);
            $this->assign('cateList', $cateList);
            return $this->fetch();
        }
    }

    public function del() {
        if ($this->isAjaxPost()) {
            $id = $this->request->param('id', 0);
            if (! $id) {
                return $this->buildFailed(ReturnCode::INVALID, '非法操作');
            }
            $res = Db::name('video')->where(['id' => array('in', $id)])->delete();
            if ($res === false) {
                return $this->buildFailed(ReturnCode::DELETE_FAILED, '删除失败');
            } else {
                return $this->buildSuccess([]);
            }
        } else {
            return $this->buildFailed(ReturnCode::INVALID, '非法操作');
        }
    }
  
    /**
     * 更改视频解析接口
     */
    public function jiekou() {
        if ($this->isAjaxPost()) {
            $video_interface = $this->request->param('video_interface');
          
          
            $res = Db::name('config')
                ->where('group', 'eq', 'video')
                ->where('name', 'eq', 'video_interface')
                ->update([
                    'value' => $video_interface
                ]);
            
            if ($res === false) {
                return $this->buildFailed(ReturnCode::UPDATE_FAILED, '保存失败');
            }
            return $this->buildSuccess([], '保存成功');
        } else {
            return $this->buildFailed(ReturnCode::INVALID, '非法操作');
        }
    }

    /**
     * 导出视频列表
     */
    public function exporVideo() {
        import('PHPExcel.Classes.PHPExcel');
        import('PHPExcel.Classes.PHPExcel.IOFactory.PHPExcel_IOFactory');
        $str = Request::instance()->param('str');
        if (!empty($str)) {
            $params = json_decode($str);
            $filter = [
                'title' => $params->title,
                'cate_name'  => $this->request->param('cate_name')
            ];
        } else {
            $filter = [
                'title' => '',
                'cate_name'  => ''
            ];
        }

        $model = collection(model('Video')->exportVideoList($filter));

        $videoList = $model->toArray();

        $newList = [];
        foreach ($videoList as $key => $value) {
            $newList[] = [
                'id' => $value['id'],
                'title' => $value['title'],
                'link' => $value['link'],
                'image' => url_domain($value['image']),
                'cate_name' => $value['cate_name']
            ];
        }
        $row_title = ['ID', '标题', '视频', '图片','视频分类'];
        array_unshift($newList, $row_title);

        $date = date('Y-m-d H i');
        $phpexcel = new \PHPExcel();
        $sheet    = $phpexcel->getActiveSheet();
        $sheet->setTitle("{$date}-视频记录");
        $chr = [];
        for ($i='A'; $i<='Z'; $i++) {
            $chr[] = $i;
            if (sizeof($chr) >= sizeof($row_title)) break;
        }

        $i = 1;
        foreach ($newList as $val) {
            $z = 0;
            foreach ($val as $k=>$v) {
                $sheet->setCellValue($chr[$z].$i, $v);
                $z++;
            }
            $i++;
        }

        $write = \PHPExcel_IOFactory::createWriter($phpexcel, 'Excel5');
        header("Pragma: public");
        header("Expires: 0");
        header("Cache-Control:must-revalidate, post-check=0, pre-check=0");
        header("Content-Type:application/force-download");
        header("Content-Type:application/vnd.ms-execl");
        header("Content-Type:application/octet-stream");
        header("Content-Type:application/download");
        header("Content-Disposition:attachment;filename={$date}-视频记录.xlsx");
        header("Content-Transfer-Encoding:binary");
        header('Cache-Control: max-age=0');
        $write->save('php://output');
        exit;
    }
  
}