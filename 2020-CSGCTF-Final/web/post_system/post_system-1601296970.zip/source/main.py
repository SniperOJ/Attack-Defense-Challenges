# -*- coding:utf-8 -*-

import sqlite3
import time

from flask import Flask,render_template,render_template_string,url_for,session,redirect,request
from functools import wraps
from flask_wtf import CSRFProtect,Form

from wtforms import StringField,PasswordField
from wtforms.validators import DataRequired,Length,EqualTo,Regexp
from wtforms import ValidationError

# check login logic

def init_db():
    con = sqlite3.connect(web.config['DB_FILE'])
    cur = con.cursor()
    sql = "CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY NOT NULL,username TEXT,password TEXT)"
    cur.execute(sql)
    con.commit()
    sql = "CREATE TABLE IF NOT EXISTS posts(id INTEGER PRIMARY KEY NOT NULL,uid INTEGER,title TEXT,content TEXT,timing TEXT)"
    cur.execute(sql)
    con.commit()
    cur.close()
    con.close()

def insert(sql,query):
    con = sqlite3.connect(web.config['DB_FILE'])
    cur = con.cursor()
    cur.execute(sql,query)
    con.commit()
    cur.close()
    con.close()

def select_bool(sql,query):
    con = sqlite3.connect(web.config['DB_FILE'])
    cur = con.cursor()
    cur.execute(sql,query)
    data = cur.fetchone()
    cur.close()
    con.close()
    if data:
        return True
    else:
        return False

def select_data(sql,query):
    con = sqlite3.connect(web.config['DB_FILE'])
    cur = con.cursor()
    cur.execute(sql,query)
    data = cur.fetchall()
    cur.close()
    con.close()
    if data:
        return data
    else:
        return False

# return json data
def tojson(**kwargs):
    data ='{'
    #print(len(kwargs))
    i = 1
    for k,v in kwargs.items():
        if i <len(kwargs):
            data = data + '"%s":"%s",' %(k,v)
        else:
            data = data + '"%s":"%s"' %(k,v)
        i = i + 1
    data = data + '}'
    #print(data)
    return data


def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if session.get("username")==None:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

# config

class Config:
    debug = True
    SECRET_PASSWORD_SALT = "CHUNQIU_GAME_135f1eb7"
    SECRET_KEY = "CHUNQIU_GAME_68af70837d82"
    DB_FILE = "./post.db"

#register form

class RegisterForms(Form):
    username = StringField(
        "username",
        validators=[
            DataRequired(message=u"请输入用户名"),
            Length(min=6, max=16, message=u"用户名长度：6~16个字符")
        ]
    )

    password = PasswordField(
        "password",
        validators=[
            DataRequired(message=u"请输入密码"),
            Length(min=8, max=18, message=u"密码长度：8~18个字符")
        ]
    )
    repeat = PasswordField(
        "repeat",
        validators=[
            DataRequired(message=u"请确认密码"),
            EqualTo('password', u"两次输入密码不一致")
        ]
    )

    @staticmethod
    def validate_username(form, field):
        if not field.data.isalnum():
            raise ValidationError(u"用户名只允许数字和字母")


# login form

class LoginForms(Form):
    username = StringField(
        "username",
        validators=[
            DataRequired(message=u"请输入用户名"),
            Length(min=6, max=16, message=u"用户名长度：6~16个字符")
        ]
    )

    password = PasswordField(
        "password",
        validators=[
            DataRequired(message=u"请输入密码"),
            Length(min=8, max=18, message=u"密码长度：6~12个字符")
        ]
    )

    @staticmethod
    def validate_username(form, field):
        if not field.data.isalnum():
            raise ValidationError(u"用户名只允许数字和字母")

class PostForms(Form):
    title = StringField(
        "title",
        validators=[
            DataRequired(message=u"请输入标题"),
            Length(min=1, max=32, message=u"标题长度：1~32个字符"),
            Regexp('^[\w\(\)\.\{\}\ \-]+$',0,message=u"请输入符合规则的字符")
        ]
    )

    content = PasswordField(
        "content",
        validators=[
            DataRequired(message=u"请输入内容"),
            Length(min=1, max=255, message=u"内容长度：1~255个字符"),
            Regexp('^[\w\(\)\.\{\}\ \-]+$',0,message=u"请输入符合规则的字符")
        ]
    )


'''
Flask main logic
'''


web = Flask(__name__,static_folder="./static/", template_folder="./templates/")

web.config.from_object(Config)

CSRFProtect(web)

'''
init db
'''

init_db()


@web.before_request
def delete_timeout_data():
    con = sqlite3.connect(web.config['DB_FILE'])
    cur = con.cursor()
    sql = "DELETE FROM posts WHERE timing < "+str(int(time.time())-180)
    #print(sql)
    cur.execute(sql)
    #print(cur.fetchall())
    con.commit()
    cur.close()
    con.close()

@web.route('/',methods=['GET'])
@web.route('/index',methods=['GET'])
def index():
    return render_template('index.tpl')

@web.route('/login',methods=['GET','POST'])
def login():
    if 'username' in session:
        return redirect(url_for('index'))
    if request.method == 'GET':
        return render_template('login.tpl')
    if request.method == 'POST':
        form = LoginForms()
        if form.validate_on_submit():
            username = form.username.data
            password = form.password.data
            sql = "SELECT * FROM users WHERE username = ? AND password = ?"
            result = select_bool(sql,(username,password,))
            if result:
                tmp_user = select_data(sql,(username,password,))
                data = tojson(code=200,msg=u"登陆成功")
                session['username'] = tmp_user[0][1]
                session['uid'] = tmp_user[0][0]
                return render_template_string(data),200,[('Content-Type','application/json; charset=utf-8')]
            else:
                data = tojson(code=500,msg=u"登陆失败")
                return render_template_string(data),200,[('Content-Type','application/json; charset=utf-8')]
        else:
            for field_name, error_message in form.errors.items():
                for error in error_message:
                    data = tojson(code=500,msg=error)
                    return render_template_string(data),200,[('Content-Type','application/json; charset=utf-8')]


@web.route('/register',methods=['GET','POST'])
def register():
    if 'username' in session:
        return redirect(url_for('index'))
    if request.method == 'GET':
        return render_template('register.tpl')
    if request.method == 'POST':
        form = RegisterForms()
        if form.validate_on_submit():
            username = form.username.data
            password = form.password.data
            sql = "SELECT * FROM users WHERE username = ?"
            result = select_bool(sql,(username,))
            if result:
                data = tojson(code=500,msg=u"用户名已存在")
                return render_template_string(data),200,[('Content-Type','application/json; charset=utf-8')]
            else:
                sql = "INSERT INTO users VALUES(null,?,?)"
                insert(sql,(username,password,))
                data = tojson(code=200,msg=u"注册成功")
                return render_template_string(data),200,[('Content-Type','application/json; charset=utf-8')]
        else:
            for field_name, error_message in form.errors.items():
                for error in error_message:
                    data = tojson(code=500,msg=error)
                    return render_template_string(data),200,[('Content-Type','application/json; charset=utf-8')]


@web.route('/post',methods=['GET','POST'])
@login_required
def post():
    if request.method == 'GET':
        return render_template('post.tpl')
    if request.method == 'POST':
        form = PostForms()
        if form.validate_on_submit():
            title = form.title.data
            content = form.content.data
            uid = session['uid']
            timing = int(time.time())
            sql = "INSERT INTO posts VALUES(null,?,?,?,?)"
            insert(sql,(uid,title,content,timing,))
            data = tojson(code=200,msg=u"写入成功")
            return render_template_string(data),200,[('Content-Type','application/json; charset=utf-8')]
        else:
            for field_name, error_message in form.errors.items():
                for error in error_message:
                    data = tojson(code=500,msg=error)
                    return render_template_string(data),200,[('Content-Type','application/json; charset=utf-8')]


@web.route('/getposts',methods=['GET'])
@login_required
def getpost():
    if request.method == 'GET':
        sql = "SELECT * FROM posts WHERE uid=? ORDER BY timing DESC Limit 8"
        uid = session['uid']
        data = select_data(sql,(uid,))
        result = []
        if data:
            for d in data:
                pid = d[0]
                title = d[2]
                content = d[3]
                tmp = tojson(title=title,content=content)
                result.append(tmp)
        return render_template_string(str(result).replace('\'','')),200,[('Content-Type','application/json; charset=utf-8')]

@web.route('/logout',methods=['GET'])
@login_required
def logout():
    session.pop('username',None)
    data = tojson(code=200,msg=u"登出成功")
    return render_template_string(data),200,[('Content-Type','application/json; charset=utf-8')]