#define ROUTE 0
#define WALL 1
#define WALL_CHAR "x"
#define ROUTE_CHAR " "
// #define DEBUG
struct maze_st {
    unsigned int size;
    unsigned int start_x, start_y, end_x, end_y;
    unsigned int cur_x, cur_y;
    char **data;
};
typedef struct maze_st Maze;


Maze* init_maze(unsigned int maze_sz_p); // 初始化迷宫
void show_maze(Maze* mazep); // 打印迷宫
int walk_maze(Maze* mazep, char *steps, unsigned int step_cnt);