<?php
namespace app\agent\controller;

use think\Db;
use think\Exception;
use think\Loader;
use think\Request;
use app\common\util\ReturnCode;
use app\common\util\Random;

class Card extends Base
{
    private $point_num = 0;

    public function _initialize() {
        parent::_initialize();
        $this->point_num = Db::name('user')->where(['id' => $this->agentInfo['id']])->value('point_num');
        $this->assign('point_num', $this->point_num);
    }

    public function index() {
        if ($this->isAjaxGet()) {
            $filter = [
                'card_no'  => $this->request->param('card_no'),
                'card_type'  => $this->request->param('card_type'),
                'is_use' => $this->request->param('is_use'),
                'username' => $this->request->param('username'),
                'create_by_id' => $this->agentInfo['id']
            ];
            $model = model('Card')->getCardList($filter);

            $cardList = $model->toArray();
            $cardTypeNameArr = ['3day' => '三天卡','month' => '月卡', 'season' => '季卡', 'year' => '年卡', 'forever' => '终身卡'];
            foreach ($cardList['data'] as $key => $value) {
                $cardList['data'][$key]['createtime'] = date('Y-m-d H:i:s', $value['createtime']);
                $cardList['data'][$key]['use_time'] = $value['use_time'] > 0 ? date('Y-m-d H:i:s', $value['use_time']) : '-';
                $cardList['data'][$key]['card_type_name'] = $cardTypeNameArr[$value['card_type']];
            }

            $data = $cardList['data'];
            $count = $cardList['total'];
            return $this->buildTableSuccess($data, $count);
        } else {
            return $this->fetch();
        }
    }

    public function exportCardList() {
        header("Content-Type: text/html; charset=utf8");
        Loader::import('PHPExcel.Classes.PHPExcel');
        Loader::import('PHPExcel.Classes.PHPExcel.IOFactory.PHPExcel_IOFactory');
        $str = Request::instance()->param('str');
        if (!empty($str)) {
            $params = json_decode($str);
            $filter = [
                'card_no'  => $params->card_no,
                'card_type'  => $params->card_type,
                'is_use' => $params->is_use,
                'username' => $params->username,
                'create_by_id' => $this->agentInfo['id']
            ];
        } else {
            $filter = [
                'card_no'  => '',
                'card_type'  => '',
                'is_use' => '',
                'username' => '',
                'create_by_id' => $this->agentInfo['id']
            ];
        }

        $model = collection(model('Card')->exportCardList($filter));

        $cardList = $model->toArray();
        
        $cardTypeNameArr = ['3day' => '三天卡','month' => '月卡', 'season' => '季卡', 'year' => '年卡', 'forever' => '终身卡'];
        $newList = [];
        foreach ($cardList as $key => $value) {
            $newList[] = [
                'id' => $value['id'],
                'card_no' => $value['card_no'],
                'card_type' => $cardTypeNameArr[$value['card_type']],
                'is_use' => $value['is_use'] == 1 ? '已使用' : '未使用',
                'use_user_name' => $value['use_user_name'],
                'use_time' => $value['use_time'] > 0 ? date('Y-m-d H:i:s', $value['use_time']) : '-'
            ];
        }
        $row_title = ['ID', '卡密', '类型', '使用状态', '使用者', '使用时间'];
        array_unshift($newList, $row_title);

        $date = date('Y-m-d H i');
        $phpexcel = new \PHPExcel();
        $sheet    = $phpexcel->getActiveSheet();
        $sheet->setTitle("{$date}-卡密记录");
        $chr = [];
        for ($i='A'; $i<='Z'; $i++) {
            $chr[] = $i;
            if (sizeof($chr) >= sizeof($row_title)) break;
        }

        $i = 1;
        foreach ($newList as $val) {
            $z = 0;
            foreach ($val as $k=>$v) {
                $sheet->setCellValue($chr[$z].$i, $v);
                $z++;
            }
            $i++;
        }

        $write = \PHPExcel_IOFactory::createWriter($phpexcel, 'Excel5');
        header("Pragma: public");
        header("Expires: 0");
        header("Cache-Control:must-revalidate, post-check=0, pre-check=0");
        header("Content-Type:application/force-download");
        header("Content-Type:application/vnd.ms-execl;charset=utf-8");
        header("Content-Type:application/octet-stream");
        header("Content-Type:application/download");
        header("Content-Disposition:attachment;filename={$date}-卡密记录.xls");
        header("Content-Transfer-Encoding:binary");
        header('Cache-Control: max-age=0');
        $write->save('php://output');
        exit;
    }

    /**
     * 提卡
     */
    public function take() {
        // 查询自己是否有设置过提卡积分
        $takePointInfo = Db::name('card_take_point')->field('month,season,year,forever')->where(['user_id' => $this->agentInfo['id']])->find();
        if (! empty($takePointInfo)) {
            $nameArr = array_keys($takePointInfo);
            $cardArr = $takePointInfo;
        } else {
            $cardConfig = Db::name('config')->where(['group' => 'card'])->field('name,value')->select();
            $nameArr = array_column($cardConfig, 'name');
            $valueArr = array_column($cardConfig, 'value');
            $cardArr = array_combine($nameArr, $valueArr);
        }
        
        if ($this->isAjaxPost()) {
            $params = $this->request->param();
            if ($params) {
                $card_type = $params['card_type'];
                $num = $params['num'];
                $desc = $params['desc'];
                if (!$num || ! in_array($card_type, $nameArr)) {
                   return $this->buildFailed(ReturnCode::INVALID, '非法操作');
                }

                if ($num > 300) {
                    return $this->buildFailed(ReturnCode::INVALID, '数量超出限制');
                }

                $needPoint = $cardArr[$params['card_type']] * $params['num'];
                if ($needPoint > $this->point_num) {
                    return $this->buildFailed(ReturnCode::INVALID, '积分不足');
                }

                $nowTime = time();
                $logData = [
                    'card_type' => $card_type,
                    'num' => $num,
                    'point' => $cardArr[$params['card_type']],
                    'desc' => $desc,
                    'create_by_id' => $this->agentInfo['id'],
                    'createtime' => $nowTime
                ];
                // 启动事务
                Db::startTrans();
                try {
                    // 提卡记录
                    $batch_no = Db::name('card_take_log')->insertGetId($logData);
                    if (! $batch_no) {
                        throw new Exception("提卡失败，请重试！");
                    }

                    $list = [];
                    for ($i=0; $i < $num; $i++) { 
                        $list[] = [
                            'batch_no' => $batch_no,
                            'card_no' => md5(Random::uuid() . Random::alnum() . time()),
                            'card_type' => $card_type,
                            'createtime' => $nowTime,
                            'create_by_id' => $this->agentInfo['id']
                        ];
                    }
                    // 生成卡
                    $res = Db::name('card')->insertAll($list);
                    if (! $res) {
                        throw new Exception("提卡失败，请重试！");
                    }

                    // 提卡后，代理的积分要减少
                    $res = Db::name('user')->where(['id' => $this->agentInfo['id']])->setDec('point_num', $needPoint);
                    if (! $res) {
                        throw new Exception("提卡失败，请重试！");
                    }
                    $info = Db::name('user')->where(['id' => $this->agentInfo['id']])->field('point_total,point_num')->find();
                    $this->point_num = $info['point_num'];
                    // 积分支出记录
                    $record = [
                        'user_id' => $this->agentInfo['id'], // 代理
                        'type' => 2, // 支出
                        'point_use' => $needPoint,
                        'point_total' => $info['point_total'],
                        'point_num' => $info['point_num'],
                        'desc' => '代理提卡' . $num . '张',
                        'create_by_type' => 2, // 代理
                        'create_by_id' => $this->agentInfo['id'],
                        'createtime' => $nowTime,
                        'use_type' => 2, // 提卡
                        'model' => 'card_take_log', // 提卡记录表
                        'record_id' => $batch_no // $batch_no
                    ];
                    // 积分支出记录
                    $res = Db::name('user_point_record')->insert($record);
                    if (! $res) {
                        throw new Exception("提卡失败，请重试！");
                    }
                    Db::commit();
                    return $this->buildSuccess([], '提卡成功');
                } catch(Exception $e) {
                    Db::rollback();
                    return $this->buildFailed(ReturnCode::ADD_FAILED, $e->getMessage());
                }
            } else {
                return $this->buildFailed(ReturnCode::INVALID, '非法操作');
            }
        } else {
            $this->assign('cardArr', json_encode($cardArr));
            return $this->fetch();
        }
    }

    public function takelog() {
        if ($this->isAjaxGet()) {

            $filter = [
                'id'  => $this->request->param('id'),
                'card_type'  => $this->request->param('card_type'),
                'starttime' => $this->request->param('starttime'),
                'endtime' => $this->request->param('endtime'),
                'create_by_id' => $this->agentInfo['id']
            ];

            $model = model('CardTakeLog')->getTakeLog($filter, $this->limit);
            $takelogList = $model->toArray();

            $cardTypeNameArr = ['3day' => '三天卡','month' => '月卡', 'season' => '季卡', 'year' => '年卡', 'forever' => '终身卡'];
            foreach ($takelogList['data'] as $key => $value) {
                $takelogList['data'][$key]['createtime'] = date('Y-m-d H:i:s', $value['createtime']);
                $takelogList['data'][$key]['card_type_name'] = $cardTypeNameArr[$value['card_type']];
            }
            $data = $takelogList['data'];
            $count = $takelogList['total'];
            return $this->buildTableSuccess($data, $count);
        } else {
            return $this->fetch();
        }
    }

    public function exportTakeLog() {
        Loader::import('PHPExcel.Classes.PHPExcel');
        Loader::import('PHPExcel.Classes.PHPExcel.IOFactory.PHPExcel_IOFactory');
        $str = Request::instance()->param('str');
        if (!empty($str)) {
            $params = json_decode($str);
            $filter = [
                'id'  => $params->id,
                'card_type'  => $params->card_type,
                'starttime' => $params->starttime,
                'endtime' => $params->endtime,
                'create_by_id' => $this->agentInfo['id']
            ];
        } else {
            $filter = [
                'id'  => '',
                'card_type'  => '',
                'starttime' => '',
                'endtime' => '',
                'create_by_id' => $this->agentInfo['id']
            ];
        }

        $model = collection(model('CardTakeLog')->exportTakeLog($filter));

        $cardList = $model->toArray();
        
        $cardTypeNameArr = ['3day' => '三天卡','month' => '月卡', 'season' => '季卡', 'year' => '年卡', 'forever' => '终身卡'];
        $newList = [];
        foreach ($cardList as $key => $value) {
            $newList[] = [
                'id' => $value['id'],
                'card_type' => $cardTypeNameArr[$value['card_type']],
                'num' => $value['num'],
                'createtime' => date('Y-m-d H:i:s', $value['createtime']),
                'desc' => $value['desc']
            ];
        }
        $row_title = ['批次号', '套餐', '数量', '时间', '备注'];
        array_unshift($newList, $row_title);

        $date = date('Y-m-d H i');
        $phpexcel = new \PHPExcel();
        $sheet    = $phpexcel->getActiveSheet();
        $sheet->setTitle("{$date}-提卡记录");
        $chr = [];
        for ($i='A'; $i<='Z'; $i++) {
            $chr[] = $i;
            if (sizeof($chr) >= sizeof($row_title)) break;
        }

        $i = 1;
        foreach ($newList as $val) {
            $z = 0;
            foreach ($val as $k=>$v) {
                $sheet->setCellValue($chr[$z].$i, $v);
                $z++;
            }
            $i++;
        }

        $write = \PHPExcel_IOFactory::createWriter($phpexcel, 'Excel5');
        header("Pragma: public");
        header("Expires: 0");
        header("Cache-Control:must-revalidate, post-check=0, pre-check=0");
        header("Content-Type:application/force-download");
        header("Content-Type:application/vnd.ms-execl");
        header("Content-Type:application/octet-stream");
        header("Content-Type:application/download");
        header("Content-Disposition:attachment;filename={$date}-提卡记录.xls");
        header("Content-Transfer-Encoding:binary");
        header('Cache-Control: max-age=0');
        $write->save('php://output');
        exit;
    }
}
