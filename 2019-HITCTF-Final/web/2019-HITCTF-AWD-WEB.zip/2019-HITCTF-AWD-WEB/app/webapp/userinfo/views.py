#/usr/bin/env python
# encoding:utf-8

from . import userinfo
from flask import render_template,abort,flash,redirect,url_for
from webapp.models import User
from flask_login import login_required,current_user
from .forms import EditMyProfile
from webapp.models import db
from flask import request,current_app
from werkzeug.datastructures import ImmutableMultiDict
from ..utils.utils import HMAC_Pickler, random_string, md5
import base64

@userinfo.route('/<username>')
def user(username):
    pickler = HMAC_Pickler(current_app.config['SERIALIZER_SECRET_KEY'])
    user = User.query.filter_by(username = username).first()
    if user.about_me != None:
        try:
            data = user.about_me
            if b'R' in base64.b64decode(data.split(pickler.seperator)[1]):
                raise Exception("Reduce R to make safe.")
            user.about_me = pickler.loads(data)
        except Exception as e:
            print("Unseriale Exception:", e)
            user.about_me = r'规格严格，功夫到家。xxx'
    if user is None:
        abort(404)
    return render_template('userinfo/userinfo.html',user=user,backgroundpic = '/static/img/userinfo_bg.jpg')

@userinfo.route('/editprofile',methods = ['GET','POST'])
@login_required
def edit_profile():
    form =EditMyProfile()
    if form.validate_on_submit():
        current_user.name = form.name.data
        current_user.location = form.location.data
        current_user.about_me = form.about_me.data
        current_user.birthday = form.birthday.data

        if request.method == 'POST': 
            if request.files == ImmutableMultiDict([]):
                current_user.headimg = form.headimg.data
                current_user.headimg = "/image/%s" % (form.headimg.data)
            else:
                headimg = request.files['headimg']
                upload_folder = current_app.config['UPLOAD_FOLDER']
                filename = "%s.jpg" % md5(random_string())
                save_path = "%s/%s" % (upload_folder, filename)
                headimg.save(save_path)
                filepath = base64.b64encode(bytes('../headimg/%s' % (filename), encoding="utf-8"))
                current_user.headimg = "/image/%s" % str(filepath, encoding="utf-8")
                print(current_user.headimg)

        db.session.add(current_user)
        db.session.commit()
        flash('Your profile has been updated')
        return redirect(url_for('.user',username = current_user.username))
    headimg = current_user.headimg
    form.name.data=current_user.name
    form.location.data = current_user.location
    form.about_me.data = "规格严格，功夫到家。"
    form.birthday.data = current_user.birthday
    return render_template('userinfo/edit_profile.html',form=form,headimg = headimg,backgroundpic = '/static/img/userinfo_bg.jpg')
