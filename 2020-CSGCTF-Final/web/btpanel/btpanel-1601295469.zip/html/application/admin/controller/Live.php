<?php
namespace app\admin\controller;

use think\Db;
use think\Exception;
use app\Common\Util\ReturnCode;

/**
 * 直播接口设置
 */
class Live extends Base
{
    /**
     * 无需鉴权的方法,但需要登录
     */
    protected $noNeedRight = [];
    
    public function index() {
        if ($this->isAjaxGet()) {
            $model = Db::name('live_interface')
            ->where('is_deleted', 0)
            ->paginate($this->limit);

            $lists = $model->toArray();

            $data = $lists['data'];
            $count = $lists['total'];
            return $this->buildTableSuccess($data, $count);
        } else {
            return $this->fetch();
        }
    }

    public function add() {
        if ($this->isAjaxPost()) {
            $params = $this->request->param();
            $data = [
                'name' => $params['name'],
                'code' => $params['code'],
                'live_url' => $params['live_url'],
                'anchor_url' => $params['anchor_url'],
                'desc' => $params['desc'],
                'is_use' => $params['is_use']
            ];
            Db::startTrans();
            try {
                $id = Db::name('live_interface')->insertGetId($data);
                if ($id === false) {
                    throw new Exception('添加失败');
                }
                // 如果启用某个接口域名，则其它接口域名自动设为禁用
                if ($data['is_use'] == 1) {
                    $res = Db::name('live_interface')->where('id', 'neq', $id)->update(['is_use' => 0]);
                    if ($res === false) {
                        throw new Exception('添加失败');
                    }
                }
                Db::commit();
                return $this->buildSuccess([], '添加成功');
            } catch (Exception $e) {
                Db::rollback();
                return $this->buildFailed(ReturnCode::ADD_FAILED, $e->getMessage());
            }
        } else {
            return $this->fetch();
        }
    }


    public function edit($id = NULL) {
        $row = Db::name('live_interface')->where(['id' => $id])->find();
        if ($this->isAjaxPost()) {
            if (empty($row)) {
                return $this->buildFailed(ReturnCode::INVALID, '非法操作');
            }
            $params = $this->request->param();
            $data = [
                'name' => $params['name'],
                'code' => $params['code'],
                'live_url' => $params['live_url'],
                'anchor_url' => $params['anchor_url'],
                'desc' => $params['desc'],
                'is_use' => $params['is_use']
            ];

            Db::startTrans();
            try {
                $res = Db::name('live_interface')->where(['id' => $id])->update($data);
                if ($res === false) {
                    throw new Exception('编辑失败');
                }
                // 如果启用某个接口域名，则其它接口域名自动设为禁用
                if ($data['is_use'] == 1) {
                    $res = Db::name('live_interface')->where('id', 'neq', $id)->update(['is_use' => 0]);
                    if ($res === false) {
                        throw new Exception('编辑失败');
                    }
                }
                Db::commit();
                return $this->buildSuccess([], '编辑成功');
            } catch (Exception $e) {
                Db::rollback();
                return $this->buildFailed(ReturnCode::UPDATE_FAILED, $e->getMessage());
            }
        } else {
            if (empty($row)) {
                $this->error('非法操作');
            }
            $this->assign('row', $row);
            return $this->fetch();
        }
    }

    public function del() {
        if ($this->isAjaxPost()) {
            $id = $this->request->param('id', 0);
            if (! $id) {
                return $this->buildFailed(ReturnCode::INVALID, '非法操作');
            }
            $res = Db::name('live_interface')->where(['id' => $id])->update(['is_use' => 0, 'is_deleted' => 1]);
            if ($res === false) {
                return $this->buildFailed(ReturnCode::DELETE_FAILED, '删除失败');
            } else {
                return $this->buildSuccess([], '删除成功');
            }
        } else {
            return $this->buildFailed(ReturnCode::INVALID, '非法操作');
        }
    }
}
