<?php
namespace app\agent\model;

use think\Model;
use think\Db;

class User extends Model {

    // 表名
    // protected $name = 'user';

    /**
     * @param $filter
     * @param $order
     * @param $by
     * @param int $page_size
     * @return \think\Paginator
     */
    public function getUserList($filter, $page = 1, $page_size = 10,$is_count = false) {
      if($is_count){
          $result = $this->alias('a')
            ->field([
                'a.id'
            ])
            ->where(function ($query) use (&$filter) {
                $where = $query->where('a.id', 'gt', 0);
                if ((bool)$filter['uid']) {
                    $where->where('a.id', 'neq', $filter['uid']);
                }
                if ((bool)$filter['agent_code']) {
                    $where->where('a.agent_code', 'eq', $filter['agent_code']);
                }
                if ((bool)$filter['username']) {
                    $where->where('a.username', 'like', '%' . $filter['username'] . '%');
                }
                if ((bool)$filter['invite_code']) {
                    $where->where('a.invite_code', 'eq', $filter['invite_code']);
                }
                if (in_array($filter['is_agent'], ['0', '1'])) {
                    $where->where('a.is_agent', 'eq', $filter['is_agent']);
                }
            })
            ->count('a.id');
        }else{
          $result = $this->alias('a')
            ->field([
                'a.id',
                'a.username',
                'a.nickname',
                'a.nickname_code',
                'a.invite_code',
                'a.referrer',
                'a.agent_code',
                'a.is_ever',
                'a.end_time',
                'a.createtime',
                'a.logintime',
                'a.is_agent',
                'a.point_num',
                'a.status',
            ])
            ->where(function ($query) use (&$filter) {
                $where = $query->where('a.id', 'gt', 0);
                if ((bool)$filter['uid']) {
                    $where->where('a.id', 'neq', $filter['uid']);
                }
                if ((bool)$filter['agent_code']) {
                    $where->where('a.agent_code', 'eq', $filter['agent_code']);
                }
                if ((bool)$filter['username']) {
                    $where->where('a.username', 'like', '%' . $filter['username'] . '%');
                }
                if ((bool)$filter['invite_code']) {
                    $where->where('a.invite_code', 'eq', $filter['invite_code']);
                }
                if (in_array($filter['is_agent'], ['0', '1'])) {
                    $where->where('a.is_agent', 'eq', $filter['is_agent']);
                }
            })
            ->order('a.id desc')
            ->page($page,$page_size)
            ->select();
        }
        return $result;
    }

    public function exportUserList($filter, $page_size = 10) {
        // 统计下级代理数
        $sql = Db::name('user')->alias('ag')
            ->field([
                'COUNT(distinct ag.id)'
            ])
            ->where('ag.referrer=a.invite_code')
            ->fetchSql(true)
            ->find();

        $result = $this->alias('a')
            ->field([
                'a.id',
                'a.username',
                'a.nickname',
                'a.nickname_code',
                'a.invite_code',
                'a.referrer',
                'a.agent_code',
                'a.end_time',
                'a.createtime',
                'a.logintime',
                'a.is_agent',
                'a.point_num',
                'a.status',
                'IFNULL( b.username, "无" )' => 'referrer_name',
                'IFNULL( c.username, "无" )' => 'agent_name',
                '(' . $sql . ')' => 'agent_nums'
            ])
            ->join('user b','b.invite_code=a.referrer', 'LEFT')
            ->join('user c','c.invite_code=a.agent_code', 'LEFT')
            ->where(function ($query) use (&$filter) {
                $where = $query->where('a.id', 'gt', 0);
                if ((bool)$filter['uid']) {
                    $where->where('a.id', 'neq', $filter['uid']);
                }
                if ((bool)$filter['agent_code']) {
                    $where->where('a.agent_code', 'eq', $filter['agent_code']);
                }
                if ((bool)$filter['username']) {
                    $where->where('a.username', 'like', '%' . $filter['username'] . '%');
                }
                if ((bool)$filter['invite_code']) {
                    $where->where('a.invite_code', 'eq', $filter['invite_code']);
                }
                if (in_array($filter['is_agent'], ['0', '1'])) {
                    $where->where('a.is_agent', 'eq', $filter['is_agent']);
                }
            })
            ->select();

        return $result;
    }
}