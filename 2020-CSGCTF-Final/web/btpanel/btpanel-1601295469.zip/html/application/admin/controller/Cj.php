<?php
namespace app\admin\controller;

use think\Request;
use think\Db;
use app\common\util\ReturnCode;
use think\Exception;



use think\Loader;
use app\common\util\Random;

// use app\common\util\ReturnCode;
use app\common\util\HttpService;


/**
 * 视频模块
 */
class Cj extends Base {



    /**
     * [$live_code 直播接口提供商代码]
     *
     * @var string
     */
    private $live_code =  '';
    /**
     * [$live_url 直播机构列表url]
     *
     * @var string
     */
    private $live_url = 'http://api.hclyz.cn:81/mf/json.txt';
    /**
     * [$anchor_url 主播列表url]
     *
     * @var string
     */
    private $anchor_url = 'http://api.hclyz.cn:81/mf';

    public function _initialize()
    {
        parent::_initialize();
        $info = Db::name('live_interface')->where(['is_deleted' => 0, 'is_use' => 1])->find();
        if (! empty($info)) {
            $this->live_code = $info['code'];
            $this->live_url = $info['live_url'];
            $this->anchor_url = $info['anchor_url'];
        }
    }




    public function index() {
        if ($this->isAjaxGet()) {

            $liveList['count'] = 0;
            $liveList['lists'] = [];
            switch ($this->live_code) {
                case 'zhibo':
                    // $liveList = $this->getZhiboLive();
                    break;
                case 'snen9':
                    $liveList = $this->getSnen9Live();
                    break;
                case 'hclyz':

                    $liveList = $this->getHclyzLive();
                    break;
                default:
                    $this->buildFailed(ReturnCode::INVALID, '非法操作');
                    break;
            }
            $res = Db::name('rule')->where(['flag' => '0'])->find();

            //直播间数目排序
            if($res['rule'] == '1'){  
              $date = array_column($liveList['lists'], 'number');
              array_multisort($date,SORT_DESC ,$liveList['lists']);
            }
            //优先级排序
            if($res['level'] != '[]'){
              $levelarr = json_decode($res['level'],true);
              $datelevel = array_column($levelarr, 'level');
              array_multisort($datelevel,SORT_DESC ,$levelarr);

              foreach ($levelarr as $key => $value) {
                foreach ($liveList['lists'] as $key2 => $value2) {
                  if($value2['name'] == $value['name']){
                    $temp = $liveList['lists'][$key2];
                    $temp['level'] = $value['level'];
                    unset($liveList['lists'][$key2]);
                    array_unshift($liveList['lists'],$temp);
                  }

                }
              }                    
            }
            return $this->buildTableSuccess($liveList['lists'], $liveList['count']);
        } else {
            return $this->fetch();
        }
    }



    public function room() {

        $name = $this->request->param('name');      
        if ($this->isAjaxGet()) {

            $roomList['count'] = 0;
            $roomList['lists'] = [];
            switch ($this->live_code) {

                case 'zhibo':
            
                    // $liveList = $this->getZhiboLive();
                    break;
                case 'snen9':
    
                    $roomList = $this->getSnen9Anchors($name);
                    break;
                case 'hclyz':

                    $roomList = $this->getHclyzAnchors($name);
                    break;

                default:
               
                    $this->buildFailed(ReturnCode::INVALID, '非法操作');
                    break;
            }

            $res = Db::name('rule')->where(['flag' => $name])->find();
            if($res){

                //获取手动添加的房间列表
                if($res['addinfo']){
                    $addarr = json_decode($res['addinfo'], true);
                    foreach ($addarr as $key => $value) {
                        $itm = [
                             'title' => $value['title'],
                             'img' => $value['img'],
                             'play_url' => $value['play_url'],
                             'flag' => 1,
                             'id' => $value['pos']
                        ];
                        array_splice($roomList['lists'], $value['pos'], 0, array($itm));
                    }

                }
                //获取开启或关闭状态
                if($res['level']){
                    $resarr = json_decode($res['level'],true);
                    foreach ($roomList['lists'] as $key => $value) {
                      foreach ($resarr as $k => $v) {
                        if($value['title'] == $v['title']){
                          $roomList['lists'][$key]['flag'] = $v['flag'];
                          //unset($roomList['lists'][$key]);
                        }
                      }
                    }
                }


            }else{
                $data = [
                    'flag' => $name
                ];
                $res = Db::name('rule')->insert($data);
                if ($res === false) {
                  return $this->buildFailed(ReturnCode::ADD_FAILED, '插入失败');
                }
            }
            return $this->buildTableSuccess($roomList['lists'], $roomList['count']);
        } else {

            return $this->fetch();
        }
    }


    /**
     * [getHclyzLive 获取hclyz下的直播平台列表]
     */
    private function getHclyzLive() {
      if (empty($this->live_url)) {
           $this->buildFailed(ReturnCode::INVALID, '非法操作');
       }
       $returnData['count'] = 0;
       $returnData['lists'] = [];
       $res = HttpService::get($this->live_url);
       if (! empty($res)) {
           $result = json_decode($res, true);
           if (isset($result['pingtai']) && is_array($result['pingtai']) && !empty($result['pingtai'])) {
               $returnData['count'] = count($result['pingtai']);
               foreach ($result['pingtai'] as $k => $val) {
                  $returnData['lists'][] = [
                       'title' => $val['title'],
                       'name' => $val['address'],
                       'img' => $val['xinimg'],
                       'number' => $val['Number'],
                       'is_badge' => 1,
                       'level' => ''
                  ];
               }
           }
       }
       return $returnData;
   }

   /**
    * [getHclyzAnchors 获取hclyz下的某个直播平台下的主播列表]
    *
    */
   private function getHclyzAnchors($name) {
       if (empty($this->anchor_url) || empty($name)) {
           $this->buildFailed(ReturnCode::INVALID, '非法操作');
       }
       $returnData['count'] = 0;
       $returnData['lists'] = [];
       $res = HttpService::get($this->anchor_url . '/' . $name);
       if (! empty($res)) {
           $result = json_decode($res, true);
           if (isset($result['zhubo']) && is_array($result['zhubo']) && !empty($result['zhubo'])) {
               $returnData['count'] = count($result['zhubo']);
               foreach ($result['zhubo'] as $k => $val) {
                  $returnData['lists'][] = [
                       'title' => $val['title'],
                       'img' => $val['img'],
                       'play_url' => $val['address'],
                       'flag' => 1,
                       'id' => $k + 1
                  ];
               }
           }
       }
       return $returnData;
   }
  
    /**
     * [getSnen9Live 获取snen9下的直播平台列表]
     */
    private function getSnen9Live() {
        if (empty($this->live_url)) {
            $this->buildFailed(ReturnCode::INVALID, '非法操作');
        }
        $returnData['count'] = 0;
        $returnData['lists'] = [];
        $res = HttpService::get($this->live_url);
        if (! empty($res)) {
            $result = json_decode($res, true);
            if (isset($result['data']) && is_array($result['data']) && !empty($result['data'])) {
                $returnData['count'] = count($result['data']);
                foreach ($result['data'] as $k => $val) {
                   $returnData['lists'][] = [
                        'title' => $val['name'],
                        'name' => $val['url'],
                        'img' => $val['img'],
                        'number' => $val['fjs'],
                        'is_badge' => 1,
                        'level' => ''
                   ];
                }
            }
        }
        return $returnData;
    }
  
    /**
         * [getSnen9Anchors 获取snen9下的某个直播平台下的主播列表]
         *
         */
    private function getSnen9Anchors($name) {
      if (empty($this->anchor_url) || empty($name)) {
        $this->buildFailed(ReturnCode::INVALID, '非法操作');
      }
      $returnData['count'] = 0;
      $returnData['lists'] = [];
      $res = HttpService::get($this->anchor_url, ['name' => $name]);
      if (! empty($res)) {
        $res =  preg_replace('/[\x00-\x1F\x80-\x9F]/u', '', trim($res));
        $result = json_decode(htmlspecialchars_decode($res), true);
        if (isset($result['data']) && is_array($result['data']) && !empty($result['data'])) {
          $returnData['count'] = count($result['data']);
          foreach ($result['data'] as $k => $val) {
            $returnData['lists'][] = [
              'title' => $val['nickname'],
              'img' => $val['logourl'],
              'play_url' => $val['play_url'],
              'flag' => 1,
              'id' => $k + 1
            ];
          }
        }
      }
      return $returnData;
    }



    public function addlive() {
        if ($this->isAjaxPost()) {
            $title = $this->request->param('title', 0);
            $img = $this->request->param('img', 0);
            $play_url = $this->request->param('play_url', 0);
            $pos = $this->request->param('pos', 0);
            $flag = $this->request->param('flag', 0);
            if($title && $img && $play_url && $pos){
                $info = ['0' => [
                    'title' => $title,
                    'img' => $img,
                    'play_url' => $play_url,
                    'pos' => $pos
                ]];
                $data = [
                    'addinfo' => json_encode($info)
                ];
                $res = Db::name('rule')->where(['flag' => $flag])->find();
                if($res['addinfo']){
                    $resarr = json_decode($res['addinfo'],true);
                    $resarr = array_merge($resarr, $info);
                    $data = [
                        'addinfo' => json_encode($resarr,true)
                    ];
                }
                $res = Db::name('rule')->where(['flag' => $flag])->update($data);
            }
            if ($res === false) {
                return $this->buildFailed(ReturnCode::INVALID, '提交失败');
            } else {
                return $this->buildSuccess([]);
            }
        } else {
            return $this->buildFailed(ReturnCode::INVALID, '非法操作');
        }
    }

    public function updateSort(){
        if ($this->isAjaxPost()) {
            $rule = $this->request->param('rule', 0);
            $flag = $this->request->param('flag', 0);
            // $res = false;

            $data = [
                'rule' => $rule,
            ];
            $res = Db::name('rule')->where(['flag' => $flag])->update($data);
            if ($res === false) {
                return $this->buildFailed(ReturnCode::INVALID, '提交失败');
            } else {
                return $this->buildSuccess([]);
            }
        } else {
            return $this->buildFailed(ReturnCode::INVALID, '非法操作');
        }
    }

    public function updateLevel(){

        if ($this->isAjaxPost()) {

            $level =$_POST['level'];
            $flag = $_POST['flag'];
            // $res = false;
            $data = [
                'level' => $level,
            ];
            $res = Db::name('rule')->where(['flag' => $flag])->find();


            if($level != '[]' && $res != '[]'){
              $resarr = json_decode($res['level'],true);
              $levelarr = $level;
              foreach ($resarr as $key => $value) {
                foreach ($levelarr as $key2 => $value2) {
                  if($value['name'] == $value2['name']){
                     unset($resarr[$key]);
                     if($value2['level'] == ''){
                      unset($levelarr[$key2]);
                     }
                  }
                }
              }
              $data['level'] = array_merge_recursive($levelarr, $resarr);
            }

            $data['level'] = json_encode($data['level']);
            $res = Db::name('rule')->where(['flag' => $flag])->update($data);

            if ($res === false) {
                return $this->buildFailed(ReturnCode::INVALID, '提交失败');
            } else {
                return $this->buildSuccess([]);
            }
        } else {
            return $this->buildFailed(ReturnCode::INVALID, '非法操作');
        }
    }

    public function roomStatusUpdate(){
        if ($this->isAjaxPost()) {
            $level = $this->request->param('level', 0);
            $flag = $this->request->param('flag', 0);
            $isexist = false;

            $res = Db::name('rule')->where(['flag' => $flag])->find();
            if($res['level']){
                $levelarr = json_decode($level, true);
                $reslevelarr = json_decode($res['level'], true);
                foreach ($reslevelarr as $key => $value) {
                  if($value['title'] == $levelarr[0]['title']){
                    $reslevelarr[$key] = $levelarr[0];
                    $isexist = true;
                    // continue;
                  }
                }
                if(! $isexist){
                   $reslevelarr = array_merge($reslevelarr,$levelarr);
                };
                $data = json_encode($reslevelarr);

                $res = Db::name('rule')->where(['flag' => $flag])->update(['level' => $data]);
            }else{
                $res = Db::name('rule')->where(['flag' => $flag])->update(['level' => $level]);
            }

            if ($res === false) {
                return $this->buildFailed(ReturnCode::INVALID, '更新失败');
            } else {
                return $this->buildSuccess([]);
            }
        } else {
            return $this->buildFailed(ReturnCode::INVALID, '非法操作');
        }
    }


}