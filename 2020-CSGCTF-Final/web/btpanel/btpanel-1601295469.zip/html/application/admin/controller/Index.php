<?php
namespace app\admin\controller;

use think\Db;

use app\admin\model\AuthRule;

use app\common\library\Tree;


class Index extends Base
{
    /**
     * 无需鉴权的方法,但需要登录
     */
    protected $noNeedRight = ['index', 'home'];

    public function index()
    {

        // 读取管理员当前拥有的权限节点
      	//cache("__menu__")->
        $userRule = $this->auth->getRuleList();
        $ruleList = collection(AuthRule::where('status', '1')->where('ismenu', 1)->order('weigh', 'desc')->select())->toArray();
        foreach ($ruleList as $k => &$v) {
            if (!in_array(strtolower($v['name']), $userRule)) {
                unset($ruleList[$k]);
                continue;
            }
            $v['url'] = url($v['name']);
        }
        // 构造菜单数据
        $parentNodeArr = [];
        foreach ($ruleList as $value) {
            if (!isset($value['id']))
                continue;
            if ($value['pid'] == 0)
                $parentNodeArr[$value['id']] = $value;
        }
        foreach ($parentNodeArr as $key => $parent) {
            $childArr = [];
            foreach ($ruleList as $child) {
                if ($child['pid'] == $parent['id']) {
                    array_push($childArr, $child);
                }
            }
            $parentNodeArr[$key]['child'] = $childArr;
        }
        $menuList = $parentNodeArr;


        //左侧菜单
        $this->assign('menuList', $menuList);
        return $this->fetch();
    }

    public function home() {
        $monthTotal = Db::name('card')->where(['card_type' => 'month'])->count();
        $seasonTotal = Db::name('card')->where(['card_type' => 'season'])->count();
        $yearTotal = Db::name('card')->where(['card_type' => 'year'])->count();
        $foreverTotal = Db::name('card')->where(['card_type' => 'forever'])->count();

        $useMonthTotal = Db::name('card')->where(['card_type' => 'month', 'is_use' => 1])->count();
        $useSeasonTotal = Db::name('card')->where(['card_type' => 'season', 'is_use' => 1])->count();
        $useYearTotal = Db::name('card')->where(['card_type' => 'year', 'is_use' => 1])->count();
        $useForeverTotal = Db::name('card')->where(['card_type' => 'forever', 'is_use' => 1])->count();
        
        // 用户数-周
        $thisweek_start = mktime(0, 0, 0, date('m'), date('d') - date('w') + 1, date('Y'));
        $thisweek_end = mktime(23,59,59, date('m'), date('d') - date('w') + 7, date('Y'));
        $weekUsreTotal = Db::name('user')->whereTime('createtime', 'between', [$thisweek_start, $thisweek_end])->count();
        $weekAgentTotal = Db::name('user')->where(['is_agent' => 1])->whereTime('createtime', 'between', [$thisweek_start, $thisweek_end])->count();
        // 用户数-月
        $thismonth_start = mktime(0, 0, 0, date('m'), 1, date('Y'));
        $thismonth_end = mktime(23,59,59, date('m'), date('t'), date('Y'));
        $monthUsreTotal = Db::name('user')->whereTime('createtime', 'between', [$thismonth_start, $thismonth_end])->count();
        $monthAgentTotal = Db::name('user')->where(['is_agent' => 1])->whereTime('createtime', 'between', [$thismonth_start, $thismonth_end])->count();

        $userTotal = Db::name('user')->count();
        $agentTotal = Db::name('user')->where(['is_agent' => 1])->count();

        $this->assign('monthTotal', $monthTotal);
        $this->assign('seasonTotal', $seasonTotal);
        $this->assign('yearTotal', $yearTotal);
        $this->assign('foreverTotal', $foreverTotal);
        $this->assign('useMonthTotal', $useMonthTotal);
        $this->assign('useSeasonTotal', $useSeasonTotal);
        $this->assign('useYearTotal', $useYearTotal);
        $this->assign('useForeverTotal', $useForeverTotal);

        $this->assign('userTotal', $userTotal);
        $this->assign('weekUsreTotal', $weekUsreTotal);
        $this->assign('monthUsreTotal', $monthUsreTotal);

        $this->assign('agentTotal', $agentTotal);
        $this->assign('weekAgentTotal', $weekAgentTotal);
        $this->assign('monthAgentTotal', $monthAgentTotal);

        return $this->fetch();
    }
}
