<?php
namespace app\agent\controller;

use think\Db;
use think\Controller;

class Index extends Base
{
    public function index()
    {
        $agent_notice = Db::name('config')->where(['group' => 'basic', 'name' => 'agent_notice'])->value('value');
        $this->assign('agent_notice', $agent_notice);
        return $this->fetch();
    }

    public function home() {
        $monthTotal = Db::name('card')->where(['create_by_id' => $this->agentInfo['id'], 'card_type' => 'month'])->count();
        $seasonTotal = Db::name('card')->where(['create_by_id' => $this->agentInfo['id'], 'card_type' => 'season'])->count();
        $yearTotal = Db::name('card')->where(['create_by_id' => $this->agentInfo['id'], 'card_type' => 'year'])->count();
        $foreverTotal = Db::name('card')->where(['create_by_id' => $this->agentInfo['id'], 'card_type' => 'forever'])->count();

        $useMonthTotal = Db::name('card')->where(['create_by_id' => $this->agentInfo['id'], 'card_type' => 'month', 'is_use' => 1])->count();
        $useSeasonTotal = Db::name('card')->where(['create_by_id' => $this->agentInfo['id'], 'card_type' => 'season', 'is_use' => 1])->count();
        $useYearTotal = Db::name('card')->where(['create_by_id' => $this->agentInfo['id'], 'card_type' => 'year', 'is_use' => 1])->count();
        $useForeverTotal = Db::name('card')->where(['create_by_id' => $this->agentInfo['id'], 'card_type' => 'forever', 'is_use' => 1])->count();
        
        // 用户数-周
        $thisweek_start = mktime(0, 0, 0, date('m'), date('d') - date('w') + 1, date('Y'));
        $thisweek_end = mktime(23,59,59, date('m'), date('d') - date('w') + 7, date('Y'));
        $weekUsreTotal = Db::name('user')->where(['referrer' => $this->agentInfo['invite_code']])->whereTime('createtime', 'between', [$thisweek_start, $thisweek_end])->count();
        $weekAgentTotal = Db::name('user')->where(['agent_code' => $this->agentInfo['invite_code']])->where(['is_agent' => 1])->whereTime('createtime', 'between', [$thisweek_start, $thisweek_end])->count();
        // 用户数-月
        $thismonth_start = mktime(0, 0, 0, date('m'), 1, date('Y'));
        $thismonth_end = mktime(23,59,59, date('m'), date('t'), date('Y'));
        $monthUsreTotal = Db::name('user')->where(['referrer' => $this->agentInfo['invite_code']])->whereTime('createtime', 'between', [$thismonth_start, $thismonth_end])->count();
        $monthAgentTotal = Db::name('user')->where(['agent_code' => $this->agentInfo['invite_code']])->where(['is_agent' => 1])->whereTime('createtime', 'between', [$thismonth_start, $thismonth_end])->count();

        $userTotal = Db::name('user')->where(['referrer' => $this->agentInfo['invite_code']])->count();
        $agentTotal = Db::name('user')->where(['agent_code' => $this->agentInfo['invite_code']])->where(['is_agent' => 1])->count();

        $this->assign('monthTotal', $monthTotal);
        $this->assign('seasonTotal', $seasonTotal);
        $this->assign('yearTotal', $yearTotal);
        $this->assign('foreverTotal', $foreverTotal);
        $this->assign('useMonthTotal', $useMonthTotal);
        $this->assign('useSeasonTotal', $useSeasonTotal);
        $this->assign('useYearTotal', $useYearTotal);
        $this->assign('useForeverTotal', $useForeverTotal);

        $this->assign('userTotal', $userTotal);
        $this->assign('weekUsreTotal', $weekUsreTotal);
        $this->assign('monthUsreTotal', $monthUsreTotal);

        $this->assign('agentTotal', $agentTotal);
        $this->assign('weekAgentTotal', $weekAgentTotal);
        $this->assign('monthAgentTotal', $monthAgentTotal);

        return $this->fetch();
    }
}
