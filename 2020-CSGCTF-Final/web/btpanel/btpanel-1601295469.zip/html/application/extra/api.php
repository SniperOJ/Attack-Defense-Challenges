<?php
// api配置
return [
    /**
     * AccessToken失效时间
     */
    'ACCESS_TOKEN_TIME_OUT' => 604800,

];
