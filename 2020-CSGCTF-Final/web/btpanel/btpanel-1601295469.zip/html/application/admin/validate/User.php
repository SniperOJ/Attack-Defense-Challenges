<?php
namespace app\admin\validate;

use think\Validate;

class User extends Validate
{
    /**
     * 正则
     */
    protected $regex = ['phone_format' => '^1[3-9]\d{9}$'];

    /**
     * 验证规则
     */
    protected $rule = [
        'username' => 'require|max:64|unique:user',
        'password' => 'require',
        'referrer' => 'require'
    ];

    /**
     * 提示消息
     */
     protected $message = [
        'username.require'  =>  '用户名不能为空',
        'username.unique'  =>  '此用户名已被注册',
        'passwrod.require' =>  '密码不能为空',
        'referrer.require' => '推荐码不能为空'
    ];

     /**
     * 验证场景
     */
    protected $scene = [
        'add'  => ['username', 'password']
    ];
}
