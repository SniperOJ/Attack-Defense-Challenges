"""empty message

Revision ID: 5f0a355c9a69
Revises: 51f5ccfba190
Create Date: 2017-10-17 16:41:58.180733

"""

# revision identifiers, used by Alembic.
revision = '5f0a355c9a69'
down_revision = '51f5ccfba190'

from alembic import op
import sqlalchemy as sa


def upgrade():
    pass


def downgrade():
    pass
