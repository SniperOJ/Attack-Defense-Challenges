#coding:utf-8
from pwn import *
import pwn_framework as pf
import time
import sys
import random

global io
global timeout
TIMEOUT = 3
ru = lambda p, x : p.recvuntil(x, timeout=TIMEOUT)
sn = lambda p, x : p.send(x, timeout=TIMEOUT)
rl = lambda p  : p.recvline(timeout=TIMEOUT)
sl = lambda p, x : p.sendline(x, timeout=TIMEOUT)
rv = lambda p, x : p.recv(numb = x, timeout=TIMEOUT)
sa = lambda p, a,b : p.sendafter(a,b, timeout=TIMEOUT)
sla = lambda p, a,b : p.sendlineafter(a,b, timeout=TIMEOUT)

# amd64 or x86
context(arch = 'amd64', os = 'linux', endian = 'little')
context.log_level = 'debug'
context.terminal = ['tmux', 'splitw', '-h']

def lg(name, val):
    log.info(name+" : "+hex(val))

def get_steps(maze, src, dst):
    ops = []
    size = len(maze)
    def _valid_(point):
        x = point[0]
        y = point[1]
        if x < 1 or x > (size - 2):
            return False
        if y < 1 or y > (size - 2):
            return False
        if maze[x][y] != 0:
            return False
        return True
    def _get_direc_(src, dst):
        if (abs(src[0]-dst[0]) + abs(src[1] - dst[1])) != 1:
            return 'x'
        if src[0] == dst[0]:
            if src[1] < dst[1]:
                return 'd'
            else:
                return 'a'
        else:
            if src[0] < dst[0]:
                return 's'
            else:
                return 'w'
    def _go_(point, direc):
        if direc == 'w':
            return (point[0]-1, point[1])
        if direc == 'a':
            return (point[0], point[1]-1)
        if direc == 's':
            return (point[0]+1, point[1])
        if direc == 'd':
            return (point[0], point[1]+1)
        log.error("wrong!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
    def _rev_go_(point, direc):
        if direc == 's':
            return (point[0]-1, point[1])
        if direc == 'd':
            return (point[0], point[1]-1)
        if direc == 'w':
            return (point[0]+1, point[1])
        if direc == 'a':
            return (point[0], point[1]+1)
        log.error("wrong!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
    stack = []
    stack.append(src)
    point = stack.pop()
    maze[point[0]][point[1]] = 2
    current = src
    direction = []
    direction.append((point[0], point[1]-1))
    direction.append((point[0]-1, point[1]))
    direction.append((point[0], point[1]+1))
    direction.append((point[0]+1, point[1]))
    for p in direction:
        if _valid_(p):
            stack.append(p)
    while len(stack) != 0:
        point = stack.pop()
        maze[point[0]][point[1]] = 2
        direc = _get_direc_(current, point)
        # print("current:"+str(current))
        # print("next:"+str(point))
        while(direc == 'x'):
            back = _rev_go_(current, ops.pop())
            current = back
            # print("back:"+str(back))
            direc = _get_direc_(back, point)
        ops.append(direc)
        current = point
        if (current[0]==dst[0] and current[1]==dst[1]):
        # print ops
            ret = ""
            for op in ops:
                ret += op
            return ret+"\n"
        direction = []
        direction.append((point[0], point[1]-1))
        direction.append((point[0]-1, point[1]))
        direction.append((point[0], point[1]+1))
        direction.append((point[0]+1, point[1]))
        for p in direction:
            if _valid_(p):
                # print("put to stack:"+str(p))
                stack.append(p)


def get_maze(p):
    ru(p, "size:")
    size = int(ru(p, ",").split(",")[0])
    log.info("maze size: "+str(size))
    ru(p, "start")
    start = eval(ru(p, ")"))
    ru(p, "end")
    end = eval(ru(p, ")"))

    log.debug("start"+str(start))
    log.debug("end"+str(end))
    tmp = rl(p, )
    maze = [[0 for i in range(size)] for i in range(size)]
    for i in range(size):
        line = rl(p)
        for j in range(size):
            maze[i][j] = 0 if line[j]==' ' else 1
    # print("maze is")
    # print(maze)
    return size, start, end, maze

def show_maze(maze):
    pass
    # size = len(maze)
    # for i in range(size):
    #     line = ""
    #     for j in range(size):
    #         line += "  " if maze[i][j] == 0 else "国"
    #     print(line)

def choice(p, idx):
    sla(p, "> ", str(idx))

def _check_maze(p):
    try:
        size, start, end, maze = get_maze(p)
        show_maze(maze)
        steps = get_steps(maze, start, end) + '\0'

        # gdb.attach(p, "b walk_maze")
        sa(p, "input your steps\n", steps)
        ru(p, "wow, you are really good at that")
        return True
    except:
        raise Exception

def check_shellcode(host, port):
    global TIMEOUT
    p = remote(host, port, timeout=TIMEOUT)
    _check_maze(p)
    try:
        choice(p, '1')
        # sc = asm(shellcraft.amd64.linux.write(1, "hello world", 11))
        sc = "Ph0666TY1131Xh333311k13XjiV11Hc1ZXYf1TqIHf9kDqW02DqX0D1Hu3M2E0A2H0U1p4s1L2t0T000q057k4I2D0W2x1l7k2p0G1o2A0x5L3A11052v0X0O0j7m037p7n0i07"
        sa(p, "show me the code ", sc)
        ru(p, "hello world")
        p.close()
        return True
    except:
        p.close()
        raise Exception

def check_repeater(host, port):
    global TIMEOUT
    p = remote(host, port, timeout=TIMEOUT)
    _check_maze(p)
    try:
        choice(p, 2)
        size = random.randint(0, 0x100)
        buf = open("/dev/urandom", "rb").read(size-1)
        sla(p, "input the size:", str(size))
        sla(p, "Say sth", buf)
        ru(p, "Say sth")
        ru(p, buf)
        p.close()
        return True
    except:
        p.close()
        raise Exception

def check_message(host, port):
    global TIMEOUT
    # p = remote(host, port, timeout=TIMEOUT)
    p = process("./main")
    _check_maze(p)
    try:
        # gdb.attach(p, "b leave_message")
        choice(p, 5)
        sc = "hacked_by_Smi1e"
        # sc = "\x90"*0x10 + asm(shellcraft.amd64.linux.sh()) # get shell
        sa(p, "e.g. hacked by Smi1e", sc)
        sla(p, "(./tourist.txt is recommended): ", "//proc/self/mem\0")
        # sla(p, "leaved by others", "0")
        # time.sleep(1)
        sla(p, "offset ?", str(0x6020dc))
        # sla(p, "offset ?", str(0x40115e)) # get shell
        # p.interactive()
        ru(p, "see you")
        p.close()
        return True
    except:
        p.close()
        raise Exception


HOST = "127.0.0.1"
PORT = 9999

# res = check_message(HOST, PORT)

context.log_level = "warn"

for i in range(10):
    try:
        check_message(HOST, PORT)
        check_shellcode(HOST, PORT)
        check_repeater(HOST, PORT)
        print("check {} success".format(i))
    except:
        print("check {} failed".format(i))