<?php
namespace app\admin\model;

use think\Model;
use think\Db;

class Card extends Model {

    // 表名
    // protected $name = 'card';

    /**
     * @param $filter
     * @param $order
     * @param $by
     * @param int $page_size
     * @return \think\Paginator
     */
    public function getCardList($filter, $page_size = 10) {
        $result = $this->alias('c')
            ->field([
                'c.id',
                'c.card_no',
                'c.card_type',
                'c.is_use',
                'c.user_id',
                'c.use_time',
                'c.createtime',
                'IFNULL( u.username, "无" )' => 'use_user_name',
                'IFNULL( ag.username, "无" )' => 'createname'
            ])
            ->join('user u', 'u.id=c.user_id', 'LEFT')
            ->join('user ag', 'ag.id=c.create_by_id', 'LEFT')
            ->where(function ($query) use (&$filter) {
                $where = $query->where('c.id', 'gt', 0);
                if ((bool)$filter['card_no']) {
                    $where->where('c.card_no', 'eq', $filter['card_no']);
                }
                if ((bool)$filter['card_type']) {
                    $where->where('c.card_type', 'eq', $filter['card_type']);
                }
                if (in_array($filter['is_use'], ['0', '1'])) {
                    $where->where('c.is_use', 'eq', $filter['is_use']);
                }
                if ((bool)$filter['use_user_name']) {
                    $where->where('u.username', 'like', '%' . $filter['use_user_name'] . '%');
                }
                if ((bool)$filter['createname']) {
                    $where->where('ag.username', 'like', '%' . $filter['createname'] . '%');
                }
                if ((bool)$filter['starttime'] &&  (bool)$filter['endtime']) {
                    $where->whereTime('c.use_time', 'between', [strtotime($filter['starttime'] . ' 00:00:00'), strtotime($filter['endtime'] . ' 23:59:59')]);
                } else {
                    if ((bool)$filter['starttime']) {
                        $where->whereTime('c.use_time', '>=', strtotime($filter['starttime'] . ' 00:00:00'));
                    }
                    if ((bool)$filter['endtime']) {
                        $where->whereTime('c.use_time', '<=', strtotime($filter['endtime'] . ' 23:59:59'));
                    }
                }
                
            })
            ->order('c.id desc')
            ->paginate($page_size);
        return $result;
    }

    /**
     * 导数据
     * @param $filter
     */
    public function exportCardList($filter) {
        $result = $this->alias('c')
            ->field([
                'c.id',
                'c.card_no',
                'c.card_type',
                'c.is_use',
                'IFNULL( u.username, "无" )' => 'use_user_name',
                'c.use_time',
                'IFNULL( ag.username, "无" )' => 'createname'
            ])
            ->join('user u', 'u.id=c.user_id', 'LEFT')
            ->join('user ag', 'ag.id=c.create_by_id', 'LEFT')
            ->where(function ($query) use (&$filter) {
                $where = $query->where('c.id', 'gt', 0);
                if ((bool)$filter['card_no']) {
                    $where->where('c.card_no', 'eq', $filter['card_no']);
                }
                if ((bool)$filter['card_type']) {
                    $where->where('c.card_type', 'eq', $filter['card_type']);
                }
                if (in_array($filter['is_use'], ['0', '1'])) {
                    $where->where('c.is_use', 'eq', $filter['is_use']);
                }
                if ((bool)$filter['use_user_name']) {
                    $where->where('u.username', 'like', '%' . $filter['use_user_name'] . '%');
                }
                if ((bool)$filter['createname']) {
                    $where->where('ag.username', 'like', '%' . $filter['createname'] . '%');
                }
                if ((bool)$filter['starttime'] &&  (bool)$filter['endtime']) {
                    $where->whereTime('c.use_time', 'between', [strtotime($filter['starttime'] . ' 00:00:00'), strtotime($filter['endtime'] . ' 23:59:59')]);
                } else {
                    if ((bool)$filter['starttime']) {
                        $where->whereTime('c.use_time', '>=', strtotime($filter['starttime'] . ' 00:00:00'));
                    }
                    if ((bool)$filter['endtime']) {
                        $where->whereTime('c.use_time', '<=', strtotime($filter['endtime'] . ' 23:59:59'));
                    }
                }
                
            })
            ->select();
        return $result;
    }
}