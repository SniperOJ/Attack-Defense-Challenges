class ValidationError(ValueError):
    pass
