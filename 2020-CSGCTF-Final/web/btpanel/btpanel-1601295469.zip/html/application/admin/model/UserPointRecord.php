<?php
namespace app\admin\model;

use think\Model;
use think\Db;

class UserPointRecord extends Model {

    // 表名
    // protected $name = 'user';

    /**
     * [代理积分操作记录]
     *
     * @since  2018-06-15
     */
    public function getPushRecordList($filter, $page_size = 10) {
        $result = $this->alias('upr')
            ->field([
                'upr.*',
                'u.username' => 'to_user_name',
                'ag.username'=> 'create_name'
            ])
            ->join('user u','u.id=upr.user_id')
            ->join('user ag','ag.id=upr.create_by_id')
            ->where('upr.create_by_type', '2')
            ->where('upr.type', '1')
            ->where('upr.use_type', '1')
            ->where('upr.is_deleted', '0')
            ->where(function ($query) use (&$filter) {
                $where = $query->where('upr.id', 'gt', 0);

                if ((bool)$filter['username']) {
                    $where->where('u.username', 'like', '%' . $filter['username'] . '%');
                }
                if ((bool)$filter['createname']) {
                    $where->where('ag.username', 'like', '%' . $filter['createname'] . '%');
                }
                if ((bool)$filter['starttime'] &&  (bool)$filter['endtime']) {
                    $where->whereTime('upr.createtime', 'between', [strtotime($filter['starttime'] . ' 00:00:00'), strtotime($filter['endtime'] . ' 23:59:59')]);
                } else {
                    if ((bool)$filter['starttime']) {
                        $where->whereTime('upr.createtime', '>=', strtotime($filter['starttime'] . ' 00:00:00'));
                    }
                    if ((bool)$filter['endtime']) {
                        $where->whereTime('upr.createtime', '<=', strtotime($filter['endtime'] . ' 23:59:59'));
                    }
                }
            })
            ->order('upr.id desc')
            ->paginate($page_size);

        return $result;
    }


    /**
     * [导出代理积分操作记录]
     *
     * @since  2018-06-15
     */
    public function exportPushRecordList($filter) {
        $result = $this->alias('upr')
            ->field([
                'upr.*',
                'u.username' => 'to_user_name',
                'ag.username'=> 'create_name'
            ])
            ->join('user u','u.id=upr.user_id')
            ->join('user ag','ag.id=upr.create_by_id')
            ->where('upr.create_by_type', '2')
            ->where('upr.type', '1')
            ->where('upr.use_type', '1')
            ->where('upr.is_deleted', '0')
            ->where(function ($query) use (&$filter) {
                $where = $query->where('upr.id', 'gt', 0);
                if ((bool)$filter['username']) {
                    $where->where('u.username', 'like', '%' . $filter['username'] . '%');
                }
                if ((bool)$filter['createname']) {
                    $where->where('ag.username', 'like', '%' . $filter['createname'] . '%');
                }
                if ((bool)$filter['starttime'] &&  (bool)$filter['endtime']) {
                    $where->whereTime('upr.createtime', 'between', [strtotime($filter['starttime'] . ' 00:00:00'), strtotime($filter['endtime'] . ' 23:59:59')]);
                } else {
                    if ((bool)$filter['starttime']) {
                        $where->whereTime('upr.createtime', '>=', strtotime($filter['starttime'] . ' 00:00:00'));
                    }
                    if ((bool)$filter['endtime']) {
                        $where->whereTime('upr.createtime', '<=', strtotime($filter['endtime'] . ' 23:59:59'));
                    }
                }
            })
            ->select();

        return $result;
    }

    /**
     * [管理员积分操作记录]
     *
     * @since  2018-06-15
     */
    public function getAdminPushRecordList($filter, $page_size = 10) {
        $result = $this->alias('upr')
            ->field([
                'upr.*',
                'u.username' => 'to_user_name',
                'ag.loginname'=> 'create_name'
            ])
            ->join('user u','u.id=upr.user_id')
            ->join('admin ag','ag.id=upr.create_by_id')
             ->where('upr.create_by_type', '1')
            ->where('upr.use_type', '1')
            ->where('upr.is_deleted', '0')
            ->where(function ($query) use (&$filter) {
                $where = $query->where('upr.id', 'gt', 0);

                if ((bool)$filter['username']) {
                    $where->where('u.username', 'like', '%' . $filter['username'] . '%');
                }
                if ((bool)$filter['createname']) {
                    $where->where('ag.loginname', 'like', '%' . $filter['createname'] . '%');
                }
                if ((bool)$filter['starttime'] &&  (bool)$filter['endtime']) {
                    $where->whereTime('upr.createtime', 'between', [strtotime($filter['starttime'] . ' 00:00:00'), strtotime($filter['endtime'] . ' 23:59:59')]);
                } else {
                    if ((bool)$filter['starttime']) {
                        $where->whereTime('upr.createtime', '>=', strtotime($filter['starttime'] . ' 00:00:00'));
                    }
                    if ((bool)$filter['endtime']) {
                        $where->whereTime('upr.createtime', '<=', strtotime($filter['endtime'] . ' 23:59:59'));
                    }
                }
            })
            ->order('upr.id desc')
            ->paginate($page_size);

        return $result;
    }


    /**
     * [导出管理员积分操作记录]
     *
     * @since  2018-06-15
     */
    public function exportAdminPushRecordList($filter) {
        $result = $this->alias('upr')
            ->field([
                'upr.*',
                'u.username' => 'to_user_name',
                'ag.loginname'=> 'create_name'
            ])
            ->join('user u','u.id=upr.user_id')
            ->join('admin ag','ag.id=upr.create_by_id')
            ->where('upr.create_by_type', '1')
            ->where('upr.use_type', '1')
            ->where('upr.is_deleted', '0')
            ->where(function ($query) use (&$filter) {
                $where = $query->where('upr.id', 'gt', 0);
                if ((bool)$filter['username']) {
                    $where->where('u.username', 'like', '%' . $filter['username'] . '%');
                }
                if ((bool)$filter['createname']) {
                    $where->where('ag.loginname', 'like', '%' . $filter['createname'] . '%');
                }
                if ((bool)$filter['starttime'] &&  (bool)$filter['endtime']) {
                    $where->whereTime('upr.createtime', 'between', [strtotime($filter['starttime'] . ' 00:00:00'), strtotime($filter['endtime'] . ' 23:59:59')]);
                } else {
                    if ((bool)$filter['starttime']) {
                        $where->whereTime('upr.createtime', '>=', strtotime($filter['starttime'] . ' 00:00:00'));
                    }
                    if ((bool)$filter['endtime']) {
                        $where->whereTime('upr.createtime', '<=', strtotime($filter['endtime'] . ' 23:59:59'));
                    }
                }
            })
            ->select();

        return $result;
    }
}