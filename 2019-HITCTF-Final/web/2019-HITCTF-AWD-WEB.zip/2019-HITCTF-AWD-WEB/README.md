#### 部署流程
```bash
#!/bin/bash

WEBROOT=/var/www/app
USER=ubuntu
GROUP=${USER}

# Install cloud-set-guest-password as a service
# download cloud-set-guest-password to /sbin
cd /lib/systemd/system/
cat <<EOF > cloud-set-guest-password.service
[Unit]
Description=Cloud Stack Set Guest Password

[Install]
WantedBy=default.target

[Service]
ExecStart=/sbin/cloud-set-guest-password
EOF
systemctl enable cloud-set-guest-password

# Install Dependencies
apt-get update
apt-get upgrade -y
apt-get dist-upgrade -y
apt-get install -y python3 python3-pip python3-gevent gunicorn3 mysql-server libssl-dev
# Setup MySQL
echo -e "GRANT ALL PRIVILEGES ON ctf.* TO 'ctf'@'localhost' IDENTIFIED BY '123456';\
CREATE DATABASE ctf;\
exit" | mysql

# Install Python Modules
cd ${WEBROOT}
pip3 install -r requirements.txt

# Setup Flask Env
find . -name '*.pyc' | xargs rm -rf
find . -name '__pycache__' | xargs rm -rf
find . -name 'migrations' | xargs rm -rf

# Setup Database
python3 manage.py db init
python3 manage.py db migrate
python3 manage.py db upgrade

# Setup Privilege
chown -R root:root .
chown root:root .secret
chmod o+w ${WEBROOT}/webapp/static/headimg
chmod o+w ${WEBROOT}/webapp/static/savepic
chown -R ${USER}:${GROUP} ${WEBROOT}/webapp

# Touch all files
find . | xargs touch

# Install Service
cd /lib/systemd/system/
cat <<EOF > hitctf.service
[Unit]
After=mysql.service

[Unit]
Description=HITCTF Web Challenge

[Install]
WantedBy=default.target

[Service]
WorkingDirectory=${WEBROOT}
ExecStart=/usr/bin/gunicorn3 -c ${WEBROOT}/gunicorn.conf.py --reload wsgi:app
EOF
systemctl enable hitctf

# Start Service
service hitctf start
```