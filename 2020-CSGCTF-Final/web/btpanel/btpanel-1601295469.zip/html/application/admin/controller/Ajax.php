<?php
namespace app\admin\controller;

use think\Config;
use think\Db;

use app\common\util\ReturnCode;
use app\common\util\Random;

/**
 * Ajax异步请求接口
 * @internal
 */
class Ajax extends Base
{
    /**
     * 无需鉴权的方法,但需要登录
     */
    protected $noNeedRight = ['upload', 'uploadVimg', 'uploadVideo', 'importVideo'];

    public function _initialize()
    {
        parent::_initialize();

        //设置过滤方法
        $this->request->filter(['strip_tags', 'htmlspecialchars']);
    }

    /**
     * 上传文件
     */
    public function upload()
    {
        // Config::set('default_return_type', 'json');
        $file = $this->request->file('file');

        if (empty($file)) {
            return $this->buildFailed(ReturnCode::INVALID, '未上传文件或超出服务器上传限制');
        }

        //判断是否已经存在附件
        $sha1 = $file->hash();

        $upload = Config::get('upload');

        preg_match('/(\d+)(\w+)/', $upload['maxsize'], $matches);
        $type = strtolower($matches[2]);
        $typeDict = ['b' => 0, 'k' => 1, 'kb' => 1, 'm' => 2, 'mb' => 2, 'gb' => 3, 'g' => 3];
        $size = (int)$upload['maxsize'] * pow(1024, isset($typeDict[$type]) ? $typeDict[$type] : 0);
        $fileInfo = $file->getInfo();
        $suffix = strtolower(pathinfo($fileInfo['name'], PATHINFO_EXTENSION));
        $suffix = $suffix ? $suffix : 'file';

        $mimetypeArr = explode(',', strtolower($upload['mimetype']));
        $typeArr = explode('/', $fileInfo['type']);

        //验证文件后缀
        if ($upload['mimetype'] !== '*' &&
            (
                !in_array($suffix, $mimetypeArr)
                || (stripos($typeArr[0] . '/', $upload['mimetype']) !== false && (!in_array($fileInfo['type'], $mimetypeArr) && !in_array($typeArr[0] . '/*', $mimetypeArr)))
            )
        ) {
            return $this->buildFailed(ReturnCode::INVALID, '上传文件格式受限制');
        }
        $replaceArr = [
            '{year}'     => date("Y"),
            '{mon}'      => date("m"),
            '{day}'      => date("d"),
            '{hour}'     => date("H"),
            '{min}'      => date("i"),
            '{sec}'      => date("s"),
            '{random}'   => Random::alnum(16),
            '{random32}' => Random::alnum(32),
            '{filename}' => $suffix ? substr($fileInfo['name'], 0, strripos($fileInfo['name'], '.')) : $fileInfo['name'],
            '{suffix}'   => $suffix,
            '{.suffix}'  => $suffix ? '.' . $suffix : '',
            '{filemd5}'  => md5_file($fileInfo['tmp_name']),
        ];
        $savekey = $upload['savekey'];
        $savekey = str_replace(array_keys($replaceArr), array_values($replaceArr), $savekey);

        $uploadDir = substr($savekey, 0, strripos($savekey, '/') + 1);
        $fileName = substr($savekey, strripos($savekey, '/') + 1);
        //
        $splInfo = $file->validate(['size' => $size])->move(ROOT_PATH . '/public' . $uploadDir, $fileName);
        // dump($splInfo);
        if ($splInfo) {
            $imagewidth = $imageheight = 0;
            if (in_array($suffix, ['gif', 'jpg', 'jpeg', 'bmp', 'png', 'swf'])) {
                $imgInfo = getimagesize($splInfo->getPathname());
                $imagewidth = isset($imgInfo[0]) ? $imgInfo[0] : $imagewidth;
                $imageheight = isset($imgInfo[1]) ? $imgInfo[1] : $imageheight;
            }
            $params = array(
                'admin_id'    => 1,
                'user_id'     => 0,
                'filesize'    => $fileInfo['size'],
                'imagewidth'  => $imagewidth,
                'imageheight' => $imageheight,
                'imagetype'   => $suffix,
                'imageframes' => 0,
                'mimetype'    => $fileInfo['type'],
                'url'         => $uploadDir . $splInfo->getSaveName(),
                'uploadtime'  => time(),
                'storage'     => 'local',
                'sha1'        => $sha1,
            );
            $attachment = model("attachment");
            $attachment->data(array_filter($params));
            $attachment->save();
            // \think\Hook::listen("upload_after", $attachment);
            return $this->buildSuccess([
                'url' => $uploadDir . $splInfo->getSaveName()
            ], '上传成功');
        } else {
            // 上传失败获取错误信息
            return $this->buildFailed(ReturnCode::ADD_FAILED, $file->getError());
        }
    }
    
    /**
     * 上传视频封面图片
     */
    public function uploadVimg()
    {
        // Config::set('default_return_type', 'json');
        $file = $this->request->file('file');

        if (empty($file)) {
            return $this->buildFailed(ReturnCode::INVALID, '未上传文件或超出服务器上传限制');
        }

        //判断是否已经存在附件
        $sha1 = $file->hash();

        $upload = Config::get('videoimg');

        preg_match('/(\d+)(\w+)/', $upload['maxsize'], $matches);
        $type = strtolower($matches[2]);
        $typeDict = ['b' => 0, 'k' => 1, 'kb' => 1, 'm' => 2, 'mb' => 2, 'gb' => 3, 'g' => 3];
        $size = (int)$upload['maxsize'] * pow(1024, isset($typeDict[$type]) ? $typeDict[$type] : 0);
        $fileInfo = $file->getInfo();
        $suffix = strtolower(pathinfo($fileInfo['name'], PATHINFO_EXTENSION));
        $suffix = $suffix ? $suffix : 'file';

        $mimetypeArr = explode(',', strtolower($upload['mimetype']));
        $typeArr = explode('/', $fileInfo['type']);

        //验证文件后缀
        if ($upload['mimetype'] !== '*' &&
            (
                !in_array($suffix, $mimetypeArr)
                || (stripos($typeArr[0] . '/', $upload['mimetype']) !== false && (!in_array($fileInfo['type'], $mimetypeArr) && !in_array($typeArr[0] . '/*', $mimetypeArr)))
            )
        ) {
            return $this->buildFailed(ReturnCode::INVALID, '上传文件格式受限制');
        }
        $replaceArr = [
            '{year}'     => date("Y"),
            '{mon}'      => date("m"),
            '{day}'      => date("d"),
            '{hour}'     => date("H"),
            '{min}'      => date("i"),
            '{sec}'      => date("s"),
            '{random}'   => Random::alnum(16),
            '{random32}' => Random::alnum(32),
            '{filename}' => $suffix ? substr($fileInfo['name'], 0, strripos($fileInfo['name'], '.')) : $fileInfo['name'],
            '{suffix}'   => $suffix,
            '{.suffix}'  => $suffix ? '.' . $suffix : '',
            '{filemd5}'  => md5_file($fileInfo['tmp_name']),
        ];
        $savekey = $upload['savekey'];
        $savekey = str_replace(array_keys($replaceArr), array_values($replaceArr), $savekey);

        $uploadDir = substr($savekey, 0, strripos($savekey, '/') + 1);
        $fileName = substr($savekey, strripos($savekey, '/') + 1);
        //
        $splInfo = $file->validate(['size' => $size])->move(ROOT_PATH . '/public' . $uploadDir, $fileName);
        // dump($splInfo);
        if ($splInfo) {
            $imagewidth = $imageheight = 0;
            if (in_array($suffix, ['gif', 'jpg', 'jpeg', 'bmp', 'png', 'swf'])) {
                $imgInfo = getimagesize($splInfo->getPathname());
                $imagewidth = isset($imgInfo[0]) ? $imgInfo[0] : $imagewidth;
                $imageheight = isset($imgInfo[1]) ? $imgInfo[1] : $imageheight;
            }
            $params = array(
                'admin_id'    => 1,
                'user_id'     => 0,
                'filesize'    => $fileInfo['size'],
                'imagewidth'  => $imagewidth,
                'imageheight' => $imageheight,
                'imagetype'   => $suffix,
                'imageframes' => 0,
                'mimetype'    => $fileInfo['type'],
                'url'         => $uploadDir . $splInfo->getSaveName(),
                'uploadtime'  => time(),
                'storage'     => 'local',
                'sha1'        => $sha1,
            );
            $attachment = model("attachment");
            $attachment->data(array_filter($params));
            $attachment->save();
            // \think\Hook::listen("upload_after", $attachment);
            return $this->buildSuccess([
                'url' => $uploadDir . $splInfo->getSaveName()
            ], '上传成功');
        } else {
            // 上传失败获取错误信息
            return $this->buildFailed(ReturnCode::ADD_FAILED, $file->getError());
        }
    }

    /**
     * 上传并导入视频
     */
    public function importVideo()
    {
        ini_set('max_execution_time', '0');
        ini_set('memory_limit', '256M');
        // Config::set('default_return_type', 'json');
        $file = $this->request->file('file');

        if (empty($file)) {
            return $this->buildFailed(ReturnCode::INVALID, '未上传文件或超出服务器上传限制');
        }

        //判断是否已经存在附件
        $sha1 = $file->hash();

        $upload = Config::get('excel');

        preg_match('/(\d+)(\w+)/', $upload['maxsize'], $matches);
        $type = strtolower($matches[2]);
        $typeDict = ['b' => 0, 'k' => 1, 'kb' => 1, 'm' => 2, 'mb' => 2, 'gb' => 3, 'g' => 3];
        $size = (int)$upload['maxsize'] * pow(1024, isset($typeDict[$type]) ? $typeDict[$type] : 0);
        $fileInfo = $file->getInfo();
        $suffix = strtolower(pathinfo($fileInfo['name'], PATHINFO_EXTENSION));
        $suffix = $suffix ? $suffix : 'file';

        $mimetypeArr = explode(',', strtolower($upload['mimetype']));
        $typeArr = explode('/', $fileInfo['type']);

        //验证文件后缀
        if ($upload['mimetype'] !== '*' &&
            (
                !in_array($suffix, $mimetypeArr)
                || (stripos($typeArr[0] . '/', $upload['mimetype']) !== false && (!in_array($fileInfo['type'], $mimetypeArr) && !in_array($typeArr[0] . '/*', $mimetypeArr)))
            )
        ) {
            return $this->buildFailed(ReturnCode::INVALID, '上传文件格式受限制');
        }
        $replaceArr = [
            '{year}'     => date("Y"),
            '{mon}'      => date("m"),
            '{day}'      => date("d"),
            '{hour}'     => date("H"),
            '{min}'      => date("i"),
            '{sec}'      => date("s"),
            '{random}'   => Random::alnum(16),
            '{random32}' => Random::alnum(32),
            '{filename}' => $suffix ? substr($fileInfo['name'], 0, strripos($fileInfo['name'], '.')) : $fileInfo['name'],
            '{suffix}'   => $suffix,
            '{.suffix}'  => $suffix ? '.' . $suffix : '',
            '{filemd5}'  => md5_file($fileInfo['tmp_name']),
        ];
        $savekey = $upload['savekey'];
        $savekey = str_replace(array_keys($replaceArr), array_values($replaceArr), $savekey);

        $uploadDir = substr($savekey, 0, strripos($savekey, '/') + 1);
        $fileName = substr($savekey, strripos($savekey, '/') + 1);
        $splInfo = $file->validate(['size' => $size])->move(ROOT_PATH . '/public' . $uploadDir, $fileName);
        if ($splInfo) {
            $filePath = ROOT_PATH . '/public' . $uploadDir . $splInfo->getSaveName();
            $result = importExecl($filePath);
            if ($result['code'] != 0) {
                return $this->buildFailed(ReturnCode::INVALID, $result['msg']);
            }
            $data = $result['data'];
            if (! empty($data)) {
                $arr = [];
                foreach($data as $val) {

                    // 视频分类
                    $cateId = Db::name('video_cate')->where(['title' => $val['E']])->value('id');
                    if (empty($cateId)) {
                        $cateId = Db::name('video_cate')->insertGetId([
                            'title' => $val['E'],
                            'create_by_id' => $this->adminInfo['id'],
                            'createtime' => time(),
                            'updatetime' => time()
                        ]);
                    }
                    $arr[] = [
                        'title' => $val['B'],
                        'link' => $val['C'],
                        'image' => $val['D'],
                        'cate_id' => $cateId,
                        'filename' => basename($val['C']),
                        'createtime' => time()
                    ];
                }
                $res = Db::name('video')->insertAll($arr);
                if ($res === false) {
                    return $this->buildFailed(ReturnCode::ADD_FAILED, '导入失败，请重试');
                }
                unset($arr);
                unset($data);
                unset($result);
                unset($splInfo);
                // 删除文件
                @unlink($filePath);
                return $this->buildSuccess([], '导入成功');
            } else {
                return $this->buildFailed(ReturnCode::ADD_FAILED, '导入失败，请重试');
            }
        } else {
            // 上传失败获取错误信息
            return $this->buildFailed(ReturnCode::ADD_FAILED, $file->getError());
        }
    }

    /**
     * 上传并导入小说
     */
    public function importNovel()
    {
        ini_set('max_execution_time', '0');
        ini_set('memory_limit', '256M');
        // Config::set('default_return_type', 'json');
        $file = $this->request->file('file');

        if (empty($file)) {
            return $this->buildFailed(ReturnCode::INVALID, '未上传文件或超出服务器上传限制');
        }

        //判断是否已经存在附件
        $sha1 = $file->hash();

        $upload = Config::get('excel');

        preg_match('/(\d+)(\w+)/', $upload['maxsize'], $matches);
        $type = strtolower($matches[2]);
        $typeDict = ['b' => 0, 'k' => 1, 'kb' => 1, 'm' => 2, 'mb' => 2, 'gb' => 3, 'g' => 3];
        $size = (int)$upload['maxsize'] * pow(1024, isset($typeDict[$type]) ? $typeDict[$type] : 0);
        $fileInfo = $file->getInfo();
        $suffix = strtolower(pathinfo($fileInfo['name'], PATHINFO_EXTENSION));
        $suffix = $suffix ? $suffix : 'file';

        $mimetypeArr = explode(',', strtolower($upload['mimetype']));
        $typeArr = explode('/', $fileInfo['type']);

        //验证文件后缀
        if ($upload['mimetype'] !== '*' &&
            (
                !in_array($suffix, $mimetypeArr)
                || (stripos($typeArr[0] . '/', $upload['mimetype']) !== false && (!in_array($fileInfo['type'], $mimetypeArr) && !in_array($typeArr[0] . '/*', $mimetypeArr)))
            )
        ) {
            return $this->buildFailed(ReturnCode::INVALID, '上传文件格式受限制');
        }
        $replaceArr = [
            '{year}'     => date("Y"),
            '{mon}'      => date("m"),
            '{day}'      => date("d"),
            '{hour}'     => date("H"),
            '{min}'      => date("i"),
            '{sec}'      => date("s"),
            '{random}'   => Random::alnum(16),
            '{random32}' => Random::alnum(32),
            '{filename}' => $suffix ? substr($fileInfo['name'], 0, strripos($fileInfo['name'], '.')) : $fileInfo['name'],
            '{suffix}'   => $suffix,
            '{.suffix}'  => $suffix ? '.' . $suffix : '',
            '{filemd5}'  => md5_file($fileInfo['tmp_name']),
        ];
        $savekey = $upload['savekey'];
        $savekey = str_replace(array_keys($replaceArr), array_values($replaceArr), $savekey);

        $uploadDir = substr($savekey, 0, strripos($savekey, '/') + 1);
        $fileName = substr($savekey, strripos($savekey, '/') + 1);
        $splInfo = $file->validate(['size' => $size])->move(ROOT_PATH . '/public' . $uploadDir, $fileName);
        if ($splInfo) {
            $filePath = ROOT_PATH . '/public' . $uploadDir . $splInfo->getSaveName();
            $result = importExecl($filePath);
            if ($result['code'] != 0) {
                return $this->buildFailed(ReturnCode::INVALID, $result['msg']);
            }
            $data = $result['data'];

            if (! empty($data)) {
                $arr = [];
                foreach($data as $val) {
                    // 小说分类
                    $cateId = Db::name('novel_cate')->where(['title' => $val['D']])->value('id');
                    if (empty($cateId)) {
                        $cateId = Db::name('novel_cate')->insertGetId([
                            'title' => $val['D'],
                            'create_by_id' => $this->adminInfo['id'],
                            'createtime' => time(),
                            'updatetime' => time()
                        ]);
                    }
                    $arr = [
                        'cate_id' => $cateId,
                        'title' => $val['B'],
                        'content' => $val['C'],
                        'createtime' => time(),
                        'updatetime' => time()
                    ];
                    $res = Db::name('novel')->insert($arr);
                }
                unset($arr);
                unset($data);
                unset($result);
                unset($splInfo);
                // 删除文件
                @unlink($filePath);
                return $this->buildSuccess([], '导入成功');
            } else {
                return $this->buildFailed(ReturnCode::ADD_FAILED, '导入失败，请重试');
            }
        } else {
            // 上传失败获取错误信息
            return $this->buildFailed(ReturnCode::ADD_FAILED, $file->getError());
        }
    }
}
