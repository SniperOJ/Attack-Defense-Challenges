imgUrl1="data/afficheimg/20161114nraqzu.jpg";
imgtext1="";
imgLink1=escape("https://yunqi.shopex.cn");
imgUrl2="data/afficheimg/20161114prfywc.jpg";
imgtext2="";
imgLink2=escape("https://yunqi.shopex.cn");
imgUrl3="data/afficheimg/20161114uxmgov.png";
imgtext3="";
imgLink3=escape("https://yunqi.shopex.cn");
imgUrl4="data/afficheimg/20161114ypdlyr.jpg";
imgtext4="";
imgLink4=escape("https://yunqi.shopex.cn");

var pics=imgUrl1+"|"+imgUrl2+"|"+imgUrl3+"|"+imgUrl4;
var links=imgLink1+"|"+imgLink2+"|"+imgLink3+"|"+imgLink4;
var texts=imgtext1+"|"+imgtext2+"|"+imgtext3+"|"+imgtext4;